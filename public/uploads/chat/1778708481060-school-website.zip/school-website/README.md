# St. Heritage School — Bilingual Website with Admin Panel

A complete, production-ready school website built with **Next.js 14 + MySQL**.

## Features

- **Bilingual** (English + Hindi) — toggleable by visitors, all content has parallel `_hi` columns
- **Beautiful homepage** with autoplay video hero, Excellence stats (real DB data, not dummy), about, academics, why-choose-us, notice board with marquee, events, gallery, sports, testimonials, CTA
- **Working multi-level navbar** (click + hover dropdowns, mobile-friendly accordion)
- **All public pages**: Home, About, Academics, Admissions (with online application), Faculty, Gallery (filterable photos/videos with lightbox), Notices (filterable by category), Events (upcoming/past), Sports, Contact (with form + map)
- **Full admin panel** at `/admin` — manage everything: site settings, theme color, hero video, all content sections, applications, contact messages
- **File uploads** (images, videos) — saved to `public/uploads/`
- **JWT-based auth** with httpOnly cookies
- **Mobile-responsive** Tailwind design with deep-maroon (#8b1a2e) + gold theme

---

## Quick Start (Local Development)

### 1. Install dependencies

```bash
npm install
```

### 2. Create the database

Create a MySQL database (any name — default is `school_db`).

**Option A — MySQL CLI:**
```bash
mysql -u root -p < database/schema.sql
```

**Option B — phpMyAdmin:**
1. Create a new database (e.g., `school_db`) with collation `utf8mb4_unicode_ci`
2. Open the **Import** tab
3. Upload `database/schema.sql`
4. Click **Go**

This creates all tables and seeds them with sample data.

### 3. Configure environment

Copy `.env.example` to `.env.local`:

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=school_db

JWT_SECRET=put_a_long_random_string_here_at_least_32_characters
JWT_EXPIRY=7d

NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

> **Important:** Use a long, random `JWT_SECRET` in production. Generate one with:
> `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

### 4. Run the dev server

```bash
npm run dev
```

Open <http://localhost:3000> for the public site, and <http://localhost:3000/admin/login> for the admin panel.

**Default admin credentials:**
- Username: `admin`
- Password: `admin123`

**🔒 Change the password immediately after first login** (an "Admin Users" management page is not in v1; for now you can update the hash directly in the `admin_users` table — generate a new bcrypt hash via `node -e "console.log(require('bcryptjs').hashSync('NEW_PASSWORD', 10))"`).

---

## Production Deployment

### Build for production

```bash
npm run build
npm start
```

The site runs on port 3000 by default. Use a process manager (PM2) or a service unit to keep it running.

### Option 1 — VPS (Ubuntu / DigitalOcean / Linode etc.)

```bash
# 1. Install Node.js 18+ and MySQL on the server
# 2. Upload project (via SFTP / git clone)
# 3. Inside the project folder:
npm ci --production=false
npm run build

# 4. Run with PM2 (recommended)
npm install -g pm2
pm2 start npm --name "school-site" -- start
pm2 save
pm2 startup     # follow the printed instructions

# 5. Set up Nginx to proxy port 80 → 3000
```

Sample Nginx config:

```nginx
server {
  listen 80;
  server_name yourschool.com www.yourschool.com;
  client_max_body_size 25M;     # for image/video uploads

  location / {
    proxy_pass http://localhost:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_cache_bypass $http_upgrade;
  }
}
```

Then enable HTTPS with Certbot: `sudo certbot --nginx -d yourschool.com`.

### Option 2 — Shared cPanel hosting (Node.js app)

1. Create a database in cPanel (MySQL Databases) and import `database/schema.sql` via phpMyAdmin
2. Open **Setup Node.js App**, create a new application:
   - Node version: 18 or higher
   - Application root: `/path/to/school-website`
   - Application URL: your domain
   - Startup file: `node_modules/next/dist/bin/next` with arguments `start -p PORT`
   - Or use a simple `server.js`:
     ```js
     // server.js
     const { spawn } = require('child_process');
     const child = spawn('npx', ['next', 'start', '-p', process.env.PORT || 3000], { stdio: 'inherit', shell: true });
     child.on('exit', code => process.exit(code));
     ```
3. In cPanel terminal: `cd /path/to/school-website && npm install && npm run build`
4. Set environment variables in cPanel's Node.js app interface (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, JWT_SECRET, etc.)
5. Restart the app

### Option 3 — Vercel (with external MySQL)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

Use a managed MySQL service (PlanetScale, Railway, Aiven) and add the connection details as Vercel environment variables. Note: file uploads to `public/uploads/` won't persist on Vercel — use Cloudinary, S3, or Vercel Blob for production media.

---

## Project Structure

```
school-website/
├── database/
│   └── schema.sql              ← MySQL schema with seed data
├── public/
│   └── uploads/                ← User-uploaded files end up here
├── src/
│   ├── app/
│   │   ├── api/                ← All backend API routes
│   │   │   ├── auth/           ← login, logout, me
│   │   │   ├── settings/       ← site_settings GET/POST
│   │   │   ├── highlights/     ← Excellence stats
│   │   │   ├── classes/  streams/  teachers/
│   │   │   ├── notices/  events/  gallery/  sports/
│   │   │   ├── testimonials/  about/  principal/
│   │   │   ├── admissions/  contact/
│   │   │   └── upload/         ← multipart file upload
│   │   ├── admin/              ← Admin panel pages
│   │   │   ├── layout.js       ← sidebar + auth guard
│   │   │   ├── login/page.js
│   │   │   ├── dashboard/page.js
│   │   │   ├── settings/page.js
│   │   │   └── (one folder per resource: highlights, classes, ...)
│   │   ├── about/  academics/  admissions/  faculty/  gallery/
│   │   ├── notices/  events/  sports/  contact/
│   │   └── page.js             ← Homepage
│   ├── components/
│   │   ├── home/               ← Homepage sections
│   │   ├── layout/             ← Navbar, Footer, SiteShell, PageBanner
│   │   └── admin/              ← Admin form helpers (FileUploader, AdminList...)
│   └── lib/
│       ├── db.js               ← MySQL connection pool
│       ├── auth.js             ← bcrypt + JWT helpers
│       ├── i18n.js             ← Bilingual translations + pickField helper
│       ├── LangContext.js      ← React Context for language
│       └── crud.js             ← Generic CRUD handler used by routes
├── .env.example
├── jsconfig.json               ← @/ path alias
├── next.config.js
├── tailwind.config.js
└── package.json
```

---

## Admin Panel — How to Use

After login at `/admin/login` you land on the dashboard. The sidebar has 14 sections:

| Section | What you manage |
|---|---|
| **Site Settings** | Site name, logo, theme color, hero video, hero title/subtitle, contact info, working hours, map embed, footer text, social URLs |
| **Highlights** | The "Excellence in Education" stat boxes on the homepage (Students, Faculty, Awards, Years, Labs, Sports Champions) |
| **About / Mission** | About school, mission, vision, principal's message — keyed sections used by the About page |
| **Classes** | Class levels (Nursery, Primary, Middle, Secondary, Senior) with images and bilingual descriptions |
| **Streams** | Class 11-12 streams: Science, Commerce, Arts |
| **Teachers** | Faculty members with photos, departments, bios |
| **Notices** | Notices with category, important flag, attachment |
| **Events** | School events (auto-categorized as upcoming/past by date) |
| **Gallery** | Photos & videos with category filtering |
| **Sports** | Sports programs with achievements |
| **Testimonials** | Parent / student testimonials with rating |
| **Admissions** | Edit fee structure & process steps + view/manage submitted applications |
| **Contact Messages** | Read / mark / delete messages from the contact form |

Every content form has both English and Hindi fields side-by-side. The Hindi field uses the Tiro Devanagari Hindi font; if Hindi is left blank, the public site falls back to English when displaying.

### Changing the theme color

Site Settings → Primary Theme Color. The color picker writes to the database.
**Note:** the visual theme uses Tailwind's compiled CSS, so a color change requires a rebuild (`npm run build`) to take full effect across all components. The DB value is stored, but Tailwind has compiled the original `#8b1a2e` into the CSS bundle. To change the live color, edit `tailwind.config.js`'s `primary` palette + `globals.css`'s `:root --primary` and rebuild.

### Hero video

Site Settings → Hero Video. Upload a `.mp4`/`.webm` file (recommended < 10MB, 1080p) or paste a video URL. Video plays muted, autoplay, looping.

### Adding new highlights / classes / sports / etc.

Each section has a list page with an "Add New" button → form page with bilingual fields, image upload, display order, and active toggle. Save → it appears live.

---

## Common tasks

**Reset the admin password**

```sql
-- Generate a new hash first:
-- node -e "console.log(require('bcryptjs').hashSync('newpassword', 10))"
UPDATE admin_users SET password_hash = '$2a$10$...' WHERE username = 'admin';
```

**Add a new admin user**

```sql
INSERT INTO admin_users (username, email, password_hash, full_name, role)
VALUES ('jane', 'jane@example.com', '$2a$10$...', 'Jane Doe', 'admin');
```

**Backup the database**

```bash
mysqldump -u root -p school_db > backup-$(date +%F).sql
```

**Backup uploads**

```bash
tar czf uploads-$(date +%F).tar.gz public/uploads/
```

---

## Tech Stack

- **Next.js 14** (App Router) — React server + client components
- **MySQL** via `mysql2/promise` connection pool
- **Tailwind CSS** — design tokens + utility classes
- **react-icons** — Fa* and Gi* icon families
- **bcryptjs** — password hashing
- **jsonwebtoken** — JWT tokens stored in httpOnly cookies
- **framer-motion / swiper** — animations + carousels (optional, included in deps)

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `ECONNREFUSED 127.0.0.1:3306` on first request | MySQL isn't running, or `.env.local` credentials are wrong |
| Login fails with default credentials | Make sure you imported `database/schema.sql` (it inserts the default admin) |
| Hindi text shows as boxes | The Tiro Devanagari Hindi font is loaded from Google Fonts — make sure the server has internet to fetch it on first paint, or self-host the font |
| Uploads return 401 | You're not logged in. Hit `/admin/login` first |
| Theme color change doesn't appear on the site | Tailwind requires a rebuild — edit `tailwind.config.js` + `globals.css` and run `npm run build` |
| `Module not found: @/lib/...` | Make sure `jsconfig.json` exists in the project root |

---

## License

This project was custom-built for your school. You own the code; modify and deploy freely. Stock images used in seed data are from Unsplash (free for commercial use).

---

**Default login** → `admin / admin123` — please change it on first run.
