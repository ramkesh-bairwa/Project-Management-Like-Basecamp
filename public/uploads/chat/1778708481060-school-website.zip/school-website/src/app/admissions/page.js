'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField } from '@/lib/i18n';
import { FaCheckCircle, FaRupeeSign, FaFileAlt, FaCalendarAlt, FaPaperPlane } from 'react-icons/fa';

export default function AdmissionsPage() {
  const { lang } = useLang();
  const [info, setInfo] = useState(null);
  const [form, setForm] = useState({
    student_name: '', dob: '', gender: '', parent_name: '', parent_email: '',
    phone: '', address: '', applying_for_class: '', previous_school: '', message: '',
  });
  const [status, setStatus] = useState({ loading: false, ok: false, error: '' });

  useEffect(() => {
    fetch('/api/admissions?type=info').then(r => r.json()).then(d => setInfo((d.items || [])[0] || null));
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ loading: true, ok: false, error: '' });
    try {
      const res = await fetch('/api/admissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setStatus({ loading: false, ok: true, error: '' });
      setForm({
        student_name: '', dob: '', gender: '', parent_name: '', parent_email: '',
        phone: '', address: '', applying_for_class: '', previous_school: '', message: '',
      });
    } catch (err) {
      setStatus({ loading: false, ok: false, error: err.message });
    }
  };

  const processSteps = (pickField(info, 'process_steps', lang) || '').split('\n').filter(Boolean);
  const docs = (pickField(info, 'documents_required', lang) || '').split('\n').filter(Boolean);

  const fees = info ? [
    { label: lang === 'hi' ? 'नर्सरी / KG' : 'Nursery / KG', value: info.fee_nursery },
    { label: lang === 'hi' ? 'प्राथमिक (1-5)' : 'Primary (1-5)', value: info.fee_primary },
    { label: lang === 'hi' ? 'मध्य (6-8)' : 'Middle (6-8)', value: info.fee_middle },
    { label: lang === 'hi' ? 'माध्यमिक (9-10)' : 'Secondary (9-10)', value: info.fee_secondary },
    { label: lang === 'hi' ? 'वरिष्ठ माध्यमिक (11-12)' : 'Senior Secondary (11-12)', value: info.fee_senior },
  ] : [];

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'प्रवेश' : 'Admissions'}
        subtitle={lang === 'hi' ? 'सत्र 2026-27 के लिए प्रवेश खुले हैं' : 'Admissions open for the 2026-27 session'}
        breadcrumbs={[{ label: lang === 'hi' ? 'प्रवेश' : 'Admissions' }]}
      />

      {/* Process */}
      <section id="process" className="py-20">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-3">
              {lang === 'hi' ? 'प्रवेश प्रक्रिया' : 'Admission Process'}
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-10">
            <div className="bg-white rounded-3xl shadow-lg p-8 border-l-4 border-primary">
              <div className="flex items-center gap-3 mb-4">
                <FaCalendarAlt className="text-primary text-2xl" />
                <h3 className="font-display text-2xl font-bold text-ink">
                  {lang === 'hi' ? 'चरण' : 'Steps'}
                </h3>
              </div>
              <ol className="space-y-4">
                {processSteps.map((s, i) => (
                  <li key={i} className="flex items-start gap-4">
                    <span className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">{i + 1}</span>
                    <span className="text-gray-700">{s}</span>
                  </li>
                ))}
              </ol>
            </div>
            <div className="bg-white rounded-3xl shadow-lg p-8 border-l-4 border-gold">
              <div className="flex items-center gap-3 mb-4">
                <FaFileAlt className="text-gold text-2xl" />
                <h3 className="font-display text-2xl font-bold text-ink">
                  {lang === 'hi' ? 'आवश्यक दस्तावेज़' : 'Documents Required'}
                </h3>
              </div>
              <ul className="space-y-3">
                {docs.map((d, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <FaCheckCircle className="text-gold mt-1 flex-shrink-0" />
                    <span className="text-gray-700">{d}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Apply Online */}
      <section id="apply" className="py-20 bg-cream">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-3">
              {lang === 'hi' ? 'ऑनलाइन आवेदन करें' : 'Apply Online'}
            </h2>
            <p className="text-gray-600">
              {lang === 'hi' ? 'फॉर्म भरें, हम आपसे संपर्क करेंगे' : 'Fill the form below — we will reach out to you'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="form-label">{lang === 'hi' ? 'छात्र का नाम *' : "Student's Name *"}</label>
                <input required name="student_name" value={form.student_name} onChange={handleChange} className="form-input" />
              </div>
              <div>
                <label className="form-label">{lang === 'hi' ? 'जन्म तिथि' : 'Date of Birth'}</label>
                <input type="date" name="dob" value={form.dob} onChange={handleChange} className="form-input" />
              </div>
              <div>
                <label className="form-label">{lang === 'hi' ? 'लिंग' : 'Gender'}</label>
                <select name="gender" value={form.gender} onChange={handleChange} className="form-input">
                  <option value="">--</option>
                  <option value="male">{lang === 'hi' ? 'पुरुष' : 'Male'}</option>
                  <option value="female">{lang === 'hi' ? 'महिला' : 'Female'}</option>
                  <option value="other">{lang === 'hi' ? 'अन्य' : 'Other'}</option>
                </select>
              </div>
              <div>
                <label className="form-label">{lang === 'hi' ? 'किस कक्षा के लिए *' : 'Applying For Class *'}</label>
                <input required name="applying_for_class" value={form.applying_for_class} onChange={handleChange} className="form-input" placeholder={lang === 'hi' ? 'जैसे: कक्षा 6' : 'e.g. Class 6'} />
              </div>
              <div>
                <label className="form-label">{lang === 'hi' ? 'अभिभावक का नाम *' : "Parent's Name *"}</label>
                <input required name="parent_name" value={form.parent_name} onChange={handleChange} className="form-input" />
              </div>
              <div>
                <label className="form-label">{lang === 'hi' ? 'फ़ोन *' : 'Phone *'}</label>
                <input required name="phone" value={form.phone} onChange={handleChange} className="form-input" />
              </div>
              <div>
                <label className="form-label">{lang === 'hi' ? 'अभिभावक का ईमेल' : "Parent's Email"}</label>
                <input type="email" name="parent_email" value={form.parent_email} onChange={handleChange} className="form-input" />
              </div>
              <div>
                <label className="form-label">{lang === 'hi' ? 'पिछला विद्यालय' : 'Previous School'}</label>
                <input name="previous_school" value={form.previous_school} onChange={handleChange} className="form-input" />
              </div>
              <div className="md:col-span-2">
                <label className="form-label">{lang === 'hi' ? 'पता' : 'Address'}</label>
                <textarea rows={2} name="address" value={form.address} onChange={handleChange} className="form-input" />
              </div>
              <div className="md:col-span-2">
                <label className="form-label">{lang === 'hi' ? 'संदेश / प्रश्न' : 'Message / Questions'}</label>
                <textarea rows={3} name="message" value={form.message} onChange={handleChange} className="form-input" />
              </div>
            </div>

            {status.error && <p className="text-red-600 mt-4 text-sm">{status.error}</p>}
            {status.ok && (
              <p className="text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-3 mt-4 text-sm">
                {lang === 'hi' ? 'आपका आवेदन प्राप्त हो गया है। हम जल्द ही संपर्क करेंगे।' : 'Your application has been received. We will contact you shortly.'}
              </p>
            )}

            <button type="submit" disabled={status.loading} className="btn-primary mt-8 w-full md:w-auto disabled:opacity-50">
              <FaPaperPlane />
              {status.loading ? (lang === 'hi' ? 'भेजा जा रहा है...' : 'Submitting...') : (lang === 'hi' ? 'आवेदन जमा करें' : 'Submit Application')}
            </button>
          </form>
        </div>
      </section>

      {/* Fee structure */}
      <section id="fees" className="py-20">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-3">
              {lang === 'hi' ? 'शुल्क संरचना' : 'Fee Structure'}
            </h2>
            <p className="text-gray-600">
              {lang === 'hi' ? 'वार्षिक शुल्क (₹ में)' : 'Annual fees (in ₹)'}
            </p>
          </div>
          <div className="max-w-3xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden">
            <table className="w-full">
              <thead className="bg-primary text-white">
                <tr>
                  <th className="px-6 py-4 text-left font-display">{lang === 'hi' ? 'कक्षा स्तर' : 'Class Level'}</th>
                  <th className="px-6 py-4 text-right font-display">{lang === 'hi' ? 'वार्षिक शुल्क' : 'Annual Fee'}</th>
                </tr>
              </thead>
              <tbody>
                {fees.map((f, i) => (
                  <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-cream'}>
                    <td className="px-6 py-4 font-medium text-gray-800">{f.label}</td>
                    <td className="px-6 py-4 text-right">
                      <span className="inline-flex items-center font-bold text-primary text-lg">
                        <FaRupeeSign className="text-sm" /> {Number(f.value || 0).toLocaleString()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="bg-cream p-5 text-sm text-gray-600 italic">
              {lang === 'hi'
                ? '* शुल्क परिवहन, पुस्तकें और गणवेश को छोड़कर है। सटीक विवरण के लिए कार्यालय से संपर्क करें।'
                : '* Fees exclude transport, books and uniform. Contact the office for the exact breakdown.'}
            </div>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
