'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField, getTranslation } from '@/lib/i18n';
import { FaBullseye, FaEye, FaQuoteLeft, FaCheckCircle } from 'react-icons/fa';

export default function AboutPage() {
  const { lang } = useLang();
  const t = getTranslation(lang);
  const [items, setItems] = useState([]);

  useEffect(() => {
    fetch('/api/about').then(r => r.json()).then(d => setItems(d.items || []));
  }, []);

  const get = (key) => items.find(i => i.section_key === key) || null;
  const about = get('about_school');
  const mission = get('mission');
  const vision = get('vision');
  const principal = get('principal_message');

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'हमारे बारे में' : 'About Us'}
        subtitle={lang === 'hi' ? 'शिक्षा में उत्कृष्टता की 40 वर्षों की विरासत' : '40 years of excellence in education'}
        breadcrumbs={[{ label: lang === 'hi' ? 'हमारे बारे में' : 'About' }]}
      />

      {/* About school */}
      <section id="school" className="py-20">
        <div className="container-x grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <div className="section-divider mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-6 text-primary">
              {pickField(about, 'title', lang) || (lang === 'hi' ? 'हमारे विद्यालय के बारे में' : 'About Our School')}
            </h2>
            <p className="text-gray-700 leading-relaxed text-lg whitespace-pre-line">
              {pickField(about, 'content', lang) || ''}
            </p>
          </div>
          <div className="order-1 lg:order-2">
            <div className="rounded-3xl overflow-hidden shadow-2xl ring-4 ring-primary/10">
              <img src={about?.image_url || 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=800'} alt="School" className="w-full h-[400px] object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section id="mission" className="py-20 bg-cream">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary">
              {lang === 'hi' ? 'हमारा मिशन और दृष्टिकोण' : 'Our Mission & Vision'}
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-10 rounded-3xl shadow-lg border-t-4 border-primary card-hover">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6 text-3xl">
                <FaBullseye />
              </div>
              <h3 className="font-display text-2xl font-bold mb-4 text-ink">
                {pickField(mission, 'title', lang) || (lang === 'hi' ? 'हमारा मिशन' : 'Our Mission')}
              </h3>
              <p className="text-gray-700 leading-relaxed">
                {pickField(mission, 'content', lang) || ''}
              </p>
            </div>
            <div className="bg-white p-10 rounded-3xl shadow-lg border-t-4 border-gold card-hover">
              <div className="w-16 h-16 rounded-2xl bg-gold/10 text-gold flex items-center justify-center mb-6 text-3xl">
                <FaEye />
              </div>
              <h3 className="font-display text-2xl font-bold mb-4 text-ink">
                {pickField(vision, 'title', lang) || (lang === 'hi' ? 'हमारी दृष्टि' : 'Our Vision')}
              </h3>
              <p className="text-gray-700 leading-relaxed">
                {pickField(vision, 'content', lang) || ''}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Principal */}
      <section id="principal" className="py-20">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary">
              {lang === 'hi' ? 'प्रधानाचार्य का संदेश' : "Principal's Message"}
            </h2>
          </div>
          <div className="grid lg:grid-cols-3 gap-10 items-center">
            <div className="lg:col-span-1">
              <div className="relative">
                <div className="rounded-3xl overflow-hidden shadow-2xl">
                  <img
                    src={principal?.image_url || 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=600'}
                    alt="Principal"
                    className="w-full h-[450px] object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 left-6 right-6 bg-white shadow-xl rounded-2xl p-5 text-center">
                  <p className="font-display font-bold text-lg text-primary">{pickField(principal, 'title', lang) || 'Dr. Rajesh Kumar'}</p>
                  <p className="text-sm text-gray-600">{lang === 'hi' ? 'प्रधानाचार्य' : 'Principal'}</p>
                </div>
              </div>
            </div>
            <div className="lg:col-span-2 relative bg-cream rounded-3xl p-10 shadow-lg">
              <FaQuoteLeft className="text-primary/20 text-6xl mb-4" />
              <p className="text-gray-700 leading-relaxed text-lg whitespace-pre-line italic">
                {pickField(principal, 'content', lang) || ''}
              </p>
            </div>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
