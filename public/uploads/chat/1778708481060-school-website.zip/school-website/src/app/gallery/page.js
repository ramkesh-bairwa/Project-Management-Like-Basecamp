'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField } from '@/lib/i18n';
import { FaTimes, FaImage, FaPlayCircle } from 'react-icons/fa';

export default function GalleryPage() {
  const { lang } = useLang();
  const [items, setItems] = useState([]);
  const [type, setType] = useState('all'); // all | photo | video
  const [lightbox, setLightbox] = useState(null);

  useEffect(() => {
    const url = type === 'all' ? '/api/gallery' : `/api/gallery?type=${type}`;
    fetch(url).then(r => r.json()).then(d => setItems(d.items || []));
  }, [type]);

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'गैलरी' : 'Gallery'}
        subtitle={lang === 'hi' ? 'विद्यालय जीवन की झलकियाँ' : 'Glimpses of school life'}
        breadcrumbs={[{ label: lang === 'hi' ? 'गैलरी' : 'Gallery' }]}
      />

      <section className="py-20">
        <div className="container-x">
          <div className="flex justify-center gap-3 mb-12">
            {[
              { v: 'all', label: lang === 'hi' ? 'सभी' : 'All', icon: FaImage },
              { v: 'photo', label: lang === 'hi' ? 'तस्वीरें' : 'Photos', icon: FaImage },
              { v: 'video', label: lang === 'hi' ? 'वीडियो' : 'Videos', icon: FaPlayCircle },
            ].map(b => (
              <button
                key={b.v}
                onClick={() => setType(b.v)}
                className={`px-6 py-2.5 rounded-full text-sm font-semibold flex items-center gap-2 transition ${
                  type === b.v ? 'bg-primary text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:border-primary'
                }`}
              >
                <b.icon /> {b.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {items.map((g) => (
              <button
                key={g.id}
                onClick={() => setLightbox(g)}
                className="group relative aspect-square rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition"
              >
                <img
                  src={g.thumbnail_url || g.media_url}
                  alt={g.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition" />
                {g.media_type === 'video' && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <FaPlayCircle className="text-white text-5xl drop-shadow-lg" />
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 p-3 text-white text-sm font-medium opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition">
                  {pickField(g, 'title', lang)}
                </div>
              </button>
            ))}
          </div>

          {items.length === 0 && (
            <p className="text-center text-gray-500 py-20">
              {lang === 'hi' ? 'कोई आइटम नहीं।' : 'No items.'}
            </p>
          )}
        </div>
      </section>

      {/* Lightbox */}
      {lightbox && (
        <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-4" onClick={() => setLightbox(null)}>
          <button className="absolute top-4 right-4 text-white text-3xl hover:text-gold" onClick={() => setLightbox(null)}>
            <FaTimes />
          </button>
          <div className="max-w-5xl max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
            {lightbox.media_type === 'video' ? (
              <video src={lightbox.media_url} controls autoPlay className="max-h-[85vh] rounded-xl" />
            ) : (
              <img src={lightbox.media_url} alt={lightbox.title} className="max-h-[85vh] rounded-xl" />
            )}
            <p className="text-white text-center mt-4 font-display text-lg">{pickField(lightbox, 'title', lang)}</p>
          </div>
        </div>
      )}
    </SiteShell>
  );
}
