'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, SaveBar } from '@/components/admin/AdminUI';

export default function HighlightForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';

  const [data, setData] = useState({
    icon: 'FaUserGraduate', title: '', title_hi: '', number_value: '',
    description: '', description_hi: '', display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/highlights/${id}`).then(r => r.json()).then(d => d.item && setData(d.item));
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/highlights' : `/api/highlights/${id}`;
      const method = isNew ? 'POST' : 'PUT';
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) {
        const r = await res.json();
        router.replace(`/admin/highlights/${r.id}`);
      }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Highlight' : 'Edit Highlight'} back="/admin/highlights" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">React Icon Name</label>
            <input value={data.icon || ''} onChange={(e) => update('icon', e.target.value)} className="form-input font-mono" placeholder="FaUserGraduate" />
            <p className="text-xs text-gray-500 mt-1">e.g. FaUserGraduate, FaTrophy. <a target="_blank" rel="noreferrer" href="https://react-icons.github.io/react-icons/icons/fa/" className="text-primary underline">Browse icons</a></p>
          </div>
          <div>
            <label className="form-label">Number Value</label>
            <input value={data.number_value || ''} onChange={(e) => update('number_value', e.target.value)} className="form-input" placeholder="2500+" />
          </div>
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
        </div>

        <BilingualField
          label="Title"
          value={data.title} valueHi={data.title_hi}
          onChange={(v) => update('title', v)} onChangeHi={(v) => update('title_hi', v)}
        />

        <BilingualField
          label="Description"
          rows={3}
          value={data.description} valueHi={data.description_hi}
          onChange={(v) => update('description', v)} onChangeHi={(v) => update('description_hi', v)}
        />

        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 rounded text-primary" />
          <span className="text-sm">Active (visible on website)</span>
        </label>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
