'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  FaBullhorn, FaCalendarAlt, FaUserGraduate, FaEnvelope, FaImages, FaChalkboardTeacher,
  FaRunning, FaQuoteRight, FaArrowRight,
} from 'react-icons/fa';

const COUNTERS = [
  { key: 'notices', endpoint: '/api/notices?all=1', label: 'Notices', icon: FaBullhorn, color: 'from-rose-500 to-rose-700', href: '/admin/notices' },
  { key: 'events', endpoint: '/api/events?all=1', label: 'Events', icon: FaCalendarAlt, color: 'from-amber-500 to-amber-700', href: '/admin/events' },
  { key: 'apps', endpoint: '/api/admissions?type=applications', label: 'Applications', icon: FaUserGraduate, color: 'from-emerald-500 to-emerald-700', href: '/admin/admissions' },
  { key: 'msgs', endpoint: '/api/contact', label: 'Messages', icon: FaEnvelope, color: 'from-sky-500 to-sky-700', href: '/admin/messages' },
  { key: 'gallery', endpoint: '/api/gallery?all=1', label: 'Gallery', icon: FaImages, color: 'from-violet-500 to-violet-700', href: '/admin/gallery' },
  { key: 'teachers', endpoint: '/api/teachers?all=1', label: 'Teachers', icon: FaChalkboardTeacher, color: 'from-fuchsia-500 to-fuchsia-700', href: '/admin/teachers' },
  { key: 'sports', endpoint: '/api/sports?all=1', label: 'Sports', icon: FaRunning, color: 'from-teal-500 to-teal-700', href: '/admin/sports' },
  { key: 'testimonials', endpoint: '/api/testimonials?all=1', label: 'Testimonials', icon: FaQuoteRight, color: 'from-indigo-500 to-indigo-700', href: '/admin/testimonials' },
];

export default function Dashboard() {
  const [counts, setCounts] = useState({});

  useEffect(() => {
    Promise.all(COUNTERS.map(c => fetch(c.endpoint).then(r => r.ok ? r.json() : { items: [] }).catch(() => ({ items: [] }))))
      .then(results => {
        const obj = {};
        results.forEach((r, i) => {
          obj[COUNTERS[i].key] = (r.items || []).length;
        });
        setCounts(obj);
      });
  }, []);

  return (
    <div>
      <div className="mb-10">
        <h1 className="font-display text-3xl md:text-4xl font-bold text-primary">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back. Here is a quick overview.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
        {COUNTERS.map((c) => (
          <Link
            key={c.key}
            href={c.href}
            className={`group relative overflow-hidden rounded-2xl p-6 text-white bg-gradient-to-br ${c.color} shadow-lg hover:shadow-2xl hover:-translate-y-1 transition`}
          >
            <c.icon className="absolute -bottom-3 -right-3 text-7xl opacity-20" />
            <div className="text-3xl font-bold font-display">{counts[c.key] ?? '...'}</div>
            <div className="text-sm font-medium opacity-90">{c.label}</div>
            <div className="mt-4 text-xs opacity-80 flex items-center gap-1 group-hover:gap-2 transition-all">
              Manage <FaArrowRight className="text-[10px]" />
            </div>
          </Link>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-md p-8">
        <h2 className="font-display text-xl font-bold text-primary mb-4">Quick Actions</h2>
        <div className="flex flex-wrap gap-3">
          <Link href="/admin/notices/new" className="btn-primary">+ Add Notice</Link>
          <Link href="/admin/events/new" className="btn-outline">+ Add Event</Link>
          <Link href="/admin/gallery/new" className="btn-outline">+ Upload to Gallery</Link>
          <Link href="/admin/settings" className="btn-outline">Site Settings</Link>
        </div>
      </div>
    </div>
  );
}
