'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function AboutList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/about').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader
        title="About / Mission / Principal"
        subtitle="Edit the About Us, Mission, Vision, and Principal's Message sections"
        action={<Link href="/admin/about/new" className="btn-primary"><FaPlus /> Add Section</Link>}
      />
      <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-lg mb-6 text-sm text-gray-700">
        <strong>Section keys (don't change):</strong> <code className="bg-white px-1 rounded">about_school</code>, <code className="bg-white px-1 rounded">mission</code>, <code className="bg-white px-1 rounded">vision</code>, <code className="bg-white px-1 rounded">principal_message</code>. These are referenced by the website pages.
      </div>
      <AdminList items={items} basePath="/api/about" onDelete={() => load()}
        columns={[
          { key: 'section_key', label: 'Key', render: i => <code className="text-xs bg-gray-100 px-2 py-1 rounded">{i.section_key}</code> },
          { key: 'title', label: 'Title' },
          { key: 'image_url', label: 'Image', render: i => i.image_url ? <img src={i.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" /> : '—' },
        ]} />
    </div>
  );
}
