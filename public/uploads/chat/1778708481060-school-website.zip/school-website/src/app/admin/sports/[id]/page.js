'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

export default function SportForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    name: '', name_hi: '', icon: 'FaRunning', category: '',
    description: '', description_hi: '', image_url: '',
    achievements: '', achievements_hi: '', display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/sports/${id}`).then(r => r.json()).then(d => d.item && setData(d.item));
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/sports' : `/api/sports/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/sports/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Sport' : 'Edit Sport'} back="/admin/sports" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <BilingualField label="Sport Name" value={data.name} valueHi={data.name_hi}
          onChange={(v) => update('name', v)} onChangeHi={(v) => update('name_hi', v)} />

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Icon Name</label>
            <input value={data.icon || ''} onChange={(e) => update('icon', e.target.value)} className="form-input font-mono" placeholder="FaRunning or GiBasketballBall" />
            <p className="text-xs text-gray-500 mt-1">Use Fa* or Gi* (Game Icons)</p>
          </div>
          <div>
            <label className="form-label">Category</label>
            <input value={data.category || ''} onChange={(e) => update('category', e.target.value)} className="form-input" placeholder="Outdoor / Indoor / Athletics" />
          </div>
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
        </div>

        <BilingualField label="Description" rows={3} value={data.description} valueHi={data.description_hi}
          onChange={(v) => update('description', v)} onChangeHi={(v) => update('description_hi', v)} />

        <BilingualField label="Achievements / Highlights" rows={2} value={data.achievements} valueHi={data.achievements_hi}
          onChange={(v) => update('achievements', v)} onChangeHi={(v) => update('achievements_hi', v)} />

        <div>
          <label className="form-label">Image</label>
          <FileUploader value={data.image_url} onChange={(v) => update('image_url', v)} />
        </div>

        <label className="flex items-center gap-2">
          <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
          <span className="text-sm">Active</span>
        </label>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
