'use client';
import { useEffect, useState } from 'react';
import { AdminHeader } from '@/components/admin/AdminUI';
import { FaEnvelopeOpen, FaEnvelope, FaTrash, FaPhone, FaCalendarAlt } from 'react-icons/fa';

export default function MessagesAdmin() {
  const [items, setItems] = useState([]);

  const load = () => fetch('/api/contact').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  const toggleRead = async (m) => {
    await fetch('/api/contact', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: m.id, is_read: !m.is_read }) });
    load();
  };

  const remove = async (id) => {
    if (!confirm('Delete this message?')) return;
    await fetch(`/api/contact?id=${id}`, { method: 'DELETE' });
    load();
  };

  return (
    <div>
      <AdminHeader title="Contact Messages" subtitle={`${items.filter(m => !m.is_read).length} unread of ${items.length}`} />

      <div className="space-y-4">
        {items.length === 0 && (
          <div className="bg-white rounded-2xl shadow-md p-12 text-center text-gray-400">No messages yet.</div>
        )}
        {items.map(m => (
          <div key={m.id} className={`bg-white rounded-2xl shadow-md p-6 border-l-4 ${m.is_read ? 'border-gray-300' : 'border-primary'}`}>
            <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-display text-lg font-bold text-ink">{m.name}</h3>
                  {!m.is_read && <span className="text-xs bg-primary text-white px-2 py-0.5 rounded-full font-bold">NEW</span>}
                </div>
                {m.subject && <p className="text-sm font-semibold text-primary mt-1">{m.subject}</p>}
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500 mt-2">
                  <a href={`mailto:${m.email}`} className="flex items-center gap-1 hover:text-primary"><FaEnvelope /> {m.email}</a>
                  {m.phone && <a href={`tel:${m.phone}`} className="flex items-center gap-1 hover:text-primary"><FaPhone /> {m.phone}</a>}
                  <span className="flex items-center gap-1"><FaCalendarAlt /> {new Date(m.created_at).toLocaleString()}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => toggleRead(m)} className="px-3 py-1.5 text-xs rounded-lg bg-gray-100 hover:bg-gray-200 inline-flex items-center gap-1 font-semibold">
                  {m.is_read ? <><FaEnvelope /> Unread</> : <><FaEnvelopeOpen /> Read</>}
                </button>
                <button onClick={() => remove(m.id)} className="px-3 py-1.5 text-xs rounded-lg bg-red-100 text-red-700 hover:bg-red-200 inline-flex items-center gap-1 font-semibold">
                  <FaTrash /> Delete
                </button>
              </div>
            </div>
            <p className="text-gray-700 whitespace-pre-line">{m.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
