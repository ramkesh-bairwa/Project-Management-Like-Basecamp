'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function ClassesList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/classes?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader
        title="Classes"
        subtitle="Class levels offered (Nursery to 12th)"
        action={<Link href="/admin/classes/new" className="btn-primary"><FaPlus /> Add Class</Link>}
      />
      <AdminList
        items={items}
        basePath="/api/classes"
        onDelete={() => load()}
        columns={[
          { key: 'image_url', label: 'Image', render: i => i.image_url ? <img src={i.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" /> : '—' },
          { key: 'class_name', label: 'Name' },
          { key: 'age_group', label: 'Age Group' },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? '✓' : '✗' },
        ]}
      />
    </div>
  );
}
