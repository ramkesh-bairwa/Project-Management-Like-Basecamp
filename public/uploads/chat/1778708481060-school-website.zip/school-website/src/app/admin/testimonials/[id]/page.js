'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

export default function TestimonialForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    name: '', name_hi: '', role: '', role_hi: '',
    message: '', message_hi: '', rating: 5, image_url: '',
    display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/testimonials/${id}`).then(r => r.json()).then(d => d.item && setData(d.item));
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/testimonials' : `/api/testimonials/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/testimonials/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Testimonial' : 'Edit Testimonial'} back="/admin/testimonials" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <BilingualField label="Name" value={data.name} valueHi={data.name_hi}
          onChange={(v) => update('name', v)} onChangeHi={(v) => update('name_hi', v)} />

        <BilingualField label="Role / Relation" value={data.role} valueHi={data.role_hi}
          onChange={(v) => update('role', v)} onChangeHi={(v) => update('role_hi', v)} />

        <BilingualField label="Message" rows={4} value={data.message} valueHi={data.message_hi}
          onChange={(v) => update('message', v)} onChangeHi={(v) => update('message_hi', v)} />

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="form-label">Rating (1-5)</label>
            <input type="number" min="1" max="5" value={data.rating || 5} onChange={(e) => update('rating', parseInt(e.target.value) || 5)} className="form-input" />
          </div>
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
        </div>

        <div>
          <label className="form-label">Photo</label>
          <FileUploader value={data.image_url} onChange={(v) => update('image_url', v)} />
        </div>

        <label className="flex items-center gap-2">
          <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
          <span className="text-sm">Active</span>
        </label>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
