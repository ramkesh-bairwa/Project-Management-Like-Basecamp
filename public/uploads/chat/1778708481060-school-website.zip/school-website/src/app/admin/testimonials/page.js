'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function TestimonialsList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/testimonials?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader title="Testimonials" subtitle="Parent and student testimonials"
        action={<Link href="/admin/testimonials/new" className="btn-primary"><FaPlus /> Add Testimonial</Link>} />
      <AdminList items={items} basePath="/api/testimonials" onDelete={() => load()}
        columns={[
          { key: 'image_url', label: 'Photo', render: i => i.image_url ? <img src={i.image_url} alt="" className="w-12 h-12 rounded-full object-cover" /> : '—' },
          { key: 'name', label: 'Name' },
          { key: 'role', label: 'Role' },
          { key: 'rating', label: 'Rating', render: i => '★'.repeat(i.rating || 5) },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? '✓' : '✗' },
        ]} />
    </div>
  );
}
