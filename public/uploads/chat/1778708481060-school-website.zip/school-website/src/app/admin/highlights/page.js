'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function HighlightsList() {
  const [items, setItems] = useState([]);

  const load = () => fetch('/api/highlights?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader
        title="Highlights"
        subtitle="The 'Excellence in Education' stat boxes shown on the homepage"
        action={<Link href="/admin/highlights/new" className="btn-primary"><FaPlus /> Add Highlight</Link>}
      />
      <AdminList
        items={items}
        basePath="/api/highlights"
        onDelete={() => load()}
        columns={[
          { key: 'icon', label: 'Icon', render: i => <code className="text-xs bg-gray-100 px-2 py-1 rounded">{i.icon}</code> },
          { key: 'title', label: 'Title' },
          { key: 'number_value', label: 'Number', render: i => <span className="font-bold text-primary">{i.number_value}</span> },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? <span className="text-green-600">✓</span> : <span className="text-gray-400">✗</span> },
        ]}
      />
    </div>
  );
}
