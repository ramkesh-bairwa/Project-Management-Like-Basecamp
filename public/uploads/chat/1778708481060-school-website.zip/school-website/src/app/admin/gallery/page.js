'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function GalleryList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/gallery?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader title="Gallery" subtitle="Photos and videos"
        action={<Link href="/admin/gallery/new" className="btn-primary"><FaPlus /> Add Item</Link>} />
      <AdminList items={items} basePath="/api/gallery" onDelete={() => load()}
        columns={[
          { key: 'thumb', label: 'Preview', render: i => (
            <img src={i.thumbnail_url || i.media_url} alt="" className="w-16 h-12 rounded-lg object-cover" />
          ) },
          { key: 'title', label: 'Title' },
          { key: 'category', label: 'Category' },
          { key: 'media_type', label: 'Type', render: i => <span className="text-xs uppercase font-bold text-gray-500">{i.media_type}</span> },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? '✓' : '✗' },
        ]} />
    </div>
  );
}
