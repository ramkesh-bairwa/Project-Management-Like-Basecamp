'use client';
import { useEffect, useState } from 'react';
import { AdminHeader } from '@/components/admin/AdminUI';
import { FaCheck, FaTimes, FaTrash, FaSpinner, FaSave, FaEnvelope, FaPhone } from 'react-icons/fa';

export default function AdmissionsAdmin() {
  const [tab, setTab] = useState('applications');
  const [apps, setApps] = useState([]);
  const [info, setInfo] = useState(null);
  const [saving, setSaving] = useState(false);
  const [savedOk, setSavedOk] = useState(false);

  const loadApps = () => fetch('/api/admissions?type=applications').then(r => r.json()).then(d => setApps(d.items || []));
  const loadInfo = () => fetch('/api/admissions?type=info').then(r => r.json()).then(d => setInfo((d.items || [])[0] || null));

  useEffect(() => { loadApps(); loadInfo(); }, []);

  const updateStatus = async (id, status) => {
    await fetch('/api/admissions', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind: 'application', id, status }) });
    loadApps();
  };

  const removeApp = async (id) => {
    if (!confirm('Delete this application?')) return;
    await fetch(`/api/admissions?id=${id}`, { method: 'DELETE' });
    loadApps();
  };

  const saveInfo = async (e) => {
    e.preventDefault();
    setSaving(true); setSavedOk(false);
    await fetch('/api/admissions', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'info', ...info }),
    });
    setSaving(false); setSavedOk(true);
    setTimeout(() => setSavedOk(false), 3000);
  };

  const updInfo = (k, v) => setInfo(s => ({ ...s, [k]: v }));

  return (
    <div>
      <AdminHeader title="Admissions" subtitle="Applications and fee structure" />

      <div className="flex gap-2 mb-6 border-b border-gray-200">
        {[
          { v: 'applications', label: `Applications (${apps.length})` },
          { v: 'info', label: 'Process & Fees' },
        ].map(t => (
          <button
            key={t.v}
            onClick={() => setTab(t.v)}
            className={`px-5 py-3 font-semibold text-sm border-b-2 transition ${
              tab === t.v ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-primary'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'applications' && (
        <div className="space-y-4">
          {apps.length === 0 && (
            <div className="bg-white rounded-2xl shadow-md p-12 text-center text-gray-400">No applications yet.</div>
          )}
          {apps.map(a => (
            <div key={a.id} className="bg-white rounded-2xl shadow-md p-6">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                <div>
                  <h3 className="font-display text-xl font-bold text-ink">{a.student_name}</h3>
                  <p className="text-sm text-gray-500">Applying for: <span className="font-semibold text-primary">{a.applying_for_class}</span></p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-3 py-1.5 rounded-full font-bold uppercase ${
                    a.status === 'approved' ? 'bg-green-100 text-green-700' :
                    a.status === 'rejected' ? 'bg-red-100 text-red-700' :
                    a.status === 'reviewed' ? 'bg-blue-100 text-blue-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>{a.status}</span>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-x-8 gap-y-2 text-sm text-gray-700 mb-4">
                <div><span className="text-gray-500">DOB:</span> {a.dob ? new Date(a.dob).toLocaleDateString() : '—'}</div>
                <div><span className="text-gray-500">Gender:</span> {a.gender || '—'}</div>
                <div><span className="text-gray-500">Parent:</span> {a.parent_name}</div>
                <div className="flex items-center gap-2"><FaPhone className="text-primary text-xs" /> {a.phone}</div>
                {a.parent_email && <div className="flex items-center gap-2"><FaEnvelope className="text-primary text-xs" /> {a.parent_email}</div>}
                <div><span className="text-gray-500">Previous:</span> {a.previous_school || '—'}</div>
                {a.address && <div className="md:col-span-2"><span className="text-gray-500">Address:</span> {a.address}</div>}
                {a.message && <div className="md:col-span-2"><span className="text-gray-500">Note:</span> {a.message}</div>}
                <div className="md:col-span-2 text-xs text-gray-400">Submitted: {new Date(a.created_at).toLocaleString()}</div>
              </div>

              <div className="flex flex-wrap gap-2 pt-3 border-t border-gray-100">
                <button onClick={() => updateStatus(a.id, 'reviewed')} className="px-3 py-1.5 text-xs rounded-lg bg-blue-100 text-blue-700 hover:bg-blue-200 font-semibold">Mark Reviewed</button>
                <button onClick={() => updateStatus(a.id, 'approved')} className="px-3 py-1.5 text-xs rounded-lg bg-green-100 text-green-700 hover:bg-green-200 font-semibold inline-flex items-center gap-1"><FaCheck /> Approve</button>
                <button onClick={() => updateStatus(a.id, 'rejected')} className="px-3 py-1.5 text-xs rounded-lg bg-red-100 text-red-700 hover:bg-red-200 font-semibold inline-flex items-center gap-1"><FaTimes /> Reject</button>
                <button onClick={() => removeApp(a.id)} className="px-3 py-1.5 text-xs rounded-lg bg-gray-100 text-gray-600 hover:bg-gray-200 font-semibold inline-flex items-center gap-1 ml-auto"><FaTrash /> Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'info' && info && (
        <form onSubmit={saveInfo} className="space-y-6">
          <div className="bg-white rounded-2xl shadow-md p-8 space-y-6">
            <h2 className="font-display text-xl font-bold text-primary">Process & Documents</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="form-label">Process Steps (one per line, English)</label>
                <textarea value={info.process_steps || ''} onChange={(e) => updInfo('process_steps', e.target.value)} rows={6} className="form-input" />
              </div>
              <div>
                <label className="form-label">Process Steps (Hindi)</label>
                <textarea value={info.process_steps_hi || ''} onChange={(e) => updInfo('process_steps_hi', e.target.value)} rows={6} className="form-input" style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }} />
              </div>
              <div>
                <label className="form-label">Documents Required (one per line, English)</label>
                <textarea value={info.documents_required || ''} onChange={(e) => updInfo('documents_required', e.target.value)} rows={6} className="form-input" />
              </div>
              <div>
                <label className="form-label">Documents Required (Hindi)</label>
                <textarea value={info.documents_required_hi || ''} onChange={(e) => updInfo('documents_required_hi', e.target.value)} rows={6} className="form-input" style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }} />
              </div>
              <div>
                <label className="form-label">Eligibility (English)</label>
                <textarea value={info.eligibility || ''} onChange={(e) => updInfo('eligibility', e.target.value)} rows={3} className="form-input" />
              </div>
              <div>
                <label className="form-label">Eligibility (Hindi)</label>
                <textarea value={info.eligibility_hi || ''} onChange={(e) => updInfo('eligibility_hi', e.target.value)} rows={3} className="form-input" style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }} />
              </div>
              <div>
                <label className="form-label">Important Dates (English)</label>
                <textarea value={info.important_dates || ''} onChange={(e) => updInfo('important_dates', e.target.value)} rows={3} className="form-input" />
              </div>
              <div>
                <label className="form-label">Important Dates (Hindi)</label>
                <textarea value={info.important_dates_hi || ''} onChange={(e) => updInfo('important_dates_hi', e.target.value)} rows={3} className="form-input" style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }} />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-md p-8 space-y-6">
            <h2 className="font-display text-xl font-bold text-primary">Annual Fee Structure (₹)</h2>
            <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-4">
              {[
                ['fee_nursery', 'Nursery / KG'],
                ['fee_primary', 'Primary (1-5)'],
                ['fee_middle', 'Middle (6-8)'],
                ['fee_secondary', 'Secondary (9-10)'],
                ['fee_senior', 'Senior (11-12)'],
              ].map(([k, label]) => (
                <div key={k}>
                  <label className="form-label">{label}</label>
                  <input
                    type="number"
                    value={info[k] || 0}
                    onChange={(e) => updInfo(k, parseInt(e.target.value) || 0)}
                    className="form-input"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-4">
            {savedOk && <span className="text-green-600 text-sm flex items-center gap-1"><FaCheck /> Saved</span>}
            <button type="submit" disabled={saving} className="btn-primary disabled:opacity-50">
              {saving ? <FaSpinner className="animate-spin" /> : <FaSave />}
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
