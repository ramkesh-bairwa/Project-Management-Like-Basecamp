'use client';
import { useEffect, useState } from 'react';
import { AdminHeader, FileUploader, SaveBar } from '@/components/admin/AdminUI';

const FIELD_LABELS = {
  site_name: 'Site Name',
  site_tagline: 'Site Tagline',
  logo_url: 'Logo',
  favicon_url: 'Favicon',
  primary_color: 'Primary Theme Color',
  hero_video_url: 'Hero Video',
  hero_title: 'Hero Title',
  hero_subtitle: 'Hero Subtitle',
  hero_cta_text: 'Hero CTA Button Text',
  about_short: 'About (short blurb)',
  contact_phone: 'Phone',
  contact_email: 'Email',
  contact_address: 'Address',
  working_hours: 'Working Hours',
  map_embed: 'Google Maps Embed (iframe HTML)',
  footer_about: 'Footer About Text',
  social_facebook: 'Facebook URL',
  social_instagram: 'Instagram URL',
  social_youtube: 'YouTube URL',
  social_twitter: 'Twitter URL',
};

const GROUPS = [
  { title: 'General', keys: ['site_name', 'site_tagline', 'logo_url', 'favicon_url', 'primary_color'] },
  { title: 'Hero Section', keys: ['hero_video_url', 'hero_title', 'hero_subtitle', 'hero_cta_text'] },
  { title: 'Contact Info', keys: ['contact_phone', 'contact_email', 'contact_address', 'working_hours', 'map_embed'] },
  { title: 'Footer & Social', keys: ['footer_about', 'about_short', 'social_facebook', 'social_instagram', 'social_youtube', 'social_twitter'] },
];

export default function SettingsPage() {
  const [raw, setRaw] = useState([]);
  const [values, setValues] = useState({}); // { key: { value, value_hi } }
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => {
      setRaw(d.raw || []);
      const v = {};
      (d.raw || []).forEach(r => {
        v[r.setting_key] = { value: r.setting_value || '', value_hi: r.setting_value_hi || '', type: r.setting_type };
      });
      setValues(v);
    });
  }, []);

  const update = (key, field, val) => {
    setValues(s => ({ ...s, [key]: { ...s[key], [field]: val } }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const updates = Object.entries(values).map(([key, v]) => ({ key, value: v.value, value_hi: v.value_hi }));
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updates }),
      });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      setTimeout(() => setOk(false), 3000);
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const renderField = (key) => {
    const v = values[key];
    if (!v) return null;
    const type = v.type;
    const isBilingual = ['text', 'textarea', 'html'].includes(type);

    if (type === 'image' || type === 'video') {
      return (
        <div key={key}>
          <label className="form-label">{FIELD_LABELS[key] || key}</label>
          <FileUploader
            value={v.value}
            onChange={(val) => update(key, 'value', val)}
            accept={type === 'video' ? 'video/*' : 'image/*'}
          />
        </div>
      );
    }

    if (type === 'color') {
      return (
        <div key={key}>
          <label className="form-label">{FIELD_LABELS[key] || key}</label>
          <div className="flex items-center gap-3">
            <input
              type="color"
              value={v.value || '#8b1a2e'}
              onChange={(e) => update(key, 'value', e.target.value)}
              className="w-16 h-12 rounded-lg cursor-pointer border border-gray-300"
            />
            <input
              type="text"
              value={v.value || ''}
              onChange={(e) => update(key, 'value', e.target.value)}
              className="form-input flex-1 font-mono"
              placeholder="#8b1a2e"
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">Tip: changes here take effect after rebuilding the site (npm run build).</p>
        </div>
      );
    }

    if (type === 'html' || type === 'textarea') {
      return (
        <div key={key} className={isBilingual ? 'grid md:grid-cols-2 gap-4' : ''}>
          <div>
            <label className="form-label">{FIELD_LABELS[key] || key} {isBilingual && '(English)'}</label>
            <textarea
              value={v.value || ''}
              onChange={(e) => update(key, 'value', e.target.value)}
              rows={type === 'html' ? 5 : 3}
              className="form-input"
            />
          </div>
          {isBilingual && (
            <div>
              <label className="form-label">{FIELD_LABELS[key] || key} (हिंदी)</label>
              <textarea
                value={v.value_hi || ''}
                onChange={(e) => update(key, 'value_hi', e.target.value)}
                rows={type === 'html' ? 5 : 3}
                className="form-input"
                style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }}
              />
            </div>
          )}
        </div>
      );
    }

    // text
    return (
      <div key={key} className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="form-label">{FIELD_LABELS[key] || key} (English)</label>
          <input value={v.value || ''} onChange={(e) => update(key, 'value', e.target.value)} className="form-input" />
        </div>
        <div>
          <label className="form-label">{FIELD_LABELS[key] || key} (हिंदी)</label>
          <input value={v.value_hi || ''} onChange={(e) => update(key, 'value_hi', e.target.value)} className="form-input" style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }} />
        </div>
      </div>
    );
  };

  return (
    <div>
      <AdminHeader title="Site Settings" subtitle="Manage everything that appears on your website" />
      <form onSubmit={submit} className="space-y-8">
        {GROUPS.map(g => (
          <div key={g.title} className="bg-white rounded-2xl shadow-md p-8">
            <h2 className="font-display text-xl font-bold text-primary mb-6 pb-3 border-b border-gray-100">{g.title}</h2>
            <div className="space-y-5">
              {g.keys.map(k => renderField(k))}
            </div>
          </div>
        ))}

        {/* Catch-all for any settings not in the predefined groups */}
        {raw.filter(r => !GROUPS.flatMap(g => g.keys).includes(r.setting_key)).length > 0 && (
          <div className="bg-white rounded-2xl shadow-md p-8">
            <h2 className="font-display text-xl font-bold text-primary mb-6 pb-3 border-b border-gray-100">Other</h2>
            <div className="space-y-5">
              {raw.filter(r => !GROUPS.flatMap(g => g.keys).includes(r.setting_key)).map(r => renderField(r.setting_key))}
            </div>
          </div>
        )}

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
