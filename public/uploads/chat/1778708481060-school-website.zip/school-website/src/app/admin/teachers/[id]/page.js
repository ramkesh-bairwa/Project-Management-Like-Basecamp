'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

export default function TeacherForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    name: '', name_hi: '', designation: '', designation_hi: '',
    qualification: '', qualification_hi: '', department: '', experience_years: 0,
    image_url: '', email: '', bio: '', bio_hi: '', display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/teachers/${id}`).then(r => r.json()).then(d => d.item && setData(d.item));
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/teachers' : `/api/teachers/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/teachers/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Teacher' : 'Edit Teacher'} back="/admin/teachers" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <BilingualField label="Name" value={data.name} valueHi={data.name_hi}
          onChange={(v) => update('name', v)} onChangeHi={(v) => update('name_hi', v)} />

        <BilingualField label="Designation" value={data.designation} valueHi={data.designation_hi}
          onChange={(v) => update('designation', v)} onChangeHi={(v) => update('designation_hi', v)} />

        <BilingualField label="Qualification" value={data.qualification} valueHi={data.qualification_hi}
          onChange={(v) => update('qualification', v)} onChangeHi={(v) => update('qualification_hi', v)} />

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Department</label>
            <input value={data.department || ''} onChange={(e) => update('department', e.target.value)} className="form-input" />
          </div>
          <div>
            <label className="form-label">Experience (years)</label>
            <input type="number" value={data.experience_years ?? 0} onChange={(e) => update('experience_years', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
        </div>

        <div>
          <label className="form-label">Email</label>
          <input type="email" value={data.email || ''} onChange={(e) => update('email', e.target.value)} className="form-input" />
        </div>

        <BilingualField label="Bio" rows={3} value={data.bio} valueHi={data.bio_hi}
          onChange={(v) => update('bio', v)} onChangeHi={(v) => update('bio_hi', v)} />

        <div>
          <label className="form-label">Photo</label>
          <FileUploader value={data.image_url} onChange={(v) => update('image_url', v)} />
        </div>

        <label className="flex items-center gap-2">
          <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
          <span className="text-sm">Active</span>
        </label>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
