'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function NoticesList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/notices?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader title="Notices" subtitle="Notices, announcements, news"
        action={<Link href="/admin/notices/new" className="btn-primary"><FaPlus /> Add Notice</Link>} />
      <AdminList items={items} basePath="/api/notices" onDelete={() => load()}
        columns={[
          { key: 'title', label: 'Title' },
          { key: 'category', label: 'Category', render: i => <span className="capitalize text-xs bg-gray-100 px-2 py-1 rounded">{i.category}</span> },
          { key: 'notice_date', label: 'Date', render: i => new Date(i.notice_date).toLocaleDateString() },
          { key: 'is_important', label: 'Important', render: i => i.is_important ? '⭐' : '' },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? '✓' : '✗' },
        ]} />
    </div>
  );
}
