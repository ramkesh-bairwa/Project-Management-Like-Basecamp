'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

export default function ClassForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    class_name: '', class_name_hi: '', age_group: '', description: '', description_hi: '',
    image_url: '', display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/classes/${id}`).then(r => r.json()).then(d => d.item && setData(d.item));
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/classes' : `/api/classes/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/classes/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Class' : 'Edit Class'} back="/admin/classes" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <BilingualField label="Class Name" value={data.class_name} valueHi={data.class_name_hi}
          onChange={(v) => update('class_name', v)} onChangeHi={(v) => update('class_name_hi', v)} />

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="form-label">Age Group</label>
            <input value={data.age_group || ''} onChange={(e) => update('age_group', e.target.value)} className="form-input" placeholder="3-5 years" />
          </div>
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
        </div>

        <BilingualField label="Description" rows={3} value={data.description} valueHi={data.description_hi}
          onChange={(v) => update('description', v)} onChangeHi={(v) => update('description_hi', v)} />

        <div>
          <label className="form-label">Class Image</label>
          <FileUploader value={data.image_url} onChange={(v) => update('image_url', v)} />
        </div>

        <label className="flex items-center gap-2">
          <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
          <span className="text-sm">Active</span>
        </label>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
