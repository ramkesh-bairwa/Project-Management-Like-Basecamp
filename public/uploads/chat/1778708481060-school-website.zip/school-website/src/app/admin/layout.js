'use client';
import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  FaTachometerAlt, FaCog, FaStar, FaInfoCircle, FaGraduationCap, FaFlask, FaChalkboardTeacher,
  FaBullhorn, FaCalendarAlt, FaImages, FaQuoteRight, FaRunning, FaUserGraduate, FaEnvelopeOpen,
  FaSignOutAlt, FaUserCircle, FaExternalLinkAlt, FaBars, FaTimes,
} from 'react-icons/fa';

const NAV = [
  { href: '/admin/dashboard', label: 'Dashboard', icon: FaTachometerAlt },
  { href: '/admin/settings', label: 'Site Settings', icon: FaCog },
  { href: '/admin/highlights', label: 'Highlights', icon: FaStar },
  { href: '/admin/about', label: 'About / Mission', icon: FaInfoCircle },
  { href: '/admin/classes', label: 'Classes', icon: FaGraduationCap },
  { href: '/admin/streams', label: 'Streams', icon: FaFlask },
  { href: '/admin/teachers', label: 'Teachers', icon: FaChalkboardTeacher },
  { href: '/admin/notices', label: 'Notices', icon: FaBullhorn },
  { href: '/admin/events', label: 'Events', icon: FaCalendarAlt },
  { href: '/admin/gallery', label: 'Gallery', icon: FaImages },
  { href: '/admin/sports', label: 'Sports', icon: FaRunning },
  { href: '/admin/testimonials', label: 'Testimonials', icon: FaQuoteRight },
  { href: '/admin/admissions', label: 'Admissions', icon: FaUserGraduate },
  { href: '/admin/messages', label: 'Messages', icon: FaEnvelopeOpen },
];

export default function AdminLayout({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isLogin = pathname === '/admin/login';

  useEffect(() => {
    if (isLogin) { setLoading(false); return; }
    fetch('/api/auth/me')
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(d => setUser(d.user))
      .catch(() => router.push('/admin/login'))
      .finally(() => setLoading(false));
  }, [isLogin, router]);

  if (isLogin) return children;

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-primary">Loading...</div>;
  }

  if (!user) return null;

  const logout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/admin/login');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile menu toggle */}
      <button
        className="lg:hidden fixed top-4 left-4 z-50 bg-primary text-white w-10 h-10 rounded-lg flex items-center justify-center shadow-lg"
        onClick={() => setSidebarOpen(!sidebarOpen)}
      >
        {sidebarOpen ? <FaTimes /> : <FaBars />}
      </button>

      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-gradient-to-b from-primary-900 to-primary-800 text-white flex flex-col shadow-2xl transition-transform ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        <div className="p-6 border-b border-white/10">
          <Link href="/admin/dashboard" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gold flex items-center justify-center text-primary font-bold">A</div>
            <div>
              <div className="font-display font-bold text-lg leading-none">Admin Panel</div>
              <div className="text-[11px] text-white/70 mt-1">School Management</div>
            </div>
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {NAV.map(n => {
            const active = pathname === n.href || pathname.startsWith(n.href + '/');
            return (
              <Link
                key={n.href}
                href={n.href}
                onClick={() => setSidebarOpen(false)}
                className={`admin-sidebar-link ${active ? 'active' : ''}`}
              >
                <n.icon className="text-base" />
                <span>{n.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10 space-y-2">
          <Link href="/" target="_blank" className="flex items-center gap-2 text-sm text-white/80 hover:text-gold transition">
            <FaExternalLinkAlt className="text-xs" /> View Website
          </Link>
          <div className="flex items-center gap-3 pt-2">
            <FaUserCircle className="text-2xl text-gold" />
            <div className="flex-1">
              <div className="text-sm font-semibold leading-tight">{user.full_name || user.username}</div>
              <div className="text-[11px] text-white/70 capitalize">{user.role}</div>
            </div>
            <button onClick={logout} className="w-9 h-9 rounded-lg bg-white/10 hover:bg-red-500 flex items-center justify-center transition" title="Logout">
              <FaSignOutAlt />
            </button>
          </div>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 bg-black/50 z-30" onClick={() => setSidebarOpen(false)} />
      )}

      <main className="flex-1 min-w-0">
        <div className="p-6 lg:p-10">{children}</div>
      </main>
    </div>
  );
}
