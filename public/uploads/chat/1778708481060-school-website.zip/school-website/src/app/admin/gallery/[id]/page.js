'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

export default function GalleryForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    title: '', title_hi: '', category: 'general', media_type: 'photo',
    media_url: '', thumbnail_url: '', display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/gallery/${id}`).then(r => r.json()).then(d => d.item && setData(d.item));
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/gallery' : `/api/gallery/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/gallery/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Gallery Item' : 'Edit Gallery Item'} back="/admin/gallery" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <BilingualField label="Title" value={data.title} valueHi={data.title_hi}
          onChange={(v) => update('title', v)} onChangeHi={(v) => update('title_hi', v)} />

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Category</label>
            <input value={data.category || ''} onChange={(e) => update('category', e.target.value)} className="form-input" placeholder="events, sports, classroom..." />
          </div>
          <div>
            <label className="form-label">Media Type</label>
            <select value={data.media_type || 'photo'} onChange={(e) => update('media_type', e.target.value)} className="form-input">
              <option value="photo">Photo</option>
              <option value="video">Video</option>
            </select>
          </div>
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
        </div>

        <div>
          <label className="form-label">Media File / URL</label>
          <FileUploader value={data.media_url} onChange={(v) => update('media_url', v)} accept={data.media_type === 'video' ? 'video/*' : 'image/*'} />
        </div>

        {data.media_type === 'video' && (
          <div>
            <label className="form-label">Video Thumbnail (optional)</label>
            <FileUploader value={data.thumbnail_url} onChange={(v) => update('thumbnail_url', v)} accept="image/*" />
          </div>
        )}

        <label className="flex items-center gap-2">
          <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
          <span className="text-sm">Active</span>
        </label>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
