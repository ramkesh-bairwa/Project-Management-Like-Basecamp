'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function StreamsList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/streams?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader title="Streams" subtitle="Class 11-12 streams (Science, Commerce, Arts)"
        action={<Link href="/admin/streams/new" className="btn-primary"><FaPlus /> Add Stream</Link>} />
      <AdminList items={items} basePath="/api/streams" onDelete={() => load()}
        columns={[
          { key: 'image_url', label: 'Image', render: i => i.image_url ? <img src={i.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" /> : '—' },
          { key: 'icon', label: 'Icon', render: i => <code className="text-xs bg-gray-100 px-2 py-1 rounded">{i.icon}</code> },
          { key: 'name', label: 'Name' },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? '✓' : '✗' },
        ]} />
    </div>
  );
}
