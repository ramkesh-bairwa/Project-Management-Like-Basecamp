'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

const CATEGORIES = ['general', 'academic', 'sports', 'holiday', 'admission', 'event'];

export default function NoticeForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    title: '', title_hi: '', content: '', content_hi: '',
    category: 'general', notice_date: new Date().toISOString().slice(0, 10),
    is_important: 0, attachment_url: '', display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/notices/${id}`).then(r => r.json()).then(d => {
      if (d.item) {
        const it = { ...d.item };
        if (it.notice_date) it.notice_date = new Date(it.notice_date).toISOString().slice(0, 10);
        setData(it);
      }
    });
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/notices' : `/api/notices/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/notices/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Notice' : 'Edit Notice'} back="/admin/notices" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <BilingualField label="Title" value={data.title} valueHi={data.title_hi}
          onChange={(v) => update('title', v)} onChangeHi={(v) => update('title_hi', v)} />

        <BilingualField label="Content" rows={5} value={data.content} valueHi={data.content_hi}
          onChange={(v) => update('content', v)} onChangeHi={(v) => update('content_hi', v)} />

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Category</label>
            <select value={data.category || 'general'} onChange={(e) => update('category', e.target.value)} className="form-input">
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Notice Date</label>
            <input type="date" value={data.notice_date || ''} onChange={(e) => update('notice_date', e.target.value)} className="form-input" />
          </div>
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
        </div>

        <div>
          <label className="form-label">Attachment (optional)</label>
          <FileUploader value={data.attachment_url} onChange={(v) => update('attachment_url', v)} accept="*/*" />
        </div>

        <div className="flex flex-wrap gap-6">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={!!data.is_important} onChange={(e) => update('is_important', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
            <span className="text-sm">Mark as Important</span>
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
            <span className="text-sm">Active</span>
          </label>
        </div>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
