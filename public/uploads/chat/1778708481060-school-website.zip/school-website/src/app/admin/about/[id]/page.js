'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

export default function AboutForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    section_key: '', title: '', title_hi: '',
    content: '', content_hi: '', image_url: '',
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/about/${id}`).then(r => r.json()).then(d => d.item && setData(d.item));
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/about' : `/api/about/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/about/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add About Section' : 'Edit About Section'} back="/admin/about" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <div>
          <label className="form-label">Section Key</label>
          <input
            value={data.section_key || ''}
            onChange={(e) => update('section_key', e.target.value)}
            className="form-input font-mono"
            placeholder="about_school | mission | vision | principal_message"
            disabled={!isNew}
          />
          <p className="text-xs text-gray-500 mt-1">Cannot be changed after creation. Used by the website to find this content.</p>
        </div>

        <BilingualField label="Title" value={data.title} valueHi={data.title_hi}
          onChange={(v) => update('title', v)} onChangeHi={(v) => update('title_hi', v)} />

        <BilingualField label="Content" rows={8} value={data.content} valueHi={data.content_hi}
          onChange={(v) => update('content', v)} onChangeHi={(v) => update('content_hi', v)} />

        <div>
          <label className="form-label">Image</label>
          <FileUploader value={data.image_url} onChange={(v) => update('image_url', v)} />
        </div>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
