'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function TeachersList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/teachers?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader title="Teachers" subtitle="Faculty members"
        action={<Link href="/admin/teachers/new" className="btn-primary"><FaPlus /> Add Teacher</Link>} />
      <AdminList items={items} basePath="/api/teachers" onDelete={() => load()}
        columns={[
          { key: 'image_url', label: 'Photo', render: i => i.image_url ? <img src={i.image_url} alt="" className="w-12 h-12 rounded-full object-cover" /> : '—' },
          { key: 'name', label: 'Name' },
          { key: 'designation', label: 'Designation' },
          { key: 'department', label: 'Department' },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? '✓' : '✗' },
        ]} />
    </div>
  );
}
