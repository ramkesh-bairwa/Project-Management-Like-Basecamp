'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AdminHeader, AdminList, FaPlus } from '@/components/admin/AdminUI';

export default function EventsList() {
  const [items, setItems] = useState([]);
  const load = () => fetch('/api/events?all=1').then(r => r.json()).then(d => setItems(d.items || []));
  useEffect(() => { load(); }, []);

  return (
    <div>
      <AdminHeader title="Events" subtitle="School events"
        action={<Link href="/admin/events/new" className="btn-primary"><FaPlus /> Add Event</Link>} />
      <AdminList items={items} basePath="/api/events" onDelete={() => load()}
        columns={[
          { key: 'image_url', label: 'Image', render: i => i.image_url ? <img src={i.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" /> : '—' },
          { key: 'title', label: 'Title' },
          { key: 'event_date', label: 'Date', render: i => new Date(i.event_date).toLocaleDateString() },
          { key: 'venue', label: 'Venue' },
          { key: 'is_active', label: 'Active', render: i => i.is_active ? '✓' : '✗' },
        ]} />
    </div>
  );
}
