'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { AdminHeader, BilingualField, FileUploader, SaveBar } from '@/components/admin/AdminUI';

export default function EventForm() {
  const { id } = useParams();
  const router = useRouter();
  const isNew = id === 'new';
  const [data, setData] = useState({
    title: '', title_hi: '', description: '', description_hi: '',
    event_date: new Date().toISOString().slice(0, 10), event_time: '',
    venue: '', venue_hi: '', category: 'general', image_url: '',
    display_order: 0, is_active: 1,
  });
  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/events/${id}`).then(r => r.json()).then(d => {
      if (d.item) {
        const it = { ...d.item };
        if (it.event_date) it.event_date = new Date(it.event_date).toISOString().slice(0, 10);
        setData(it);
      }
    });
  }, [id, isNew]);

  const update = (k, v) => setData(s => ({ ...s, [k]: v }));
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setOk(false); setError('');
    try {
      const url = isNew ? '/api/events' : `/api/events/${id}`;
      const res = await fetch(url, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('Save failed');
      setOk(true);
      if (isNew) { const r = await res.json(); router.replace(`/admin/events/${r.id}`); }
      setTimeout(() => setOk(false), 3000);
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div>
      <AdminHeader title={isNew ? 'Add Event' : 'Edit Event'} back="/admin/events" />
      <form onSubmit={submit} className="bg-white rounded-2xl shadow-md p-8 space-y-6">
        <BilingualField label="Title" value={data.title} valueHi={data.title_hi}
          onChange={(v) => update('title', v)} onChangeHi={(v) => update('title_hi', v)} />

        <BilingualField label="Description" rows={4} value={data.description} valueHi={data.description_hi}
          onChange={(v) => update('description', v)} onChangeHi={(v) => update('description_hi', v)} />

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Event Date</label>
            <input type="date" value={data.event_date || ''} onChange={(e) => update('event_date', e.target.value)} className="form-input" />
          </div>
          <div>
            <label className="form-label">Event Time</label>
            <input type="text" value={data.event_time || ''} onChange={(e) => update('event_time', e.target.value)} className="form-input" placeholder="9:00 AM - 12:00 PM" />
          </div>
          <div>
            <label className="form-label">Category</label>
            <input value={data.category || 'general'} onChange={(e) => update('category', e.target.value)} className="form-input" />
          </div>
        </div>

        <BilingualField label="Venue" value={data.venue} valueHi={data.venue_hi}
          onChange={(v) => update('venue', v)} onChangeHi={(v) => update('venue_hi', v)} />

        <div>
          <label className="form-label">Image</label>
          <FileUploader value={data.image_url} onChange={(v) => update('image_url', v)} />
        </div>

        <div className="grid md:grid-cols-2 gap-4 items-end">
          <div>
            <label className="form-label">Display Order</label>
            <input type="number" value={data.display_order ?? 0} onChange={(e) => update('display_order', parseInt(e.target.value) || 0)} className="form-input" />
          </div>
          <label className="flex items-center gap-2 mb-3">
            <input type="checkbox" checked={!!data.is_active} onChange={(e) => update('is_active', e.target.checked ? 1 : 0)} className="w-4 h-4 text-primary" />
            <span className="text-sm">Active</span>
          </label>
        </div>

        <SaveBar saving={saving} ok={ok} error={error} />
      </form>
    </div>
  );
}
