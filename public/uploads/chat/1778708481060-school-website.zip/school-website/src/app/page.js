import SiteShell from '@/components/layout/SiteShell';
import Hero from '@/components/home/Hero';
import Highlights from '@/components/home/Highlights';
import AboutSection from '@/components/home/AboutSection';
import AcademicsSection from '@/components/home/AcademicsSection';
import WhyChooseUs from '@/components/home/WhyChooseUs';
import NoticeBoard from '@/components/home/NoticeBoard';
import EventsSection from '@/components/home/EventsSection';
import GallerySection from '@/components/home/GallerySection';
import SportsSection from '@/components/home/SportsSection';
import Testimonials from '@/components/home/Testimonials';
import CTASection from '@/components/home/CTASection';

export default function HomePage() {
  return (
    <SiteShell>
      <Hero />
      <Highlights />
      <AboutSection />
      <AcademicsSection />
      <WhyChooseUs />
      <NoticeBoard />
      <EventsSection />
      <GallerySection />
      <SportsSection />
      <Testimonials />
      <CTASection />
    </SiteShell>
  );
}
