'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField } from '@/lib/i18n';
import * as FaIcons from 'react-icons/fa';
import { FaBookOpen, FaCheckCircle } from 'react-icons/fa';

const Icon = ({ name, ...rest }) => {
  const I = FaIcons[name] || FaIcons.FaGraduationCap;
  return <I {...rest} />;
};

export default function AcademicsPage() {
  const { lang } = useLang();
  const [classes, setClasses] = useState([]);
  const [streams, setStreams] = useState([]);

  useEffect(() => {
    fetch('/api/classes').then(r => r.json()).then(d => setClasses(d.items || []));
    fetch('/api/streams').then(r => r.json()).then(d => setStreams(d.items || []));
  }, []);

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'शिक्षण' : 'Academics'}
        subtitle={lang === 'hi' ? 'सर्वांगीण विकास के लिए व्यापक पाठ्यक्रम' : 'A comprehensive curriculum for holistic development'}
        breadcrumbs={[{ label: lang === 'hi' ? 'शिक्षण' : 'Academics' }]}
      />

      {/* Classes */}
      <section id="classes" className="py-20">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-3">
              {lang === 'hi' ? 'कक्षाएँ (नर्सरी से 12वीं)' : 'Classes (Nursery to 12th)'}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              {lang === 'hi'
                ? 'प्रारंभिक बचपन से वरिष्ठ माध्यमिक तक — हर स्तर पर गुणवत्तापूर्ण शिक्षा'
                : 'From early childhood to senior secondary — quality education at every stage'}
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {classes.map((c) => (
              <div key={c.id} className="group bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-md card-hover">
                <div className="relative h-48">
                  <img src={c.image_url || 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600'} alt="" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/20 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <h3 className="font-display text-2xl font-bold">{pickField(c, 'class_name', lang)}</h3>
                    {c.age_group && <p className="text-sm text-white/90">{c.age_group}</p>}
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 text-sm leading-relaxed">{pickField(c, 'description', lang)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Streams */}
      <section id="streams" className="py-20 bg-cream">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-3">
              {lang === 'hi' ? 'धाराएँ (कक्षा 11-12)' : 'Streams (Class 11-12)'}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              {lang === 'hi' ? 'अपनी रुचि और करियर लक्ष्य के अनुसार चुनें' : 'Choose according to your interest and career goals'}
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {streams.map((s) => (
              <div key={s.id} className="bg-white rounded-3xl shadow-lg overflow-hidden card-hover">
                <div className="relative h-56">
                  <img src={s.image_url || 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=600'} alt="" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  <div className="absolute top-4 right-4 w-14 h-14 rounded-full bg-gold text-white flex items-center justify-center text-2xl shadow-lg">
                    <Icon name={s.icon || 'FaFlask'} />
                  </div>
                  <h3 className="absolute bottom-4 left-4 font-display text-2xl font-bold text-white">{pickField(s, 'name', lang)}</h3>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 mb-4">{pickField(s, 'description', lang)}</p>
                  {s.subjects && (
                    <div>
                      <p className="font-semibold text-sm text-primary mb-2">
                        {lang === 'hi' ? 'विषय:' : 'Subjects:'}
                      </p>
                      <p className="text-sm text-gray-600">{pickField(s, 'subjects', lang)}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Curriculum */}
      <section id="curriculum" className="py-20">
        <div className="container-x">
          <div className="text-center mb-12">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-3">
              {lang === 'hi' ? 'पाठ्यक्रम' : 'Curriculum'}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              {lang === 'hi' ? 'CBSE मान्यता प्राप्त सर्वांगीण पाठ्यक्रम' : 'CBSE-affiliated holistic curriculum'}
            </p>
          </div>
          <div className="bg-gradient-to-br from-primary to-primary-800 text-white rounded-3xl p-10 md:p-14 shadow-2xl">
            <div className="grid md:grid-cols-2 gap-10">
              <div>
                <FaBookOpen className="text-gold text-4xl mb-4" />
                <h3 className="font-display text-2xl font-bold mb-4">
                  {lang === 'hi' ? 'शैक्षणिक उत्कृष्टता' : 'Academic Excellence'}
                </h3>
                <ul className="space-y-3">
                  {(lang === 'hi'
                    ? ['CBSE मान्यता प्राप्त पाठ्यक्रम', 'अनुभवी शिक्षकगण', 'आधुनिक शिक्षण विधियाँ', 'नियमित मूल्यांकन', 'व्यक्तिगत ध्यान']
                    : ['CBSE-affiliated curriculum', 'Experienced faculty', 'Modern teaching methods', 'Regular assessments', 'Personalised attention']
                  ).map((x, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <FaCheckCircle className="text-gold mt-1 flex-shrink-0" />
                      <span>{x}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <FaBookOpen className="text-gold text-4xl mb-4" />
                <h3 className="font-display text-2xl font-bold mb-4">
                  {lang === 'hi' ? 'सह-पाठ्यक्रम गतिविधियाँ' : 'Co-Curricular Activities'}
                </h3>
                <ul className="space-y-3">
                  {(lang === 'hi'
                    ? ['कला और शिल्प', 'संगीत और नृत्य', 'खेल और शारीरिक शिक्षा', 'विज्ञान प्रदर्शनी', 'वाद-विवाद और सार्वजनिक भाषण']
                    : ['Arts & crafts', 'Music & dance', 'Sports & physical education', 'Science exhibitions', 'Debate & public speaking']
                  ).map((x, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <FaCheckCircle className="text-gold mt-1 flex-shrink-0" />
                      <span>{x}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
