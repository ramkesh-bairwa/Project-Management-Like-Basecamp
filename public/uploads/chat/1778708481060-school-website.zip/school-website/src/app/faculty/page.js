'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField } from '@/lib/i18n';
import { FaEnvelope, FaGraduationCap } from 'react-icons/fa';

export default function FacultyPage() {
  const { lang } = useLang();
  const [teachers, setTeachers] = useState([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetch('/api/teachers').then(r => r.json()).then(d => setTeachers(d.items || []));
  }, []);

  const departments = ['all', ...new Set(teachers.map(t => t.department).filter(Boolean))];
  const filtered = filter === 'all' ? teachers : teachers.filter(t => t.department === filter);

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'शिक्षकगण' : 'Our Faculty'}
        subtitle={lang === 'hi' ? 'अनुभवी और समर्पित शिक्षक' : 'Experienced and dedicated teachers'}
        breadcrumbs={[{ label: lang === 'hi' ? 'शिक्षकगण' : 'Faculty' }]}
      />

      <section className="py-20">
        <div className="container-x">
          {departments.length > 2 && (
            <div className="flex flex-wrap gap-3 justify-center mb-12">
              {departments.map(d => (
                <button
                  key={d}
                  onClick={() => setFilter(d)}
                  className={`px-5 py-2 rounded-full text-sm font-semibold transition ${
                    filter === d ? 'bg-primary text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:border-primary'
                  }`}
                >
                  {d === 'all' ? (lang === 'hi' ? 'सभी' : 'All') : d}
                </button>
              ))}
            </div>
          )}

          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filtered.map((t) => (
              <div key={t.id} className="group bg-white rounded-2xl overflow-hidden shadow-md card-hover">
                <div className="relative h-72 overflow-hidden">
                  <img
                    src={t.image_url || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400'}
                    alt={t.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition" />
                  {t.email && (
                    <a
                      href={`mailto:${t.email}`}
                      className="absolute bottom-4 left-4 right-4 bg-gold text-white text-center py-2 rounded-lg text-sm font-semibold opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition"
                    >
                      <FaEnvelope className="inline mr-2" /> {lang === 'hi' ? 'संपर्क करें' : 'Contact'}
                    </a>
                  )}
                </div>
                <div className="p-5 text-center">
                  <h3 className="font-display text-lg font-bold text-ink">{pickField(t, 'name', lang)}</h3>
                  <p className="text-primary text-sm font-medium mb-2">{pickField(t, 'designation', lang)}</p>
                  {t.qualification && (
                    <p className="text-gray-500 text-xs flex items-center justify-center gap-1">
                      <FaGraduationCap /> {pickField(t, 'qualification', lang)}
                    </p>
                  )}
                  {t.experience_years > 0 && (
                    <p className="text-xs text-gray-400 mt-2">
                      {t.experience_years} {lang === 'hi' ? 'वर्ष का अनुभव' : 'years experience'}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="text-center text-gray-500 py-20">
              {lang === 'hi' ? 'कोई शिक्षक नहीं मिले।' : 'No teachers found.'}
            </p>
          )}
        </div>
      </section>
    </SiteShell>
  );
}
