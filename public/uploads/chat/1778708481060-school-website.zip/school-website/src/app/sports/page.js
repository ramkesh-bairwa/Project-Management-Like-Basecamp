'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField } from '@/lib/i18n';
import * as FaIcons from 'react-icons/fa';
import * as GiIcons from 'react-icons/gi';
import { FaTrophy } from 'react-icons/fa';

const Icon = ({ name, ...rest }) => {
  const I = FaIcons[name] || GiIcons[name] || FaIcons.FaRunning;
  return <I {...rest} />;
};

export default function SportsPage() {
  const { lang } = useLang();
  const [sports, setSports] = useState([]);

  useEffect(() => {
    fetch('/api/sports').then(r => r.json()).then(d => setSports(d.items || []));
  }, []);

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'खेल' : 'Sports'}
        subtitle={lang === 'hi' ? 'स्वस्थ शरीर, स्वस्थ मन' : 'Healthy body, healthy mind'}
        breadcrumbs={[{ label: lang === 'hi' ? 'खेल' : 'Sports' }]}
      />

      <section className="py-20">
        <div className="container-x">
          <div className="text-center mb-12 max-w-3xl mx-auto">
            <div className="section-divider mx-auto mb-4" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-3">
              {lang === 'hi' ? 'हमारी खेल सुविधाएँ' : 'Our Sports Programs'}
            </h2>
            <p className="text-gray-600">
              {lang === 'hi'
                ? 'अंतर्विद्यालय और राज्य स्तरीय प्रतियोगिताओं में भाग लेने के लिए विश्व-स्तरीय कोचिंग और सुविधाएँ।'
                : 'World-class coaching and facilities to compete at inter-school and state-level tournaments.'}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sports.map((s) => (
              <div key={s.id} className="bg-white rounded-3xl shadow-md overflow-hidden card-hover">
                <div className="relative h-56">
                  <img src={s.image_url || 'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=600'} alt="" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  <div className="absolute top-4 right-4 w-14 h-14 rounded-full bg-gold text-white flex items-center justify-center text-2xl shadow-lg">
                    <Icon name={s.icon} />
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <h3 className="font-display text-xl font-bold">{pickField(s, 'name', lang)}</h3>
                    {s.category && (
                      <span className="text-xs bg-white/20 backdrop-blur px-2 py-0.5 rounded-full">{s.category}</span>
                    )}
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 text-sm mb-4">{pickField(s, 'description', lang)}</p>
                  {pickField(s, 'achievements', lang) && (
                    <div className="bg-gold/10 border border-gold/30 rounded-xl p-3 flex items-start gap-2">
                      <FaTrophy className="text-gold mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-ink">{pickField(s, 'achievements', lang)}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {sports.length === 0 && (
            <p className="text-center text-gray-500 py-10">
              {lang === 'hi' ? 'अभी कोई खेल नहीं जोड़े गए।' : 'No sports added yet.'}
            </p>
          )}
        </div>
      </section>
    </SiteShell>
  );
}
