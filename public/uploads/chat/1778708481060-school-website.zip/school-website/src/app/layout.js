import './globals.css';
import { LangProvider } from '@/lib/LangContext';

export const metadata = {
  title: 'St. Heritage Public School - Excellence in Education',
  description: 'A premier educational institution committed to nurturing future leaders through holistic education, modern facilities, and dedicated faculty.',
  keywords: 'school, education, CBSE, admissions, primary school, senior secondary',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <LangProvider>{children}</LangProvider>
      </body>
    </html>
  );
}
