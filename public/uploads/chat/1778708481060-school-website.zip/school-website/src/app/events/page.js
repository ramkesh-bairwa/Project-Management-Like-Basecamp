'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField } from '@/lib/i18n';
import { FaClock, FaMapMarkerAlt, FaCalendarAlt } from 'react-icons/fa';

export default function EventsPage() {
  const { lang } = useLang();
  const [filter, setFilter] = useState('all'); // all | upcoming | past
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const url = filter === 'all' ? '/api/events' : `/api/events?filter=${filter}`;
    fetch(url).then(r => r.json()).then(d => setEvents(d.items || []));
  }, [filter]);

  const labels = {
    en: { all: 'All Events', upcoming: 'Upcoming', past: 'Past' },
    hi: { all: 'सभी कार्यक्रम', upcoming: 'आगामी', past: 'विगत' },
  };

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'कार्यक्रम' : 'Events'}
        subtitle={lang === 'hi' ? 'विद्यालय में आयोजित होने वाले कार्यक्रम' : 'Events held at our school'}
        breadcrumbs={[{ label: lang === 'hi' ? 'कार्यक्रम' : 'Events' }]}
      />

      <section className="py-20">
        <div className="container-x">
          <div className="flex justify-center gap-3 mb-12">
            {['all', 'upcoming', 'past'].map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-6 py-2.5 rounded-full text-sm font-semibold transition ${
                  filter === f ? 'bg-primary text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:border-primary'
                }`}
              >
                {labels[lang][f]}
              </button>
            ))}
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {events.map((e) => {
              const d = new Date(e.event_date);
              const day = d.getDate();
              const month = d.toLocaleString(lang === 'hi' ? 'hi-IN' : 'en-US', { month: 'short' });
              return (
                <div key={e.id} className="bg-white rounded-2xl shadow-md overflow-hidden card-hover">
                  <div className="relative h-48">
                    <img src={e.image_url || 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=600'} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute top-4 left-4 bg-white text-primary rounded-xl px-3 py-2 text-center shadow-lg">
                      <div className="font-display text-2xl font-bold leading-none">{day}</div>
                      <div className="text-xs uppercase font-semibold">{month}</div>
                    </div>
                    {e.category && (
                      <span className="absolute top-4 right-4 bg-gold text-white text-xs px-3 py-1 rounded-full font-semibold capitalize">
                        {e.category}
                      </span>
                    )}
                  </div>
                  <div className="p-5">
                    <h3 className="font-display text-lg font-bold text-ink mb-2 line-clamp-2">{pickField(e, 'title', lang)}</h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">{pickField(e, 'description', lang)}</p>
                    <div className="space-y-1 text-xs text-gray-500">
                      <p className="flex items-center gap-2"><FaCalendarAlt className="text-primary" /> {d.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                      {e.event_time && <p className="flex items-center gap-2"><FaClock className="text-primary" /> {e.event_time}</p>}
                      {e.venue && <p className="flex items-center gap-2"><FaMapMarkerAlt className="text-primary" /> {pickField(e, 'venue', lang)}</p>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {events.length === 0 && (
            <p className="text-center text-gray-500 py-10">
              {lang === 'hi' ? 'कोई कार्यक्रम नहीं।' : 'No events.'}
            </p>
          )}
        </div>
      </section>
    </SiteShell>
  );
}
