import { NextResponse } from 'next/server';
import { query, queryOne } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const key = url.searchParams.get('key');
    if (key) {
      const row = await queryOne('SELECT * FROM about_content WHERE section_key = ? LIMIT 1', [key]);
      return NextResponse.json({ item: row });
    }
    const rows = await query('SELECT * FROM about_content ORDER BY id ASC');
    return NextResponse.json({ items: rows });
  } catch (e) {
    console.error('about GET error:', e);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

export async function POST(request) {
  // upsert by section_key
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const b = await request.json();
    const existing = await queryOne('SELECT id FROM about_content WHERE section_key = ? LIMIT 1', [b.section_key]);
    if (existing) {
      await query(
        `UPDATE about_content SET title=?, title_hi=?, content=?, content_hi=?, image_url=? WHERE section_key=?`,
        [b.title || null, b.title_hi || null, b.content || null, b.content_hi || null, b.image_url || null, b.section_key]
      );
      return NextResponse.json({ success: true, id: existing.id });
    }
    const result = await query(
      `INSERT INTO about_content (section_key, title, title_hi, content, content_hi, image_url) VALUES (?,?,?,?,?,?)`,
      [b.section_key, b.title || null, b.title_hi || null, b.content || null, b.content_hi || null, b.image_url || null]
    );
    return NextResponse.json({ success: true, id: result.insertId });
  } catch (e) {
    console.error('about POST error:', e);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
