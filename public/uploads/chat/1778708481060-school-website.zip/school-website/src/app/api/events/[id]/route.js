import { makeCrudHandlers } from '@/lib/crud';

const fields = ['title', 'title_hi', 'description', 'description_hi', 'event_date', 'event_time', 'venue', 'venue_hi', 'category', 'image_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('events', fields);
export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
