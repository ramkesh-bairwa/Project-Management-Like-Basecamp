import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const type = url.searchParams.get('type'); // photo | video
    const limit = parseInt(url.searchParams.get('limit') || '0', 10);
    const onlyActive = url.searchParams.get('all') !== '1';

    const where = [];
    const params = [];
    if (onlyActive) where.push('is_active = 1');
    if (type) {
      where.push('media_type = ?');
      params.push(type);
    }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const lim = limit > 0 ? `LIMIT ${limit}` : '';
    const rows = await query(`SELECT * FROM gallery ${whereSql} ORDER BY display_order ASC, id DESC ${lim}`, params);
    return NextResponse.json({ items: rows });
  } catch (e) {
    console.error('gallery GET error:', e);
    return NextResponse.json({ error: 'Failed to load' }, { status: 500 });
  }
}

export async function POST(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const b = await request.json();
    const result = await query(
      `INSERT INTO gallery (title, title_hi, category, media_type, media_url, thumbnail_url, display_order, is_active)
       VALUES (?,?,?,?,?,?,?,?)`,
      [
        b.title, b.title_hi || null, b.category || 'general', b.media_type || 'photo',
        b.media_url, b.thumbnail_url || null, b.display_order || 0, b.is_active ? 1 : 0,
      ]
    );
    return NextResponse.json({ success: true, id: result.insertId });
  } catch (e) {
    console.error('gallery POST error:', e);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
