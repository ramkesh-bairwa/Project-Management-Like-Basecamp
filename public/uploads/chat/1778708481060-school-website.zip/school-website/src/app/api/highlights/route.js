import { makeCrudHandlers } from '@/lib/crud';

const fields = ['icon', 'title', 'title_hi', 'number_value', 'description', 'description_hi', 'display_order', 'is_active'];
const h = makeCrudHandlers('highlights', fields);

export const GET = (req) => h.list(req);
export const POST = (req) => h.create(req);
