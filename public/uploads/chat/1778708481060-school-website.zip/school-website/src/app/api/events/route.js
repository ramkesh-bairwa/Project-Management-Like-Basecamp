import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const filter = url.searchParams.get('filter');
    const limit = parseInt(url.searchParams.get('limit') || '0', 10);
    const onlyActive = url.searchParams.get('all') !== '1';

    const where = [];
    if (onlyActive) where.push('is_active = 1');
    if (filter === 'upcoming') where.push('event_date >= CURDATE()');
    else if (filter === 'past') where.push('event_date < CURDATE()');

    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const order = filter === 'past' ? 'event_date DESC' : 'event_date ASC';
    const lim = limit > 0 ? `LIMIT ${limit}` : '';
    const rows = await query(`SELECT * FROM events ${whereSql} ORDER BY ${order} ${lim}`);
    return NextResponse.json({ items: rows });
  } catch (e) {
    console.error('events GET error:', e);
    return NextResponse.json({ error: 'Failed to load' }, { status: 500 });
  }
}

export async function POST(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const b = await request.json();
    const result = await query(
      `INSERT INTO events (title, title_hi, description, description_hi, event_date, event_time, venue, venue_hi, category, image_url, display_order, is_active)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        b.title, b.title_hi || null, b.description, b.description_hi || null,
        b.event_date, b.event_time || null, b.venue || null, b.venue_hi || null,
        b.category || 'general', b.image_url || null, b.display_order || 0, b.is_active ? 1 : 0,
      ]
    );
    return NextResponse.json({ success: true, id: result.insertId });
  } catch (e) {
    console.error('events POST error:', e);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
