import { makeCrudHandlers } from '@/lib/crud';

const fields = ['title', 'title_hi', 'category', 'media_type', 'media_url', 'thumbnail_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('gallery', fields);
export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
