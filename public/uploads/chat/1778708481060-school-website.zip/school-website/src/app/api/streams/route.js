import { makeCrudHandlers } from '@/lib/crud';

const fields = ['name', 'name_hi', 'icon', 'description', 'description_hi', 'subjects', 'subjects_hi', 'image_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('streams', fields);
export const GET = (req) => h.list(req);
export const POST = (req) => h.create(req);
