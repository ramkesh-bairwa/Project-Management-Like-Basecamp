import { NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';
import { requireAuth } from '@/lib/auth';

export const runtime = 'nodejs';

export async function POST(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const formData = await request.formData();
    const file = formData.get('file');
    if (!file) return NextResponse.json({ error: 'No file' }, { status: 400 });

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const uploadDir = path.join(process.cwd(), 'public', 'uploads');
    await mkdir(uploadDir, { recursive: true });

    // safe filename: timestamp + random + sanitized original
    const ext = path.extname(file.name || '').toLowerCase().replace(/[^.a-z0-9]/g, '');
    const base = (file.name || 'file').replace(/[^a-z0-9._-]/gi, '_').slice(0, 60);
    const finalName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${base}${ext && !base.endsWith(ext) ? ext : ''}`;
    const filepath = path.join(uploadDir, finalName);

    await writeFile(filepath, buffer);

    const url = `/uploads/${finalName}`;
    return NextResponse.json({ success: true, url });
  } catch (e) {
    console.error('upload error:', e);
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 });
  }
}
