import { makeCrudHandlers } from '@/lib/crud';

const fields = ['name', 'name_hi', 'role', 'role_hi', 'message', 'message_hi', 'rating', 'image_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('testimonials', fields);
export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
