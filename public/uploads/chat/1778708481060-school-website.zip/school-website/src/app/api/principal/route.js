import { NextResponse } from 'next/server';
import { queryOne } from '@/lib/db';

export async function GET() {
  try {
    const row = await queryOne('SELECT * FROM about_content WHERE section_key = ? LIMIT 1', ['principal_message']);
    return NextResponse.json({ item: row });
  } catch (e) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
