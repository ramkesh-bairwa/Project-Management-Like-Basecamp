import { makeCrudHandlers } from '@/lib/crud';

const fields = ['name', 'name_hi', 'designation', 'designation_hi', 'qualification', 'qualification_hi', 'department', 'experience_years', 'image_url', 'email', 'bio', 'bio_hi', 'display_order', 'is_active'];
const h = makeCrudHandlers('teachers', fields);
export const GET = (req) => h.list(req);
export const POST = (req) => h.create(req);
