import { NextResponse } from 'next/server';
import { query, queryOne } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

// GET ?type=info  -> admission_info row(s) with process steps + fees (public)
// GET ?type=applications -> admin list of applications (auth)
export async function GET(request) {
  try {
    const url = new URL(request.url);
    const type = url.searchParams.get('type') || 'info';

    if (type === 'info') {
      const rows = await query('SELECT * FROM admission_info ORDER BY id ASC');
      return NextResponse.json({ items: rows });
    }

    if (type === 'applications') {
      const user = await requireAuth();
      if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      const rows = await query('SELECT * FROM admission_applications ORDER BY created_at DESC');
      return NextResponse.json({ items: rows });
    }

    return NextResponse.json({ error: 'Unknown type' }, { status: 400 });
  } catch (e) {
    console.error('admissions GET error:', e);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

// POST: public submission of application
export async function POST(request) {
  try {
    const b = await request.json();
    if (!b.student_name || !b.parent_name || !b.phone || !b.applying_for_class) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }
    const result = await query(
      `INSERT INTO admission_applications
       (student_name, dob, gender, parent_name, parent_email, phone, address, applying_for_class, previous_school, message, status)
       VALUES (?,?,?,?,?,?,?,?,?,?, 'pending')`,
      [
        b.student_name, b.dob || null, b.gender || null, b.parent_name,
        b.parent_email || null, b.phone, b.address || null,
        b.applying_for_class, b.previous_school || null, b.message || null,
      ]
    );
    return NextResponse.json({ success: true, id: result.insertId });
  } catch (e) {
    console.error('admissions POST error:', e);
    return NextResponse.json({ error: 'Failed to submit application' }, { status: 500 });
  }
}

// PUT: admin updates admission_info OR application status
// body { kind: 'info' | 'application', id, ...fields }
export async function PUT(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const b = await request.json();
    if (b.kind === 'info') {
      await query(
        `UPDATE admission_info
         SET process_steps=?, process_steps_hi=?, eligibility=?, eligibility_hi=?,
             documents_required=?, documents_required_hi=?,
             fee_nursery=?, fee_primary=?, fee_middle=?, fee_secondary=?, fee_senior=?,
             important_dates=?, important_dates_hi=?
         WHERE id=?`,
        [
          b.process_steps || null, b.process_steps_hi || null,
          b.eligibility || null, b.eligibility_hi || null,
          b.documents_required || null, b.documents_required_hi || null,
          b.fee_nursery || 0, b.fee_primary || 0, b.fee_middle || 0,
          b.fee_secondary || 0, b.fee_senior || 0,
          b.important_dates || null, b.important_dates_hi || null,
          b.id,
        ]
      );
      return NextResponse.json({ success: true });
    }
    if (b.kind === 'application') {
      await query('UPDATE admission_applications SET status=? WHERE id=?', [b.status, b.id]);
      return NextResponse.json({ success: true });
    }
    return NextResponse.json({ error: 'Unknown kind' }, { status: 400 });
  } catch (e) {
    console.error('admissions PUT error:', e);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

// DELETE: admin deletes an application
export async function DELETE(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'No id' }, { status: 400 });
    await query('DELETE FROM admission_applications WHERE id=?', [id]);
    return NextResponse.json({ success: true });
  } catch (e) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
