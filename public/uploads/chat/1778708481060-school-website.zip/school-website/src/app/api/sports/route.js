import { makeCrudHandlers } from '@/lib/crud';

const fields = ['name', 'name_hi', 'icon', 'category', 'description', 'description_hi', 'image_url', 'achievements', 'achievements_hi', 'display_order', 'is_active'];
const h = makeCrudHandlers('sports', fields);
export const GET = (req) => h.list(req);
export const POST = (req) => h.create(req);
