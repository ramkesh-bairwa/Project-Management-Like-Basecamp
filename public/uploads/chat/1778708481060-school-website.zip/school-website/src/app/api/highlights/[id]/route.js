import { makeCrudHandlers } from '@/lib/crud';

const fields = ['icon', 'title', 'title_hi', 'number_value', 'description', 'description_hi', 'display_order', 'is_active'];
const h = makeCrudHandlers('highlights', fields);

export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
