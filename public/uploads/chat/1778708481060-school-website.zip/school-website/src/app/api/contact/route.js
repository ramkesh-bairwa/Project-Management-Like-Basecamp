import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET() {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const rows = await query('SELECT * FROM contact_messages ORDER BY created_at DESC');
    return NextResponse.json({ items: rows });
  } catch (e) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const b = await request.json();
    if (!b.name || !b.email || !b.message) {
      return NextResponse.json({ error: 'Name, email and message are required' }, { status: 400 });
    }
    const result = await query(
      `INSERT INTO contact_messages (name, email, phone, subject, message, is_read) VALUES (?,?,?,?,?,0)`,
      [b.name, b.email, b.phone || null, b.subject || null, b.message]
    );
    return NextResponse.json({ success: true, id: result.insertId });
  } catch (e) {
    console.error('contact POST error:', e);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

export async function PUT(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const b = await request.json();
    await query('UPDATE contact_messages SET is_read=? WHERE id=?', [b.is_read ? 1 : 0, b.id]);
    return NextResponse.json({ success: true });
  } catch (e) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

export async function DELETE(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'No id' }, { status: 400 });
    await query('DELETE FROM contact_messages WHERE id=?', [id]);
    return NextResponse.json({ success: true });
  } catch (e) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
