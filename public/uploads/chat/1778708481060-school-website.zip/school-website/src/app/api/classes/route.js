import { makeCrudHandlers } from '@/lib/crud';

const fields = ['class_name', 'class_name_hi', 'age_group', 'description', 'description_hi', 'image_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('classes', fields);
export const GET = (req) => h.list(req);
export const POST = (req) => h.create(req);
