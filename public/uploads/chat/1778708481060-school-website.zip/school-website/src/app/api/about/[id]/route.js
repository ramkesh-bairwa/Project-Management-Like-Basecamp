import { makeCrudHandlers } from '@/lib/crud';

const fields = ['section_key', 'title', 'title_hi', 'content', 'content_hi', 'image_url'];
const h = makeCrudHandlers('about_content', fields, 'id ASC');
export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
