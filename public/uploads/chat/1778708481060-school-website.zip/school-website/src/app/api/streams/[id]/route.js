import { makeCrudHandlers } from '@/lib/crud';

const fields = ['name', 'name_hi', 'icon', 'description', 'description_hi', 'subjects', 'subjects_hi', 'image_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('streams', fields);
export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
