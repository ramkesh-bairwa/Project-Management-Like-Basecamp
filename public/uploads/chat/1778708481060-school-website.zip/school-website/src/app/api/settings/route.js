import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET() {
  try {
    const rows = await query('SELECT setting_key, setting_value, setting_value_hi, setting_type FROM site_settings');
    const obj = {};
    rows.forEach((r) => {
      obj[r.setting_key] = r.setting_value;
      if (r.setting_value_hi) obj[`${r.setting_key}_hi`] = r.setting_value_hi;
    });
    return NextResponse.json({ settings: obj, raw: rows });
  } catch (e) {
    console.error('settings GET error:', e);
    return NextResponse.json({ error: 'Failed to load settings' }, { status: 500 });
  }
}

export async function POST(request) {
  const user = await requireAuth();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await request.json();
    // body: { updates: [{key, value, value_hi}] }
    const updates = body.updates || [];
    for (const u of updates) {
      await query(
        'UPDATE site_settings SET setting_value = ?, setting_value_hi = ? WHERE setting_key = ?',
        [u.value ?? '', u.value_hi ?? null, u.key]
      );
    }
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error('settings POST error:', e);
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 });
  }
}
