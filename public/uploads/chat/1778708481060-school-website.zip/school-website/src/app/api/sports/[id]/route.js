import { makeCrudHandlers } from '@/lib/crud';

const fields = ['name', 'name_hi', 'icon', 'category', 'description', 'description_hi', 'image_url', 'achievements', 'achievements_hi', 'display_order', 'is_active'];
const h = makeCrudHandlers('sports', fields);
export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
