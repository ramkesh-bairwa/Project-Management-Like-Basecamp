import { makeCrudHandlers } from '@/lib/crud';

const fields = ['class_name', 'class_name_hi', 'age_group', 'description', 'description_hi', 'image_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('classes', fields);
export const GET = (_req, { params }) => h.getOne(params.id);
export const PUT = (req, { params }) => h.update(params.id, req);
export const DELETE = (_req, { params }) => h.remove(params.id);
