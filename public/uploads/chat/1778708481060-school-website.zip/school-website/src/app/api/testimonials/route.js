import { makeCrudHandlers } from '@/lib/crud';

const fields = ['name', 'name_hi', 'role', 'role_hi', 'message', 'message_hi', 'rating', 'image_url', 'display_order', 'is_active'];
const h = makeCrudHandlers('testimonials', fields);
export const GET = (req) => h.list(req);
export const POST = (req) => h.create(req);
