'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaClock, FaPaperPlane, FaFacebook, FaInstagram, FaYoutube, FaTwitter } from 'react-icons/fa';

export default function ContactPage() {
  const { lang } = useLang();
  const [settings, setSettings] = useState({});
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [status, setStatus] = useState({ loading: false, ok: false, error: '' });

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => setSettings(d.settings || {}));
  }, []);

  const pick = (key) => (lang === 'hi' && settings[`${key}_hi`]) ? settings[`${key}_hi`] : settings[key];

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ loading: true, ok: false, error: '' });
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setStatus({ loading: false, ok: true, error: '' });
      setForm({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch (err) {
      setStatus({ loading: false, ok: false, error: err.message });
    }
  };

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'संपर्क करें' : 'Contact Us'}
        subtitle={lang === 'hi' ? 'हम आपकी सहायता के लिए यहाँ हैं' : 'We are here to help'}
        breadcrumbs={[{ label: lang === 'hi' ? 'संपर्क' : 'Contact' }]}
      />

      <section className="py-20">
        <div className="container-x">
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {[
              { icon: FaPhone, label: lang === 'hi' ? 'फ़ोन' : 'Phone', value: settings.contact_phone, href: settings.contact_phone ? `tel:${settings.contact_phone}` : null },
              { icon: FaEnvelope, label: lang === 'hi' ? 'ईमेल' : 'Email', value: settings.contact_email, href: settings.contact_email ? `mailto:${settings.contact_email}` : null },
              { icon: FaMapMarkerAlt, label: lang === 'hi' ? 'पता' : 'Address', value: pick('contact_address') },
            ].map((c, i) => (
              <div key={i} className="bg-white rounded-3xl shadow-lg p-8 text-center card-hover">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 text-primary flex items-center justify-center text-2xl mb-4">
                  <c.icon />
                </div>
                <h3 className="font-display text-lg font-bold text-ink mb-2">{c.label}</h3>
                {c.href ? (
                  <a href={c.href} className="text-gray-600 hover:text-primary transition">{c.value}</a>
                ) : (
                  <p className="text-gray-600">{c.value}</p>
                )}
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-10 items-start">
            {/* Form */}
            <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-10">
              <div className="section-divider mb-4" />
              <h2 className="font-display text-3xl font-bold text-primary mb-6">
                {lang === 'hi' ? 'हमें संदेश भेजें' : 'Send us a message'}
              </h2>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="form-label">{lang === 'hi' ? 'नाम *' : 'Name *'}</label>
                    <input required name="name" value={form.name} onChange={handleChange} className="form-input" />
                  </div>
                  <div>
                    <label className="form-label">{lang === 'hi' ? 'ईमेल *' : 'Email *'}</label>
                    <input required type="email" name="email" value={form.email} onChange={handleChange} className="form-input" />
                  </div>
                  <div>
                    <label className="form-label">{lang === 'hi' ? 'फ़ोन' : 'Phone'}</label>
                    <input name="phone" value={form.phone} onChange={handleChange} className="form-input" />
                  </div>
                  <div>
                    <label className="form-label">{lang === 'hi' ? 'विषय' : 'Subject'}</label>
                    <input name="subject" value={form.subject} onChange={handleChange} className="form-input" />
                  </div>
                </div>
                <div>
                  <label className="form-label">{lang === 'hi' ? 'संदेश *' : 'Message *'}</label>
                  <textarea required rows={5} name="message" value={form.message} onChange={handleChange} className="form-input" />
                </div>
                {status.error && <p className="text-red-600 text-sm">{status.error}</p>}
                {status.ok && (
                  <p className="text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-3 text-sm">
                    {lang === 'hi' ? 'धन्यवाद! आपका संदेश भेज दिया गया है।' : "Thank you! Your message has been sent."}
                  </p>
                )}
                <button type="submit" disabled={status.loading} className="btn-primary disabled:opacity-50">
                  <FaPaperPlane />
                  {status.loading ? '...' : (lang === 'hi' ? 'भेजें' : 'Send Message')}
                </button>
              </form>
            </div>

            {/* Map + extras */}
            <div className="space-y-6">
              <div className="bg-white rounded-3xl shadow-lg overflow-hidden h-[400px]">
                {settings.map_embed ? (
                  <div className="w-full h-full" dangerouslySetInnerHTML={{ __html: settings.map_embed }} />
                ) : (
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d224346.41818148622!2d77.04417187454!3d28.527280572069514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x52c2b7494e204dce!2sNew%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1700000000000"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                  />
                )}
              </div>
              <div className="bg-white rounded-3xl shadow-lg p-6">
                <h3 className="font-display font-bold text-ink mb-3 flex items-center gap-2">
                  <FaClock className="text-primary" /> {lang === 'hi' ? 'कार्य समय' : 'Working Hours'}
                </h3>
                <p className="text-gray-700 whitespace-pre-line">{pick('working_hours') || 'Mon-Fri: 8:00 AM - 4:00 PM\nSat: 8:00 AM - 1:00 PM'}</p>
              </div>
              <div className="bg-white rounded-3xl shadow-lg p-6">
                <h3 className="font-display font-bold text-ink mb-3">{lang === 'hi' ? 'सोशल मीडिया' : 'Follow us'}</h3>
                <div className="flex gap-3">
                  {[
                    { url: settings.social_facebook, icon: FaFacebook },
                    { url: settings.social_instagram, icon: FaInstagram },
                    { url: settings.social_youtube, icon: FaYoutube },
                    { url: settings.social_twitter, icon: FaTwitter },
                  ].filter(s => s.url).map((s, i) => (
                    <a key={i} href={s.url} target="_blank" rel="noreferrer" className="w-11 h-11 rounded-full bg-primary/10 text-primary flex items-center justify-center hover:bg-primary hover:text-white transition">
                      <s.icon />
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
