'use client';
import { useEffect, useState } from 'react';
import SiteShell from '@/components/layout/SiteShell';
import PageBanner from '@/components/layout/PageBanner';
import { useLang } from '@/lib/LangContext';
import { pickField } from '@/lib/i18n';
import { FaCalendarAlt, FaPaperclip, FaStar } from 'react-icons/fa';

const CAT_COLORS = {
  general: 'bg-gray-100 text-gray-700',
  academic: 'bg-blue-100 text-blue-700',
  sports: 'bg-green-100 text-green-700',
  holiday: 'bg-orange-100 text-orange-700',
  admission: 'bg-purple-100 text-purple-700',
  event: 'bg-pink-100 text-pink-700',
};

export default function NoticesPage() {
  const { lang } = useLang();
  const [notices, setNotices] = useState([]);
  const [cat, setCat] = useState('all');

  useEffect(() => {
    const url = cat === 'all' ? '/api/notices' : `/api/notices?cat=${cat}`;
    fetch(url).then(r => r.json()).then(d => setNotices(d.items || []));
  }, [cat]);

  const cats = ['all', 'academic', 'sports', 'holiday', 'admission', 'event', 'general'];
  const labels = {
    en: { all: 'All', academic: 'Academic', sports: 'Sports', holiday: 'Holiday', admission: 'Admission', event: 'Event', general: 'General' },
    hi: { all: 'सभी', academic: 'शैक्षणिक', sports: 'खेल', holiday: 'अवकाश', admission: 'प्रवेश', event: 'कार्यक्रम', general: 'सामान्य' },
  };

  return (
    <SiteShell>
      <PageBanner
        title={lang === 'hi' ? 'सूचनाएँ और समाचार' : 'Notices & News'}
        subtitle={lang === 'hi' ? 'नवीनतम घोषणाएँ और अद्यतन' : 'Latest announcements and updates'}
        breadcrumbs={[{ label: lang === 'hi' ? 'सूचनाएँ' : 'Notices' }]}
      />

      <section className="py-20">
        <div className="container-x">
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {cats.map(c => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`px-5 py-2 rounded-full text-sm font-semibold transition ${
                  cat === c ? 'bg-primary text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:border-primary'
                }`}
              >
                {labels[lang][c]}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {notices.map((n) => (
              <div key={n.id} className={`bg-white rounded-2xl shadow-md p-6 border-l-4 card-hover ${
                n.is_important ? 'border-gold' : 'border-primary'
              }`}>
                <div className="flex items-start justify-between mb-3 gap-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-xs px-3 py-1 rounded-full font-semibold ${CAT_COLORS[n.category] || CAT_COLORS.general}`}>
                      {labels[lang][n.category] || n.category}
                    </span>
                    {n.is_important ? (
                      <span className="bg-gold/15 text-gold text-xs px-3 py-1 rounded-full font-bold flex items-center gap-1">
                        <FaStar className="text-[10px]" /> {lang === 'hi' ? 'महत्वपूर्ण' : 'Important'}
                      </span>
                    ) : null}
                  </div>
                  <span className="text-xs text-gray-500 flex items-center gap-1 whitespace-nowrap">
                    <FaCalendarAlt /> {new Date(n.notice_date).toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                </div>
                <h3 className="font-display text-xl font-bold text-ink mb-2">{pickField(n, 'title', lang)}</h3>
                <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-line">{pickField(n, 'content', lang)}</p>
                {n.attachment_url && (
                  <a href={n.attachment_url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-primary text-sm font-semibold hover:text-primary-700">
                    <FaPaperclip /> {lang === 'hi' ? 'संलग्नक देखें' : 'View attachment'}
                  </a>
                )}
              </div>
            ))}
          </div>

          {notices.length === 0 && (
            <p className="text-center text-gray-500 py-10">
              {lang === 'hi' ? 'इस श्रेणी में कोई सूचना नहीं।' : 'No notices in this category.'}
            </p>
          )}
        </div>
      </section>
    </SiteShell>
  );
}
