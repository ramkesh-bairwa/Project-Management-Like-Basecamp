'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import * as Fa from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function AcademicsSection() {
  const { t, lang } = useLang();
  const [streams, setStreams] = useState([]);

  useEffect(() => {
    fetch('/api/streams')
      .then(r => r.json())
      .then(data => setStreams(data.streams || []))
      .catch(() => {});
  }, []);

  return (
    <section className="py-20 bg-gradient-to-b from-cream to-white relative overflow-hidden">
      <div className="absolute inset-0 pattern-overlay"></div>
      <div className="container-x relative">
        <div className="text-center mb-14">
          <span className="section-divider">{lang === 'hi' ? 'शिक्षा' : 'Academics'}</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-3">{t.home.academicsTitle}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">{t.home.academicsSub}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {streams.map((stream) => {
            const Icon = Fa[stream.icon] || Fa.FaBook;
            const name = lang === 'hi' ? stream.name_hi || stream.name : stream.name;
            const desc = lang === 'hi' ? stream.description_hi || stream.description : stream.description;
            return (
              <div key={stream.id} className="group relative bg-white rounded-2xl overflow-hidden card-hover border border-gray-100">
                <div className="relative h-52 overflow-hidden">
                  <img
                    src={stream.image_url || 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800'}
                    alt={name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    onError={(e) => { e.target.src = 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800'; }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/30 to-transparent"></div>
                  <div className="absolute top-4 left-4 w-14 h-14 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/30">
                    <Icon className="text-2xl" />
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="font-display text-2xl font-bold text-white">{name}</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-sm text-gray-600 leading-relaxed mb-4 line-clamp-3">{desc}</p>
                  <Link href={`/academics#streams`} className="text-primary font-semibold text-sm inline-flex items-center gap-1 hover:gap-2 transition-all">
                    {t.home.readMore} →
                  </Link>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-10">
          <Link href="/academics" className="btn-primary">
            {t.home.viewAll} <Fa.FaArrowRight />
          </Link>
        </div>
      </div>
    </section>
  );
}
