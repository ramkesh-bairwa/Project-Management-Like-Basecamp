'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { FaBullhorn, FaCalendarAlt, FaArrowRight, FaExclamationCircle } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function NoticeBoard() {
  const { t, lang } = useLang();
  const [notices, setNotices] = useState([]);

  useEffect(() => {
    fetch('/api/notices?limit=6')
      .then(r => r.json())
      .then(data => setNotices(data.notices || []))
      .catch(() => {});
  }, []);

  const formatDate = (date) => {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const categoryColors = {
    sports: 'bg-blue-100 text-blue-700',
    academic: 'bg-purple-100 text-purple-700',
    holiday: 'bg-green-100 text-green-700',
    admission: 'bg-amber-100 text-amber-700',
    event: 'bg-pink-100 text-pink-700',
    general: 'bg-gray-100 text-gray-700',
  };

  return (
    <section className="py-20 bg-white relative">
      <div className="container-x">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <span className="section-divider">{lang === 'hi' ? 'अद्यतन रहें' : 'Stay Informed'}</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-2">{t.home.noticeTitle}</h2>
            <p className="text-gray-600">{t.home.noticeSub}</p>
          </div>
          <Link href="/notices" className="btn-primary">
            {t.home.viewAll} <FaArrowRight />
          </Link>
        </div>

        {/* Marquee for important notices */}
        {notices.filter(n => n.is_important).length > 0 && (
          <div className="mb-8 bg-gradient-to-r from-primary to-primary-700 text-white rounded-xl overflow-hidden flex items-stretch">
            <div className="bg-gold text-ink px-5 flex items-center gap-2 font-bold text-sm flex-shrink-0">
              <FaBullhorn className="animate-pulse" /> {lang === 'hi' ? 'महत्वपूर्ण' : 'IMPORTANT'}
            </div>
            <div className="marquee-container py-3">
              <div className="marquee-content gap-12 px-6">
                {[...notices.filter(n => n.is_important), ...notices.filter(n => n.is_important)].map((n, i) => (
                  <span key={i} className="text-sm whitespace-nowrap">
                    ★ {lang === 'hi' ? n.title_hi || n.title : n.title}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {notices.slice(0, 6).map((notice) => {
            const title = lang === 'hi' ? notice.title_hi || notice.title : notice.title;
            const content = lang === 'hi' ? notice.content_hi || notice.content : notice.content;
            return (
              <div key={notice.id} className="group bg-white border border-gray-200 rounded-2xl p-6 card-hover relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-primary group-hover:w-full group-hover:opacity-5 transition-all duration-500"></div>
                <div className="relative">
                  <div className="flex items-center gap-2 mb-3">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium uppercase tracking-wide ${categoryColors[notice.category] || categoryColors.general}`}>
                      {notice.category}
                    </span>
                    {notice.is_important ? <FaExclamationCircle className="text-primary" /> : null}
                  </div>
                  <h3 className="font-display text-lg font-bold mb-2 group-hover:text-primary transition line-clamp-2">{title}</h3>
                  <p className="text-sm text-gray-600 line-clamp-3 mb-4">{content}</p>
                  <div className="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-gray-100">
                    <span className="flex items-center gap-1.5">
                      <FaCalendarAlt /> {formatDate(notice.notice_date || notice.created_at)}
                    </span>
                    <Link href="/notices" className="text-primary font-semibold hover:gap-2 inline-flex items-center gap-1 transition-all">
                      {t.home.readMore} →
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
