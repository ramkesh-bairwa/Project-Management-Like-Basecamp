'use client';
import Link from 'next/link';
import { FaArrowRight, FaPhone } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function CTASection({ settings = {} }) {
  const { t, lang } = useLang();

  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary-700 to-primary-900"></div>
      {/* Pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <pattern id="cta-pat" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
            <path d="M0 40 L40 0 L80 40 L40 80 Z" fill="none" stroke="white" strokeWidth="0.5"/>
          </pattern>
          <rect width="100%" height="100%" fill="url(#cta-pat)" />
        </svg>
      </div>

      {/* Decorative blobs */}
      <div className="absolute top-0 left-0 w-72 h-72 rounded-full bg-gold/20 blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-72 h-72 rounded-full bg-white/5 blur-3xl"></div>

      <div className="container-x relative text-center text-white">
        <div className="max-w-3xl mx-auto">
          <span className="inline-block bg-gold/20 text-gold border border-gold/30 rounded-full px-4 py-1 text-xs uppercase tracking-widest mb-5">
            {lang === 'hi' ? 'प्रवेश 2026-27 खुले हैं' : 'Admissions Open 2026-27'}
          </span>
          <h2 className="font-display text-4xl md:text-6xl font-bold mb-5 text-balance">{t.home.ctaTitle}</h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">{t.home.ctaSub}</p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/admissions#apply" className="btn-primary btn-gold !text-ink !py-4 !px-8 !text-base">
              {t.home.ctaBtn} <FaArrowRight />
            </Link>
            {settings.contact_phone && (
              <a href={`tel:${settings.contact_phone}`} className="btn-outline !py-4 !px-8 !text-base">
                <FaPhone /> {settings.contact_phone}
              </a>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
