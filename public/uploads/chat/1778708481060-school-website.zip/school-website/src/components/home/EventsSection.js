'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { FaCalendarAlt, FaMapMarkerAlt, FaClock, FaArrowRight } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function EventsSection() {
  const { t, lang } = useLang();
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetch('/api/events?limit=4&filter=upcoming')
      .then(r => r.json())
      .then(data => setEvents(data.events || []))
      .catch(() => {});
  }, []);

  const formatDate = (date) => {
    if (!date) return { day: '', month: '' };
    const d = new Date(date);
    return {
      day: d.getDate(),
      month: d.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-US', { month: 'short' }).toUpperCase(),
    };
  };

  if (!events.length) return null;

  return (
    <section className="py-20 bg-gradient-to-b from-white to-cream relative">
      <div className="container-x">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <span className="section-divider">{lang === 'hi' ? 'जुड़ें' : 'Join Us'}</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-2">{t.home.eventsTitle}</h2>
            <p className="text-gray-600">{t.home.eventsSub}</p>
          </div>
          <Link href="/events" className="btn-primary">
            {t.home.viewAll} <FaArrowRight />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {events.map((event) => {
            const dateObj = formatDate(event.event_date);
            const title = lang === 'hi' ? event.title_hi || event.title : event.title;
            const desc = lang === 'hi' ? event.description_hi || event.description : event.description;
            const venue = lang === 'hi' ? event.venue_hi || event.venue : event.venue;
            return (
              <div key={event.id} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 card-hover">
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={event.image_url || 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=800'}
                    alt={title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    onError={(e) => { e.target.src = 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=800'; }}
                  />
                  <div className="absolute top-3 left-3 bg-white rounded-xl px-3 py-2 text-center shadow-lg">
                    <div className="font-display text-2xl font-bold text-primary leading-none">{dateObj.day}</div>
                    <div className="text-xs text-gray-600 font-semibold">{dateObj.month}</div>
                  </div>
                  {event.category && (
                    <span className="absolute top-3 right-3 bg-gold text-ink text-xs px-2.5 py-1 rounded-full font-semibold uppercase tracking-wide">
                      {event.category}
                    </span>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="font-display text-lg font-bold mb-2 group-hover:text-primary transition line-clamp-2">{title}</h3>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">{desc}</p>
                  <div className="space-y-1.5 text-xs text-gray-500">
                    {event.event_time && (
                      <div className="flex items-center gap-1.5">
                        <FaClock className="text-primary" /> {event.event_time}
                      </div>
                    )}
                    {venue && (
                      <div className="flex items-center gap-1.5">
                        <FaMapMarkerAlt className="text-primary" /> {venue}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
