'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { FaPlay, FaArrowRight } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function Hero() {
  const { t, lang } = useLang();
  const [settings, setSettings] = useState({});

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => setSettings(d.settings || {})).catch(() => {});
  }, []);

  const videoUrl = settings.hero_video_url || 'https://videos.pexels.com/video-files/8419063/8419063-uhd_2560_1440_25fps.mp4';
  const title = lang === 'hi' ? settings.hero_title_hi || settings.hero_title : settings.hero_title;
  const subtitle = lang === 'hi' ? settings.hero_subtitle_hi || settings.hero_subtitle : settings.hero_subtitle;
  const btnText = lang === 'hi' ? settings.hero_cta_text_hi || settings.hero_cta_text : settings.hero_cta_text;

  return (
    <section className="relative h-[92vh] min-h-[600px] overflow-hidden">
      <video
        autoPlay
        muted
        loop
        playsInline
        key={videoUrl}
        className="absolute inset-0 w-full h-full object-cover"
        poster="https://images.unsplash.com/photo-1497486751825-1233686d5d80?w=1920"
      >
        <source src={videoUrl} type="video/mp4" />
      </video>

      <div className="hero-video-overlay"></div>

      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <pattern id="hero-grid" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M 60 0 L 0 0 0 60" fill="none" stroke="white" strokeWidth="0.5"/>
          </pattern>
          <rect width="100%" height="100%" fill="url(#hero-grid)" />
        </svg>
      </div>

      <div className="relative h-full container-x flex flex-col justify-center text-white">
        <div className="max-w-3xl animate-slide-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 mb-6 rounded-full glass-dark border border-white/20 text-xs tracking-widest uppercase">
            <span className="w-2 h-2 rounded-full bg-gold animate-pulse"></span>
            {lang === 'hi' ? 'सेंट हेरिटेज पब्लिक स्कूल में आपका स्वागत है' : 'Welcome to St. Heritage Public School'}
          </div>
          <h1 className={`font-display font-bold mb-6 leading-[1.1] text-balance ${lang === 'hi' ? 'text-4xl md:text-5xl lg:text-6xl' : 'text-5xl md:text-6xl lg:text-7xl'}`}>
            {title || (lang === 'hi' ? 'आज के बच्चे, कल के नेता' : "Shaping Tomorrow's Leaders Today")}
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-10 max-w-2xl text-balance">
            {subtitle || (lang === 'hi' ? 'जहाँ परंपरा और नवाचार मिलते हैं' : 'Where Tradition Meets Innovation in Education')}
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/admissions#apply" className="btn-primary btn-gold !text-ink !py-4 !px-8 !text-base">
              {btnText || t.home.heroBtn} <FaArrowRight />
            </Link>
            <Link href="/about" className="btn-outline !py-4 !px-8 !text-base">
              <FaPlay className="text-xs" /> {t.home.heroBtn2}
            </Link>
          </div>
        </div>

        <div className="absolute bottom-8 left-0 right-0 hidden md:block">
          <div className="container-x">
            <div className="flex items-center gap-8 text-sm">
              <div className="flex items-center gap-2">
                <span className="w-12 h-px bg-gold"></span>
                <span className="text-gold font-semibold tracking-widest text-xs uppercase">{lang === 'hi' ? '1985 से' : 'Est. 1985'}</span>
              </div>
              <div className="opacity-50">|</div>
              <div className="text-white/80 text-xs">{lang === 'hi' ? 'सीबीएसई संबद्ध • एनसीईआरटी आधारित' : 'CBSE Affiliated • NCERT Curriculum'}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-6 right-6 z-10 hidden md:flex flex-col items-center gap-2 text-white/70 text-xs">
        <div className="rotate-90 origin-center tracking-widest">SCROLL</div>
        <div className="w-px h-12 bg-gradient-to-b from-gold to-transparent"></div>
      </div>
    </section>
  );
}
