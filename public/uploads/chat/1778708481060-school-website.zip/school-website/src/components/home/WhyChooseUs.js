'use client';
import { FaGraduationCap, FaBook, FaUsers, FaFlask, FaBus, FaShieldAlt } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function WhyChooseUs() {
  const { t, lang } = useLang();

  const features = lang === 'hi' ? [
    { icon: FaGraduationCap, title: 'योग्य शिक्षक', desc: 'अनुभवी और योग्य शिक्षण कर्मचारी' },
    { icon: FaBook, title: 'समृद्ध पाठ्यक्रम', desc: 'सीबीएसई आधारित आधुनिक शिक्षण विधि' },
    { icon: FaUsers, title: 'छोटी कक्षाएँ', desc: 'व्यक्तिगत ध्यान के लिए अधिकतम 25 छात्र' },
    { icon: FaFlask, title: 'आधुनिक प्रयोगशालाएँ', desc: 'विज्ञान, कंप्यूटर और भाषा प्रयोगशालाएँ' },
    { icon: FaBus, title: 'सुरक्षित परिवहन', desc: 'जीपीएस-ट्रैक्ड स्कूल बस सुविधा' },
    { icon: FaShieldAlt, title: 'सुरक्षित परिसर', desc: '24/7 सुरक्षा और सीसीटीवी निगरानी' },
  ] : [
    { icon: FaGraduationCap, title: 'Qualified Faculty', desc: 'Experienced and certified teaching staff dedicated to excellence' },
    { icon: FaBook, title: 'Rich Curriculum', desc: 'CBSE-based modern teaching methodology with global standards' },
    { icon: FaUsers, title: 'Small Class Size', desc: 'Maximum 25 students per class for personalized attention' },
    { icon: FaFlask, title: 'Modern Laboratories', desc: 'Science, Computer, Language, and Robotics labs' },
    { icon: FaBus, title: 'Safe Transportation', desc: 'GPS-tracked school bus facility with trained staff' },
    { icon: FaShieldAlt, title: 'Secure Campus', desc: '24/7 security with CCTV surveillance and access control' },
  ];

  return (
    <section className="py-20 bg-ink relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-primary blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-gold blur-3xl"></div>
      </div>

      <div className="container-x relative">
        <div className="text-center mb-14">
          <span className="section-divider !text-gold">{lang === 'hi' ? 'क्यों चुनें' : 'Why Choose Us'}</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-3 text-white">{t.home.whyTitle}</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">{t.home.whySub}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={i}
              className="group relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-7 hover:bg-gradient-to-br hover:from-primary hover:to-primary-700 transition-all duration-500"
            >
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <feature.icon className="text-2xl text-ink" />
              </div>
              <h3 className="font-display text-xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-300 leading-relaxed">{feature.desc}</p>
              <div className="absolute top-4 right-4 text-6xl font-display font-bold text-white/5 group-hover:text-white/10 transition">
                0{i + 1}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
