'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import * as Fa from 'react-icons/fa';
import * as Gi from 'react-icons/gi';
import { FaArrowRight } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function SportsSection() {
  const { t, lang } = useLang();
  const [sports, setSports] = useState([]);

  useEffect(() => {
    fetch('/api/sports?limit=6')
      .then(r => r.json())
      .then(data => setSports(data.sports || []))
      .catch(() => {});
  }, []);

  const getIcon = (iconName) => {
    return Fa[iconName] || Gi[iconName] || Fa.FaTrophy;
  };

  if (!sports.length) return null;

  return (
    <section className="py-20 bg-gradient-to-br from-cream via-white to-primary-50 relative overflow-hidden">
      <div className="absolute -top-32 right-0 w-96 h-96 rounded-full bg-gold/10 blur-3xl"></div>
      <div className="absolute -bottom-32 left-0 w-96 h-96 rounded-full bg-primary/10 blur-3xl"></div>

      <div className="container-x relative">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <span className="section-divider">{lang === 'hi' ? 'चैंपियंस का जन्म यहीं होता है' : 'Champions Are Born Here'}</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-2">{t.home.sportsTitle}</h2>
            <p className="text-gray-600">{t.home.sportsSub}</p>
          </div>
          <Link href="/sports" className="btn-primary">
            {t.home.viewAll} <FaArrowRight />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sports.slice(0, 6).map((sport) => {
            const Icon = getIcon(sport.icon);
            const name = lang === 'hi' ? sport.name_hi || sport.name : sport.name;
            const desc = lang === 'hi' ? sport.description_hi || sport.description : sport.description;
            const ach = lang === 'hi' ? sport.achievements_hi || sport.achievements : sport.achievements;
            return (
              <div key={sport.id} className="group relative bg-white rounded-2xl overflow-hidden card-hover border border-gray-100">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={sport.image_url || 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800'}
                    alt={name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    onError={(e) => { e.target.src = 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800'; }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent"></div>
                  <div className="absolute top-4 right-4 w-12 h-12 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/30">
                    <Icon className="text-xl" />
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="font-display text-2xl font-bold text-white mb-1">{name}</h3>
                    <span className="inline-block bg-gold text-ink text-xs px-2.5 py-0.5 rounded-full font-semibold uppercase">
                      {sport.category}
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">{desc}</p>
                  {ach && (
                    <div className="flex items-start gap-2 text-xs bg-gold/10 rounded-lg p-2.5 border border-gold/20">
                      <Fa.FaTrophy className="text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{ach}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
