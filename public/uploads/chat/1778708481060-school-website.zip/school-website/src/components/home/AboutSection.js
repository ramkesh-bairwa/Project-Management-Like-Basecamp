'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { FaArrowRight, FaCheckCircle } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function AboutSection() {
  const { t, lang } = useLang();
  const [about, setAbout] = useState(null);

  useEffect(() => {
    fetch('/api/about')
      .then(r => r.json())
      .then(data => {
        const aboutSchool = data.sections?.find(s => s.section_key === 'about_school');
        setAbout(aboutSchool || null);
      })
      .catch(() => {});
  }, []);

  const features = lang === 'hi'
    ? ['विश्व स्तरीय बुनियादी ढांचा', 'अनुभवी शिक्षक', 'समग्र विकास', 'आधुनिक पाठ्यक्रम']
    : ['World-class Infrastructure', 'Experienced Faculty', 'Holistic Development', 'Modern Curriculum'];

  return (
    <section className="py-20 bg-white relative overflow-hidden">
      <div className="container-x grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Image side */}
        <div className="relative">
          <div className="absolute -top-6 -left-6 w-32 h-32 border-4 border-gold rounded-2xl -z-10"></div>
          <div className="absolute -bottom-6 -right-6 w-32 h-32 border-4 border-primary rounded-2xl -z-10"></div>
          <div className="relative rounded-2xl overflow-hidden shadow-2xl">
            <img
              src={about?.image_url || 'https://images.unsplash.com/photo-1497486751825-1233686d5d80?w=1200'}
              alt="About School"
              className="w-full h-[500px] object-cover"
              onError={(e) => { e.target.src = 'https://images.unsplash.com/photo-1497486751825-1233686d5d80?w=1200'; }}
            />
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-ink/90 to-transparent text-white">
              <div className="font-display text-3xl font-bold">40+ {lang === 'hi' ? 'वर्षों की विरासत' : 'Years of Legacy'}</div>
              <div className="text-sm opacity-80">{lang === 'hi' ? '1985 से उत्कृष्टता प्रदान कर रहे हैं' : 'Delivering excellence since 1985'}</div>
            </div>
          </div>
          {/* Floating card */}
          <div className="absolute -right-4 top-1/3 hidden md:block bg-white shadow-2xl rounded-xl p-4 border border-gold/30">
            <div className="text-3xl font-display font-bold text-primary">98%</div>
            <div className="text-xs text-gray-500">{lang === 'hi' ? 'पास प्रतिशत' : 'Pass Rate'}</div>
          </div>
        </div>

        {/* Content */}
        <div>
          <span className="section-divider">{lang === 'hi' ? 'हमारी कहानी' : 'Our Story'}</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-6 text-ink">
            {about ? (lang === 'hi' ? about.title_hi || about.title : about.title) : t.home.aboutTitle}
          </h2>
          <p className="text-gray-600 leading-relaxed mb-6 text-balance">
            {about ? (lang === 'hi' ? about.content_hi || about.content : about.content) : ''}
          </p>

          <div className="grid grid-cols-2 gap-3 mb-8">
            {features.map((f, i) => (
              <div key={i} className="flex items-center gap-2 text-sm">
                <FaCheckCircle className="text-gold flex-shrink-0" />
                <span className="text-gray-700">{f}</span>
              </div>
            ))}
          </div>

          <Link href="/about" className="btn-primary">
            {t.home.aboutBtn} <FaArrowRight />
          </Link>
        </div>
      </div>
    </section>
  );
}
