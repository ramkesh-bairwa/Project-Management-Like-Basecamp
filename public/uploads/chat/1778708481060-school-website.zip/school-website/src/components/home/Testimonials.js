'use client';
import { useEffect, useState } from 'react';
import { FaQuoteLeft, FaStar, FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function Testimonials() {
  const { t, lang } = useLang();
  const [items, setItems] = useState([]);
  const [active, setActive] = useState(0);

  useEffect(() => {
    fetch('/api/testimonials')
      .then(r => r.json())
      .then(data => setItems(data.testimonials || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (items.length < 2) return;
    const id = setInterval(() => setActive(a => (a + 1) % items.length), 6000);
    return () => clearInterval(id);
  }, [items.length]);

  if (!items.length) return null;

  const next = () => setActive(a => (a + 1) % items.length);
  const prev = () => setActive(a => (a - 1 + items.length) % items.length);

  const current = items[active];
  const name = lang === 'hi' ? current.name_hi || current.name : current.name;
  const role = lang === 'hi' ? current.role_hi || current.role : current.role;
  const message = lang === 'hi' ? current.message_hi || current.message : current.message;

  return (
    <section className="py-20 bg-gradient-to-br from-primary via-primary-700 to-primary-900 relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-10 right-10 text-white/5 text-[15rem] font-display leading-none select-none">"</div>
      <div className="absolute bottom-10 left-10 text-white/5 text-[15rem] font-display leading-none select-none rotate-180">"</div>

      <div className="container-x relative">
        <div className="text-center mb-12 text-white">
          <span className="section-divider !text-gold">{lang === 'hi' ? 'प्रशंसापत्र' : 'Testimonials'}</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-2">{t.home.testimonialsTitle}</h2>
          <p className="text-white/80 max-w-2xl mx-auto">{t.home.testimonialsSub}</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl p-8 md:p-12 relative shadow-2xl">
            <FaQuoteLeft className="text-gold text-4xl mb-6" />
            <p className="text-lg md:text-xl text-gray-700 leading-relaxed mb-8 italic min-h-[120px]">
              "{message}"
            </p>
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                {current.image_url ? (
                  <img src={current.image_url} alt={name} className="w-14 h-14 rounded-full object-cover border-2 border-gold"
                    onError={(e) => e.target.style.display = 'none'} />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-primary-700 flex items-center justify-center text-white font-bold text-xl">
                    {name?.[0]}
                  </div>
                )}
                <div>
                  <div className="font-display text-lg font-bold text-ink">{name}</div>
                  <div className="text-sm text-gray-500">{role}</div>
                </div>
              </div>
              <div className="flex gap-1 text-gold">
                {[...Array(current.rating || 5)].map((_, i) => <FaStar key={i} />)}
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3 mt-6">
            <button onClick={prev} className="w-11 h-11 rounded-full bg-white/20 hover:bg-gold hover:text-ink text-white flex items-center justify-center transition">
              <FaChevronLeft />
            </button>
            <div className="flex items-center gap-2">
              {items.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  className={`h-2 rounded-full transition-all ${i === active ? 'w-8 bg-gold' : 'w-2 bg-white/40 hover:bg-white/60'}`}
                  aria-label={`Go to testimonial ${i + 1}`}
                />
              ))}
            </div>
            <button onClick={next} className="w-11 h-11 rounded-full bg-white/20 hover:bg-gold hover:text-ink text-white flex items-center justify-center transition">
              <FaChevronRight />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
