'use client';
import { useEffect, useState } from 'react';
import * as Fa from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function Highlights() {
  const { t, lang } = useLang();
  const [highlights, setHighlights] = useState([]);

  useEffect(() => {
    fetch('/api/highlights')
      .then(r => r.json())
      .then(data => setHighlights(data.highlights || []))
      .catch(() => {});
  }, []);

  if (!highlights.length) return null;

  return (
    <section className="relative py-20 bg-gradient-to-br from-cream via-white to-primary-50 decorative-bg overflow-hidden">
      {/* Decorative shapes */}
      <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-gradient-to-br from-gold/10 to-transparent blur-2xl"></div>
      <div className="absolute bottom-10 right-10 w-48 h-48 rounded-full bg-gradient-to-br from-primary/10 to-transparent blur-3xl"></div>

      <div className="container-x relative">
        <div className="text-center mb-14">
          <span className="section-divider">{lang === 'hi' ? 'हमारी गर्व की उपलब्धियाँ' : 'Our Proud Achievements'}</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-3 text-ink">
            {t.home.excellence}
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">{t.home.excellenceSub}</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
          {highlights.map((item, i) => {
            const Icon = Fa[item.icon] || Fa.FaStar;
            const title = lang === 'hi' ? item.title_hi || item.title : item.title;
            const desc = lang === 'hi' ? item.description_hi || item.description : item.description;
            return (
              <div
                key={item.id}
                className="group relative bg-white rounded-2xl p-6 text-center card-hover border border-gray-100 overflow-hidden"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                {/* Top accent */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-gold to-primary opacity-0 group-hover:opacity-100 transition-opacity"></div>

                <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 bg-gradient-to-br from-primary-50 to-primary-100 group-hover:from-primary group-hover:to-primary-700 transition-all duration-500">
                  <Icon className="text-2xl text-primary group-hover:text-white transition-colors duration-500" />
                </div>

                <div className="font-display text-3xl md:text-4xl font-bold gradient-text mb-1">
                  {item.number_value}
                </div>
                <div className="font-semibold text-sm text-ink mb-2">{title}</div>
                <div className="text-xs text-gray-500 leading-relaxed">{desc}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
