'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { FaArrowRight, FaImages } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function GallerySection() {
  const { t, lang } = useLang();
  const [items, setItems] = useState([]);

  useEffect(() => {
    fetch('/api/gallery?limit=8')
      .then(r => r.json())
      .then(data => setItems(data.items || []))
      .catch(() => {});
  }, []);

  if (!items.length) return null;

  return (
    <section className="py-20 bg-white relative">
      <div className="container-x">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <span className="section-divider">{lang === 'hi' ? 'झलकियाँ' : 'Glimpses'}</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-2">{t.home.galleryTitle}</h2>
            <p className="text-gray-600">{t.home.gallerySub}</p>
          </div>
          <Link href="/gallery" className="btn-primary">
            {t.home.viewAll} <FaArrowRight />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {items.slice(0, 8).map((item, i) => {
            const title = lang === 'hi' ? item.title_hi || item.title : item.title;
            return (
              <div
                key={item.id}
                className={`group relative overflow-hidden rounded-xl ${i === 0 || i === 5 ? 'md:row-span-2 md:col-span-1' : ''}`}
                style={{ height: i === 0 || i === 5 ? 'auto' : '200px', minHeight: '200px' }}
              >
                <img
                  src={item.media_url}
                  alt={title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                  <div>
                    <div className="text-xs uppercase tracking-widest text-gold mb-1">{item.category}</div>
                    <div className="text-white font-semibold">{title}</div>
                  </div>
                </div>
                <div className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition">
                  <FaImages />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
