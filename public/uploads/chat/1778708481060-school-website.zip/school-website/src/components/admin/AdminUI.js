'use client';
import { useState, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FaUpload, FaSpinner, FaTimes, FaPlus, FaPencilAlt, FaTrash, FaArrowLeft, FaSave, FaCheck } from 'react-icons/fa';

// File uploader — uploads to /api/upload, returns URL
export function FileUploader({ value, onChange, accept = 'image/*' }) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const ref = useRef(null);

  const upload = async (file) => {
    setUploading(true);
    setError('');
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      onChange(data.url);
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <div className="flex items-center gap-3">
        <input
          type="text"
          value={value || ''}
          onChange={(e) => onChange(e.target.value)}
          className="form-input flex-1"
          placeholder="https://... or upload below"
        />
        <button
          type="button"
          onClick={() => ref.current?.click()}
          disabled={uploading}
          className="px-4 py-2 bg-primary text-white rounded-lg flex items-center gap-2 hover:bg-primary-700 disabled:opacity-50 whitespace-nowrap"
        >
          {uploading ? <FaSpinner className="animate-spin" /> : <FaUpload />}
          {uploading ? 'Uploading' : 'Upload'}
        </button>
        <input
          ref={ref}
          type="file"
          accept={accept}
          className="hidden"
          onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
        />
      </div>
      {error && <p className="text-red-600 text-xs mt-1">{error}</p>}
      {value && (
        <div className="mt-3 inline-block relative">
          {value.match(/\.(mp4|webm|mov)$/i) ? (
            <video src={value} className="h-24 rounded-lg" controls />
          ) : (
            <img src={value} alt="" className="h-24 rounded-lg shadow-sm border border-gray-200" />
          )}
          <button type="button" onClick={() => onChange('')} className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
            <FaTimes />
          </button>
        </div>
      )}
    </div>
  );
}

// Admin page header with breadcrumb + action button
export function AdminHeader({ title, subtitle, action, back }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        {back && (
          <Link href={back} className="text-sm text-gray-500 hover:text-primary flex items-center gap-1 mb-2">
            <FaArrowLeft className="text-xs" /> Back
          </Link>
        )}
        <h1 className="font-display text-3xl md:text-4xl font-bold text-primary">{title}</h1>
        {subtitle && <p className="text-gray-500 mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

// Generic list table — pass items, columns, basePath
export function AdminList({ items, columns, basePath, onDelete, idField = 'id', emptyText = 'No items yet.', addLabel = 'Add new' }) {
  const router = useRouter();
  const handleDelete = async (id) => {
    if (!confirm('Delete this item? This cannot be undone.')) return;
    try {
      const res = await fetch(`${basePath}/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Delete failed');
      if (onDelete) onDelete(id);
      else router.refresh();
    } catch (e) {
      alert(e.message);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-md overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              {columns.map(c => (
                <th key={c.key} className="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  {c.label}
                </th>
              ))}
              <th className="px-5 py-3 text-right text-xs font-semibold text-gray-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {items.map(item => (
              <tr key={item[idField]} className="hover:bg-gray-50">
                {columns.map(c => (
                  <td key={c.key} className="px-5 py-3 text-sm text-gray-700">
                    {c.render ? c.render(item) : item[c.key]}
                  </td>
                ))}
                <td className="px-5 py-3 text-right whitespace-nowrap">
                  <Link href={`/admin${basePath.replace('/api', '')}/${item[idField]}`} className="inline-flex items-center gap-1 text-primary hover:text-primary-700 mr-3 text-sm">
                    <FaPencilAlt className="text-xs" /> Edit
                  </Link>
                  <button onClick={() => handleDelete(item[idField])} className="inline-flex items-center gap-1 text-red-500 hover:text-red-700 text-sm">
                    <FaTrash className="text-xs" /> Delete
                  </button>
                </td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={columns.length + 1} className="px-5 py-12 text-center text-gray-400">{emptyText}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Bilingual input pair
export function BilingualField({ label, value, valueHi, onChange, onChangeHi, type = 'text', rows }) {
  const Tag = rows ? 'textarea' : 'input';
  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div>
        <label className="form-label">{label} (English)</label>
        <Tag
          type={type}
          value={value || ''}
          onChange={(e) => onChange(e.target.value)}
          rows={rows}
          className="form-input"
        />
      </div>
      <div>
        <label className="form-label">{label} (हिंदी)</label>
        <Tag
          type={type}
          value={valueHi || ''}
          onChange={(e) => onChangeHi(e.target.value)}
          rows={rows}
          className="form-input"
          style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }}
        />
      </div>
    </div>
  );
}

export function SaveBar({ saving, ok, error }) {
  return (
    <div className="mt-8 flex items-center justify-end gap-4 sticky bottom-0 bg-white pt-4 pb-2 -mx-8 px-8 border-t border-gray-100">
      {error && <span className="text-red-600 text-sm">{error}</span>}
      {ok && <span className="text-green-600 text-sm flex items-center gap-1"><FaCheck /> Saved</span>}
      <button type="submit" disabled={saving} className="btn-primary disabled:opacity-50">
        {saving ? <FaSpinner className="animate-spin" /> : <FaSave />}
        {saving ? 'Saving...' : 'Save'}
      </button>
    </div>
  );
}

export { FaPlus };
