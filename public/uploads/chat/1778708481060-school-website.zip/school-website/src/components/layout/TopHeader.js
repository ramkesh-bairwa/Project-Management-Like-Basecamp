'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { FaPhone, FaEnvelope, FaFacebook, FaTwitter, FaInstagram, FaYoutube } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function TopHeader({ settings = {} }) {
  const { lang, setLang } = useLang();

  return (
    <div className="bg-gradient-to-r from-primary-900 via-primary-800 to-primary-900 text-white text-sm py-2 px-4 hidden md:block">
      <div className="container-x flex justify-between items-center">
        <div className="flex items-center gap-6">
          {settings.contact_phone && (
            <a href={`tel:${settings.contact_phone}`} className="flex items-center gap-2 hover:text-gold transition">
              <FaPhone className="text-xs" /> {settings.contact_phone}
            </a>
          )}
          {settings.contact_email && (
            <a href={`mailto:${settings.contact_email}`} className="flex items-center gap-2 hover:text-gold transition">
              <FaEnvelope className="text-xs" /> {settings.contact_email}
            </a>
          )}
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs opacity-80">
            {lang === 'hi' ? settings.working_hours_hi || settings.working_hours : settings.working_hours}
          </span>
          <span className="opacity-30">|</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLang('en')}
              className={`px-2 py-0.5 rounded text-xs font-semibold transition ${lang === 'en' ? 'bg-gold text-ink' : 'hover:bg-white/10'}`}
            >EN</button>
            <button
              onClick={() => setLang('hi')}
              className={`px-2 py-0.5 rounded text-xs font-semibold transition ${lang === 'hi' ? 'bg-gold text-ink' : 'hover:bg-white/10'}`}
            >हिं</button>
          </div>
          <span className="opacity-30">|</span>
          <div className="flex items-center gap-3">
            {settings.facebook_url && <a href={settings.facebook_url} target="_blank" rel="noopener noreferrer" className="hover:text-gold"><FaFacebook /></a>}
            {settings.twitter_url && <a href={settings.twitter_url} target="_blank" rel="noopener noreferrer" className="hover:text-gold"><FaTwitter /></a>}
            {settings.instagram_url && <a href={settings.instagram_url} target="_blank" rel="noopener noreferrer" className="hover:text-gold"><FaInstagram /></a>}
            {settings.youtube_url && <a href={settings.youtube_url} target="_blank" rel="noopener noreferrer" className="hover:text-gold"><FaYoutube /></a>}
          </div>
        </div>
      </div>
    </div>
  );
}
