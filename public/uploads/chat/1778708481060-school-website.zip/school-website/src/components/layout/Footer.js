'use client';
import Link from 'next/link';
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaFacebook, FaTwitter, FaInstagram, FaYoutube, FaGraduationCap, FaArrowRight } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function Footer({ settings = {} }) {
  const { t, lang } = useLang();
  const year = new Date().getFullYear();

  const quickLinks = [
    { label: t.nav.about, href: '/about' },
    { label: t.nav.academics, href: '/academics' },
    { label: t.nav.admissions, href: '/admissions' },
    { label: t.nav.faculty, href: '/faculty' },
    { label: t.nav.sports, href: '/sports' },
  ];

  const moreLinks = [
    { label: t.nav.gallery, href: '/gallery' },
    { label: t.nav.notices, href: '/notices' },
    { label: t.nav.events, href: '/events' },
    { label: t.nav.contact, href: '/contact' },
  ];

  return (
    <footer className="relative bg-gradient-to-br from-ink via-primary-950 to-ink text-gray-300 overflow-hidden">
      {/* Decorative top */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent"></div>

      {/* Pattern overlay */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <pattern id="footer-pat" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
            <circle cx="20" cy="20" r="1" fill="#d4af37" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#footer-pat)" />
        </svg>
      </div>

      <div className="relative container-x py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        {/* About */}
        <div>
          <Link href="/" className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-500 to-primary flex items-center justify-center text-white shadow-lg">
              <FaGraduationCap className="text-2xl" />
            </div>
            <div className="font-display font-bold text-xl text-white">
              {lang === 'hi' ? settings.site_name_hi || settings.site_name : settings.site_name || 'St. Heritage'}
            </div>
          </Link>
          <p className="text-sm leading-relaxed mb-5">
            {lang === 'hi' ? settings.footer_about_hi || settings.footer_about : settings.footer_about || ''}
          </p>
          <div className="flex gap-3">
            {settings.facebook_url && (
              <a href={settings.facebook_url} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 hover:bg-gold hover:text-ink flex items-center justify-center transition">
                <FaFacebook />
              </a>
            )}
            {settings.twitter_url && (
              <a href={settings.twitter_url} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 hover:bg-gold hover:text-ink flex items-center justify-center transition">
                <FaTwitter />
              </a>
            )}
            {settings.instagram_url && (
              <a href={settings.instagram_url} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 hover:bg-gold hover:text-ink flex items-center justify-center transition">
                <FaInstagram />
              </a>
            )}
            {settings.youtube_url && (
              <a href={settings.youtube_url} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 hover:bg-gold hover:text-ink flex items-center justify-center transition">
                <FaYoutube />
              </a>
            )}
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-display text-lg font-semibold text-white mb-5 relative pb-3">
            {t.footer.quickLinks}
            <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-gold"></span>
          </h4>
          <ul className="space-y-2.5 text-sm">
            {quickLinks.map((link, i) => (
              <li key={i}>
                <Link href={link.href} className="hover:text-gold transition flex items-center gap-2 group">
                  <FaArrowRight className="text-[10px] opacity-0 group-hover:opacity-100 transition" />
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* More Links */}
        <div>
          <h4 className="font-display text-lg font-semibold text-white mb-5 relative pb-3">
            {lang === 'hi' ? 'अधिक' : 'More'}
            <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-gold"></span>
          </h4>
          <ul className="space-y-2.5 text-sm">
            {moreLinks.map((link, i) => (
              <li key={i}>
                <Link href={link.href} className="hover:text-gold transition flex items-center gap-2 group">
                  <FaArrowRight className="text-[10px] opacity-0 group-hover:opacity-100 transition" />
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-display text-lg font-semibold text-white mb-5 relative pb-3">
            {t.footer.contact}
            <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-gold"></span>
          </h4>
          <ul className="space-y-3 text-sm">
            {settings.contact_address && (
              <li className="flex gap-3">
                <FaMapMarkerAlt className="text-gold mt-1 flex-shrink-0" />
                <span>{lang === 'hi' ? settings.contact_address_hi || settings.contact_address : settings.contact_address}</span>
              </li>
            )}
            {settings.contact_phone && (
              <li className="flex gap-3">
                <FaPhone className="text-gold mt-1 flex-shrink-0" />
                <a href={`tel:${settings.contact_phone}`} className="hover:text-gold">{settings.contact_phone}</a>
              </li>
            )}
            {settings.contact_email && (
              <li className="flex gap-3">
                <FaEnvelope className="text-gold mt-1 flex-shrink-0" />
                <a href={`mailto:${settings.contact_email}`} className="hover:text-gold break-all">{settings.contact_email}</a>
              </li>
            )}
          </ul>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="relative border-t border-white/10 py-5 text-center text-xs text-gray-400">
        <div className="container-x flex flex-col md:flex-row justify-between items-center gap-2">
          <div>© {year} {lang === 'hi' ? settings.site_name_hi || settings.site_name : settings.site_name}. {t.footer.rights}.</div>
          <div>{t.footer.developed} ❤</div>
        </div>
      </div>
    </footer>
  );
}
