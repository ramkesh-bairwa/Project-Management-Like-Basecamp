'use client';
import Link from 'next/link';
import { FaHome, FaChevronRight } from 'react-icons/fa';

export default function PageBanner({ title, subtitle, breadcrumbs = [] }) {
  return (
    <section className="page-banner relative bg-gradient-to-br from-primary-900 via-primary to-primary-800 text-white py-20 md:py-28 overflow-hidden">
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h60v60H0z' fill='none'/%3E%3Cpath d='M30 30 L60 0 H0 Z' fill='%23ffffff' opacity='0.3'/%3E%3C/svg%3E")`,
      }} />
      <div className="absolute -bottom-10 -right-10 w-72 h-72 bg-gold/10 rounded-full blur-3xl" />
      <div className="container-x relative z-10 text-center">
        <h1 className="font-display text-4xl md:text-6xl font-bold mb-4 leading-tight">{title}</h1>
        {subtitle && <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-6">{subtitle}</p>}
        <nav className="flex items-center justify-center text-sm text-white/80 flex-wrap gap-2">
          <Link href="/" className="hover:text-gold flex items-center gap-1">
            <FaHome /> Home
          </Link>
          {breadcrumbs.map((bc, i) => (
            <span key={i} className="flex items-center gap-2">
              <FaChevronRight className="text-xs opacity-60" />
              {bc.href ? (
                <Link href={bc.href} className="hover:text-gold">{bc.label}</Link>
              ) : (
                <span className="text-gold">{bc.label}</span>
              )}
            </span>
          ))}
        </nav>
      </div>
    </section>
  );
}
