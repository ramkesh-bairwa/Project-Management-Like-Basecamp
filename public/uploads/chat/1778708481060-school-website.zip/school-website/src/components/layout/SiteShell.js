'use client';
import { useEffect, useState } from 'react';
import TopHeader from './TopHeader';
import Navbar from './Navbar';
import Footer from './Footer';
import { useLang } from '@/lib/LangContext';

export default function SiteShell({ children }) {
  const [settings, setSettings] = useState({});
  const { lang } = useLang();

  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.json())
      .then(data => setSettings(data.settings || {}))
      .catch(() => {});
  }, []);

  useEffect(() => {
    document.body.classList.toggle('lang-hi', lang === 'hi');
  }, [lang]);

  return (
    <>
      <TopHeader settings={settings} />
      <Navbar settings={settings} />
      <main>{children}</main>
      <Footer settings={settings} />
    </>
  );
}
