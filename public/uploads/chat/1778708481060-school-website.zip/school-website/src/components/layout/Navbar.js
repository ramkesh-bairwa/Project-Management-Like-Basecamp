'use client';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { FaChevronDown, FaBars, FaTimes, FaGraduationCap } from 'react-icons/fa';
import { useLang } from '@/lib/LangContext';

export default function Navbar({ settings = {} }) {
  const { t, lang } = useLang();
  const [openDesktop, setOpenDesktop] = useState(null);   // index of open desktop dropdown
  const [openMobile, setOpenMobile] = useState(null);     // index of open mobile accordion
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navRef = useRef(null);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // close dropdown on outside click
  useEffect(() => {
    const handleClick = (e) => {
      if (navRef.current && !navRef.current.contains(e.target)) {
        setOpenDesktop(null);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // close mobile menu on navigation
  useEffect(() => {
    setMobileOpen(false);
    setOpenMobile(null);
    setOpenDesktop(null);
  }, [pathname]);

  const menu = [
    { label: t.nav.home, href: '/' },
    {
      label: t.nav.about,
      href: '/about',
      submenu: [
        { label: t.nav.aboutSchool, href: '/about#school' },
        { label: t.nav.missionVision, href: '/about#mission' },
        { label: t.nav.principalMessage, href: '/about#principal' },
      ],
    },
    {
      label: t.nav.academics,
      href: '/academics',
      submenu: [
        { label: t.nav.classes, href: '/academics#classes' },
        { label: t.nav.streams, href: '/academics#streams' },
        { label: t.nav.curriculum, href: '/academics#curriculum' },
      ],
    },
    {
      label: t.nav.admissions,
      href: '/admissions',
      submenu: [
        { label: t.nav.admissionProcess, href: '/admissions#process' },
        { label: t.nav.applyOnline, href: '/admissions#apply' },
        { label: t.nav.feeStructure, href: '/admissions#fees' },
      ],
    },
    { label: t.nav.faculty, href: '/faculty' },
    { label: t.nav.sports, href: '/sports' },
    {
      label: t.nav.gallery,
      href: '/gallery',
      submenu: [
        { label: t.nav.photos, href: '/gallery?type=photo' },
        { label: t.nav.videos, href: '/gallery?type=video' },
      ],
    },
    {
      label: t.nav.notices,
      href: '/notices',
      submenu: [
        { label: t.nav.latestNews, href: '/notices' },
        { label: t.nav.holidays, href: '/notices?cat=holiday' },
      ],
    },
    {
      label: t.nav.events,
      href: '/events',
      submenu: [
        { label: t.nav.allEvents, href: '/events' },
        { label: t.nav.upcoming, href: '/events?filter=upcoming' },
        { label: t.nav.past, href: '/events?filter=past' },
      ],
    },
    { label: t.nav.contact, href: '/contact' },
  ];

  const handleParentClick = (e, item, idx) => {
    if (!item.submenu) return;
    // On desktop, prevent navigation when toggling - click again to navigate
    if (window.innerWidth >= 1024) {
      if (openDesktop !== idx) {
        e.preventDefault();
        setOpenDesktop(idx);
      } else {
        // If same dropdown clicked again on parent, navigate to parent page
        setOpenDesktop(null);
      }
    }
  };

  return (
    <nav
      ref={navRef}
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-lg' : 'bg-white/95 backdrop-blur-md shadow-md'
      }`}
    >
      <div className="container-x">
        <div className="flex items-center justify-between py-3">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary-700 flex items-center justify-center text-white shadow-lg group-hover:scale-105 transition">
              <FaGraduationCap className="text-2xl" />
            </div>
            <div>
              <div className={`font-display font-bold text-primary leading-tight ${lang === 'hi' ? 'text-base' : 'text-lg'}`}>
                {lang === 'hi' ? settings.site_name_hi || settings.site_name : settings.site_name || 'St. Heritage'}
              </div>
              <div className="text-[10px] text-gray-500 tracking-widest uppercase hidden sm:block">
                {lang === 'hi' ? settings.site_tagline_hi || settings.site_tagline : settings.site_tagline || 'Excellence Since 1985'}
              </div>
            </div>
          </Link>

          {/* Desktop nav */}
          <ul className="hidden lg:flex items-center gap-1 text-[14px] font-medium">
            {menu.map((item, idx) => (
              <li key={idx} className="relative">
                {item.submenu ? (
                  <>
                    <button
                      onClick={(e) => handleParentClick(e, item, idx)}
                      onMouseEnter={() => setOpenDesktop(idx)}
                      className={`flex items-center gap-1 px-3 py-2 rounded-md hover:bg-primary/5 hover:text-primary transition ${
                        pathname.startsWith(item.href) && item.href !== '/' ? 'text-primary' : ''
                      }`}
                    >
                      {item.label}
                      <FaChevronDown className={`text-[10px] transition-transform ${openDesktop === idx ? 'rotate-180' : ''}`} />
                    </button>
                    {openDesktop === idx && (
                      <div
                        onMouseLeave={() => setOpenDesktop(null)}
                        className="absolute left-0 top-full mt-1 min-w-[240px] bg-white shadow-2xl rounded-lg border border-gray-100 py-2 overflow-hidden animate-fade-in"
                      >
                        <Link
                          href={item.href}
                          className="block px-4 py-2 text-sm font-semibold text-primary border-b border-gray-100 hover:bg-primary/5"
                        >
                          {item.label} →
                        </Link>
                        {item.submenu.map((sub, sidx) => (
                          <Link
                            key={sidx}
                            href={sub.href}
                            className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-primary hover:text-white transition relative pl-6"
                          >
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-gold"></span>
                            {sub.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <Link
                    href={item.href}
                    className={`px-3 py-2 rounded-md hover:bg-primary/5 hover:text-primary transition block ${
                      pathname === item.href ? 'text-primary' : ''
                    }`}
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>

          {/* CTA + Mobile toggle */}
          <div className="flex items-center gap-3">
            <Link href="/admissions#apply" className="hidden lg:inline-flex btn-primary !py-2.5 !px-5 text-sm">
              {t.home.heroBtn}
            </Link>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden w-10 h-10 flex items-center justify-center rounded-md bg-primary text-white"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <FaTimes /> : <FaBars />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-white border-t border-gray-100 max-h-[80vh] overflow-y-auto mobile-menu-enter">
          <ul className="py-2">
            {menu.map((item, idx) => (
              <li key={idx} className="border-b border-gray-50">
                {item.submenu ? (
                  <>
                    <div className="flex items-center justify-between">
                      <Link
                        href={item.href}
                        className="flex-1 px-4 py-3 font-medium text-gray-800"
                      >
                        {item.label}
                      </Link>
                      <button
                        onClick={() => setOpenMobile(openMobile === idx ? null : idx)}
                        className="px-4 py-3 text-gray-500"
                        aria-label="Toggle submenu"
                      >
                        <FaChevronDown className={`transition-transform ${openMobile === idx ? 'rotate-180 text-primary' : ''}`} />
                      </button>
                    </div>
                    {openMobile === idx && (
                      <div className="bg-gray-50 pl-6 py-1">
                        {item.submenu.map((sub, sidx) => (
                          <Link
                            key={sidx}
                            href={sub.href}
                            className="block px-4 py-2.5 text-sm text-gray-600 hover:text-primary border-l-2 border-gold/30 hover:border-primary"
                          >
                            {sub.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <Link href={item.href} className="block px-4 py-3 font-medium text-gray-800 hover:text-primary">
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>
          <div className="p-4">
            <Link href="/admissions#apply" className="btn-primary w-full justify-center">
              {t.home.heroBtn}
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
