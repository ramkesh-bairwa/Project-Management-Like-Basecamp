-- ============================================================================
-- SCHOOL WEBSITE — COMPLETE DATABASE SCHEMA
-- Import via phpMyAdmin or:  mysql -u root -p < database/schema.sql
-- ============================================================================

CREATE DATABASE IF NOT EXISTS school_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE school_db;

-- ============================================================================
-- ADMIN USERS
-- Default: username=admin, password=admin123 (CHANGE AFTER FIRST LOGIN)
-- ============================================================================
DROP TABLE IF EXISTS admin_users;
CREATE TABLE admin_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  email VARCHAR(150),
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150),
  role VARCHAR(50) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO admin_users (username, email, password_hash, full_name, role) VALUES
('admin', 'admin@school.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Administrator', 'super_admin');

-- ============================================================================
-- SITE SETTINGS
-- ============================================================================
DROP TABLE IF EXISTS site_settings;
CREATE TABLE site_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value TEXT,
  setting_value_hi TEXT,
  setting_type VARCHAR(50) DEFAULT 'text',
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO site_settings (setting_key, setting_value, setting_value_hi, setting_type) VALUES
('site_name', 'St. Heritage Public School', 'सेंट हेरिटेज पब्लिक स्कूल', 'text'),
('site_tagline', 'Excellence in Education Since 1985', 'शिक्षा में उत्कृष्टता 1985 से', 'text'),
('logo_url', '', NULL, 'image'),
('favicon_url', '', NULL, 'image'),
('primary_color', '#8b1a2e', NULL, 'color'),
('hero_video_url', 'https://videos.pexels.com/video-files/8419063/8419063-uhd_2560_1440_25fps.mp4', NULL, 'video'),
('hero_title', 'Shaping Tomorrow''s Leaders Today', 'आज के बच्चे, कल के नेता', 'text'),
('hero_subtitle', 'Where Tradition Meets Innovation in Education', 'जहाँ परंपरा और नवाचार मिलते हैं', 'text'),
('hero_cta_text', 'Apply for Admission', 'प्रवेश के लिए आवेदन करें', 'text'),
('about_short', 'A legacy of educational excellence spanning four decades', 'चार दशकों की शैक्षिक उत्कृष्टता की विरासत', 'textarea'),
('contact_phone', '+91 98765 43210', NULL, 'text'),
('contact_email', 'info@stheritage.edu.in', NULL, 'text'),
('contact_address', '123 Education Lane, Sector 15, New Delhi - 110001', '123 शिक्षा मार्ग, सेक्टर 15, नई दिल्ली - 110001', 'text'),
('working_hours', 'Mon-Fri: 8:00 AM - 4:00 PM\nSat: 8:00 AM - 1:00 PM', 'सोम-शुक्र: सुबह 8:00 - शाम 4:00\nशनि: सुबह 8:00 - दोपहर 1:00', 'textarea'),
('map_embed', '', NULL, 'html'),
('footer_about', 'Committed to providing world-class education with strong values, modern infrastructure, and dedicated faculty.', 'मजबूत मूल्यों, आधुनिक बुनियादी ढांचे और समर्पित शिक्षकों के साथ विश्व स्तरीय शिक्षा प्रदान करने के लिए प्रतिबद्ध।', 'textarea'),
('social_facebook', 'https://facebook.com', NULL, 'text'),
('social_instagram', 'https://instagram.com', NULL, 'text'),
('social_youtube', 'https://youtube.com', NULL, 'text'),
('social_twitter', 'https://twitter.com', NULL, 'text');

-- ============================================================================
-- HIGHLIGHTS — "Excellence in Education" stat boxes (real DB data, not dummy)
-- ============================================================================
DROP TABLE IF EXISTS highlights;
CREATE TABLE highlights (
  id INT AUTO_INCREMENT PRIMARY KEY,
  icon VARCHAR(100),
  title VARCHAR(200) NOT NULL,
  title_hi VARCHAR(200),
  number_value VARCHAR(50),
  description TEXT,
  description_hi TEXT,
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO highlights (icon, title, title_hi, number_value, description, description_hi, display_order, is_active) VALUES
('FaUserGraduate', 'Students Enrolled', 'पंजीकृत छात्र', '2500+', 'Active learners across all grades pursuing excellence', 'सभी कक्षाओं में सक्रिय छात्र उत्कृष्टता की ओर अग्रसर', 1, 1),
('FaChalkboardTeacher', 'Expert Faculty', 'विशेषज्ञ शिक्षक', '150+', 'Highly qualified and experienced teachers', 'उच्च योग्य और अनुभवी शिक्षक', 2, 1),
('FaTrophy', 'Awards Won', 'पुरस्कार जीते', '350+', 'National and international recognitions earned', 'राष्ट्रीय और अंतर्राष्ट्रीय मान्यताएँ प्राप्त', 3, 1),
('FaBook', 'Years of Legacy', 'विरासत के वर्ष', '40+', 'Decades of educational excellence and trust', 'शैक्षिक उत्कृष्टता और विश्वास के दशक', 4, 1),
('FaFlask', 'Modern Labs', 'आधुनिक प्रयोगशालाएँ', '25+', 'State-of-the-art science and computer labs', 'अत्याधुनिक विज्ञान और कंप्यूटर प्रयोगशालाएँ', 5, 1),
('FaMedal', 'Sports Champions', 'खेल चैंपियन', '120+', 'State and national level sports achievers', 'राज्य और राष्ट्रीय स्तर के खिलाड़ी', 6, 1);

-- ============================================================================
-- ABOUT CONTENT
-- ============================================================================
DROP TABLE IF EXISTS about_content;
CREATE TABLE about_content (
  id INT AUTO_INCREMENT PRIMARY KEY,
  section_key VARCHAR(100) UNIQUE NOT NULL,
  title VARCHAR(255),
  title_hi VARCHAR(255),
  content TEXT,
  content_hi TEXT,
  image_url VARCHAR(500),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO about_content (section_key, title, title_hi, content, content_hi, image_url) VALUES
('about_school', 'About Our School', 'हमारे विद्यालय के बारे में',
'Founded in 1985, St. Heritage Public School has been a beacon of educational excellence for over four decades. We are committed to nurturing well-rounded individuals through a balanced approach combining academic rigor, moral values, sports, arts, and life skills. Our state-of-the-art campus spans 15 acres of green space, providing students the perfect environment to learn, grow, and thrive. We follow the CBSE curriculum supplemented with international best practices to prepare our students for global challenges.',
'1985 में स्थापित, सेंट हेरिटेज पब्लिक स्कूल चार दशकों से शैक्षिक उत्कृष्टता का प्रतीक रहा है। हम शैक्षणिक कठोरता, नैतिक मूल्यों, खेल, कला और जीवन कौशल के संतुलित दृष्टिकोण के माध्यम से सर्वांगीण व्यक्तियों के विकास के लिए प्रतिबद्ध हैं। हमारा अत्याधुनिक परिसर 15 एकड़ हरित क्षेत्र में फैला है।',
'https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=1200'),

('mission', 'Our Mission', 'हमारा लक्ष्य',
'To provide a stimulating learning environment that empowers every child to discover their unique potential, fostering academic excellence, ethical values, creative expression, and global citizenship. We strive to create lifelong learners who contribute meaningfully to society.',
'एक उत्तेजक सीखने का वातावरण प्रदान करना जो हर बच्चे को अपनी अनूठी क्षमता की खोज करने के लिए सशक्त बनाता है, शैक्षणिक उत्कृष्टता, नैतिक मूल्यों और वैश्विक नागरिकता को बढ़ावा देता है।',
NULL),

('vision', 'Our Vision', 'हमारी दृष्टि',
'To be a globally recognized institution of educational excellence, shaping confident, compassionate, and capable leaders of tomorrow who will make a positive difference in the world through knowledge, integrity, and innovation.',
'शैक्षिक उत्कृष्टता का एक विश्व स्तर पर मान्यता प्राप्त संस्थान बनना, कल के आत्मविश्वासी, दयालु और सक्षम नेताओं को आकार देना जो ज्ञान, अखंडता और नवाचार के माध्यम से दुनिया में सकारात्मक अंतर लाएंगे।',
NULL),

('principal_message', 'Dr. Rajesh Kumar Sharma', 'डॉ. राजेश कुमार शर्मा',
'Dear Parents and Students,\n\nWelcome to St. Heritage Public School, where we believe education is not just about academic achievement, but about shaping character, nurturing talent, and building futures. With over 40 years of legacy, our institution stands as a testament to our commitment to holistic education.\n\nIn today''s rapidly changing world, we prepare our students not just for examinations, but for life itself. Our experienced faculty, modern infrastructure, and progressive curriculum work in harmony to ensure that every child discovers their true potential.\n\nWe invite you to be part of our heritage of excellence.\n\nWarm regards,\nDr. Rajesh Kumar Sharma\nPrincipal',
'प्रिय अभिभावकों और छात्रों,\n\nसेंट हेरिटेज पब्लिक स्कूल में आपका स्वागत है, जहाँ हम मानते हैं कि शिक्षा केवल शैक्षणिक उपलब्धि के बारे में नहीं है, बल्कि चरित्र निर्माण, प्रतिभा का पोषण और भविष्य के निर्माण के बारे में है।\n\nसादर,\nडॉ. राजेश कुमार शर्मा\nप्रधानाचार्य',
'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600');

-- ============================================================================
-- CLASSES
-- ============================================================================
DROP TABLE IF EXISTS classes;
CREATE TABLE classes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  class_name VARCHAR(150) NOT NULL,
  class_name_hi VARCHAR(150),
  age_group VARCHAR(100),
  description TEXT,
  description_hi TEXT,
  image_url VARCHAR(500),
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO classes (class_name, class_name_hi, age_group, description, description_hi, image_url, display_order, is_active) VALUES
('Nursery & Pre-Primary', 'नर्सरी एवं प्री-प्राइमरी', '3-5 years', 'A nurturing environment where children begin their educational journey through play-based learning, storytelling, and creative activities.', '3-5 आयु वर्ग के बच्चों के लिए पोषक वातावरण जहाँ वे खेल-आधारित शिक्षा के माध्यम से अपनी शैक्षिक यात्रा शुरू करते हैं।', 'https://images.unsplash.com/photo-1587653263995-422546a7a569?w=800', 1, 1),
('Primary (Class 1-5)', 'प्राथमिक (कक्षा 1-5)', '6-10 years', 'Building strong foundations in language, mathematics, science, and social skills through interactive teaching methods.', 'भाषा, गणित, विज्ञान और सामाजिक कौशल में मजबूत नींव का निर्माण।', 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800', 2, 1),
('Middle School (Class 6-8)', 'मिडिल स्कूल (कक्षा 6-8)', '11-13 years', 'Comprehensive education that develops critical thinking, scientific temperament, and creative expression.', 'व्यापक शिक्षा जो आलोचनात्मक सोच और रचनात्मक अभिव्यक्ति विकसित करती है।', 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=800', 3, 1),
('Secondary (Class 9-10)', 'माध्यमिक (कक्षा 9-10)', '14-15 years', 'CBSE curriculum preparing students for board examinations with strong conceptual understanding.', 'सीबीएसई पाठ्यक्रम छात्रों को बोर्ड परीक्षा के लिए तैयार करता है।', 'https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800', 4, 1),
('Senior Secondary (Class 11-12)', 'वरिष्ठ माध्यमिक (कक्षा 11-12)', '16-17 years', 'Specialized streams - Science, Commerce, and Arts - with focus on career preparation and competitive exams.', 'विशेष धाराएँ - विज्ञान, वाणिज्य और कला - कैरियर तैयारी पर ध्यान केंद्रित करें।', 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800', 5, 1);

-- ============================================================================
-- STREAMS
-- ============================================================================
DROP TABLE IF EXISTS streams;
CREATE TABLE streams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  name_hi VARCHAR(150),
  icon VARCHAR(100),
  description TEXT,
  description_hi TEXT,
  subjects TEXT,
  subjects_hi TEXT,
  image_url VARCHAR(500),
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO streams (name, name_hi, icon, description, description_hi, subjects, subjects_hi, image_url, display_order, is_active) VALUES
('Science', 'विज्ञान', 'FaFlask', 'Discover the wonders of science through rigorous study of natural phenomena, mathematical reasoning, and technological innovation. Pathway to engineering, medicine, and research.', 'प्राकृतिक घटनाओं, गणितीय तर्क और तकनीकी नवाचार के कठोर अध्ययन के माध्यम से विज्ञान के चमत्कारों की खोज करें।', 'Physics, Chemistry, Mathematics, Biology, Computer Science, English', 'भौतिकी, रसायन विज्ञान, गणित, जीव विज्ञान, कंप्यूटर विज्ञान, अंग्रेजी', 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800', 1, 1),
('Commerce', 'वाणिज्य', 'FaChartLine', 'Master the language of business with comprehensive study of finance, economics, and management. Pathway to CA, MBA, finance, and entrepreneurship.', 'वित्त, अर्थशास्त्र और प्रबंधन के व्यापक अध्ययन के साथ व्यवसाय की भाषा में महारत हासिल करें।', 'Accountancy, Business Studies, Economics, Mathematics, Informatics, English', 'लेखाशास्त्र, व्यवसाय अध्ययन, अर्थशास्त्र, गणित, अंग्रेजी', 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800', 2, 1),
('Arts / Humanities', 'कला / मानविकी', 'FaPaintBrush', 'Explore human culture, society, and creativity through diverse subjects that develop critical thinking. Pathway to civil services, law, journalism, and literature.', 'विविध विषयों के माध्यम से मानव संस्कृति, समाज और रचनात्मकता का अन्वेषण करें।', 'History, Political Science, Geography, Psychology, Sociology, English', 'इतिहास, राजनीति विज्ञान, भूगोल, मनोविज्ञान, समाजशास्त्र, अंग्रेजी', 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800', 3, 1);

-- ============================================================================
-- TEACHERS
-- ============================================================================
DROP TABLE IF EXISTS teachers;
CREATE TABLE teachers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  name_hi VARCHAR(150),
  designation VARCHAR(150),
  designation_hi VARCHAR(150),
  qualification VARCHAR(255),
  qualification_hi VARCHAR(255),
  department VARCHAR(100),
  experience_years INT DEFAULT 0,
  image_url VARCHAR(500),
  email VARCHAR(150),
  bio TEXT,
  bio_hi TEXT,
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO teachers (name, name_hi, designation, designation_hi, qualification, qualification_hi, department, experience_years, image_url, email, bio, bio_hi, display_order, is_active) VALUES
('Dr. Rajesh Kumar Sharma', 'डॉ. राजेश कुमार शर्मा', 'Principal', 'प्रधानाचार्य', 'Ph.D in Education, M.Ed, M.A.', 'पीएच.डी (शिक्षा), एम.एड, एम.ए.', 'Administration', 28, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400', 'principal@stheritage.edu.in', 'A visionary educator with three decades of experience transforming schools and shaping young minds.', 'तीन दशकों के अनुभव वाले दूरदर्शी शिक्षक।', 1, 1),
('Mrs. Priya Mehta', 'श्रीमती प्रिया मेहता', 'Vice Principal', 'उप प्रधानाचार्य', 'M.Sc Mathematics, B.Ed', 'एम.एससी (गणित), बी.एड', 'Administration', 22, 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400', 'vp@stheritage.edu.in', 'Dedicated to academic excellence and student development with expertise in mathematics education.', 'गणित शिक्षा में विशेषज्ञता।', 2, 1),
('Mr. Anil Verma', 'श्री अनिल वर्मा', 'HOD - Science', 'विभागाध्यक्ष - विज्ञान', 'M.Sc Physics, B.Ed', 'एम.एससी (भौतिकी), बी.एड', 'Science', 18, 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400', 'anil@stheritage.edu.in', 'Passionate physics educator known for innovative teaching methods and laboratory excellence.', 'अभिनव शिक्षण विधियों के लिए जाने जाते हैं।', 3, 1),
('Dr. Sunita Rao', 'डॉ. सुनीता राव', 'HOD - English', 'विभागाध्यक्ष - अंग्रेजी', 'Ph.D English Literature, M.A.', 'पीएच.डी (अंग्रेजी साहित्य), एम.ए.', 'Languages', 20, 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400', 'sunita@stheritage.edu.in', 'Literature enthusiast committed to nurturing love for language and creative writing.', 'भाषा और रचनात्मक लेखन के प्रति प्रेम।', 4, 1),
('Mr. Vikram Singh', 'श्री विक्रम सिंह', 'Sports Director', 'खेल निदेशक', 'M.P.Ed, NIS Certified', 'एम.पी.एड, एनआईएस प्रमाणित', 'Sports', 15, 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=400', 'vikram@stheritage.edu.in', 'Former state-level athlete dedicated to building sports excellence and physical fitness culture.', 'पूर्व राज्य स्तरीय एथलीट।', 5, 1),
('Mrs. Kavita Iyer', 'श्रीमती कविता अय्यर', 'Senior Teacher - Mathematics', 'वरिष्ठ शिक्षक - गणित', 'M.Sc Mathematics, B.Ed', 'एम.एससी (गणित), बी.एड', 'Mathematics', 16, 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400', 'kavita@stheritage.edu.in', 'Making mathematics enjoyable and accessible through innovative pedagogical approaches.', 'गणित को आनंददायक बनाना।', 6, 1),
('Mr. Suresh Pandey', 'श्री सुरेश पांडे', 'Senior Teacher - Hindi', 'वरिष्ठ शिक्षक - हिंदी', 'M.A. Hindi, B.Ed', 'एम.ए. (हिंदी), बी.एड', 'Languages', 19, 'https://images.unsplash.com/photo-1542178243-bc20204b769f?w=400', 'suresh@stheritage.edu.in', 'Hindi literature scholar fostering deep appreciation for Indian languages and culture.', 'भारतीय भाषाओं के विद्वान।', 7, 1),
('Ms. Neha Kapoor', 'सुश्री नेहा कपूर', 'Computer Science Teacher', 'कंप्यूटर विज्ञान शिक्षक', 'MCA, B.Ed', 'एमसीए, बी.एड', 'Computer Science', 12, 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400', 'neha@stheritage.edu.in', 'Tech-savvy educator preparing students for the digital future with hands-on coding experience.', 'डिजिटल भविष्य के लिए तैयार करना।', 8, 1);

-- ============================================================================
-- NOTICES
-- ============================================================================
DROP TABLE IF EXISTS notices;
CREATE TABLE notices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  title_hi VARCHAR(255),
  content TEXT,
  content_hi TEXT,
  category VARCHAR(50) DEFAULT 'general',
  notice_date DATE,
  is_important TINYINT(1) DEFAULT 0,
  attachment_url VARCHAR(500),
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO notices (title, title_hi, content, content_hi, category, notice_date, is_important, is_active) VALUES
('Annual Sports Day - Registrations Open', 'वार्षिक खेल दिवस - पंजीकरण खुले', 'Annual Sports Day will be held on December 15, 2026. All students are encouraged to participate in track events, team sports, and individual competitions. Register with your class teacher by November 30.', 'वार्षिक खेल दिवस 15 दिसंबर 2026 को आयोजित किया जाएगा।', 'sports', '2026-04-25', 1, 1),
('Parent-Teacher Meeting Schedule', 'अभिभावक-शिक्षक बैठक कार्यक्रम', 'PTM scheduled for May 10, 2026 from 9:00 AM to 1:00 PM. All parents are requested to attend to discuss their child''s academic progress.', 'अभिभावक-शिक्षक बैठक 10 मई 2026 को सुबह 9:00 बजे से दोपहर 1:00 बजे तक निर्धारित है।', 'academic', '2026-04-20', 1, 1),
('Summer Vacation Notice', 'गर्मी की छुट्टी की सूचना', 'School will remain closed for summer vacation from June 1 to July 5, 2026. School reopens on July 6, 2026.', 'गर्मी की छुट्टियों के लिए स्कूल 1 जून से 5 जुलाई 2026 तक बंद रहेगा।', 'holiday', '2026-04-15', 0, 1),
('Admission Open for 2026-27 Session', 'सत्र 2026-27 के लिए प्रवेश खुले', 'Applications are now being accepted for the academic year 2026-27 for classes Nursery to XI. Limited seats available. Apply online or visit the admission office.', 'शैक्षणिक वर्ष 2026-27 के लिए नर्सरी से XI तक आवेदन स्वीकार किए जा रहे हैं।', 'admission', '2026-04-10', 1, 1),
('Science Exhibition - Inter-School', 'विज्ञान प्रदर्शनी - अंतर-विद्यालय', 'Inter-school science exhibition on May 25, 2026. Students from classes 6-12 are invited to showcase innovative projects.', 'अंतर-विद्यालय विज्ञान प्रदर्शनी 25 मई 2026 को।', 'event', '2026-04-08', 0, 1),
('Republic Day Celebration', 'गणतंत्र दिवस समारोह', 'Republic Day will be celebrated with flag hoisting, cultural programs, and patriotic performances. Parents are cordially invited.', 'गणतंत्र दिवस ध्वजारोहण और सांस्कृतिक कार्यक्रमों के साथ मनाया जाएगा।', 'event', '2026-01-25', 0, 1),
('Holi Holiday Notice', 'होली अवकाश सूचना', 'School will remain closed on March 14-15, 2026 on account of Holi festival.', 'होली के अवसर पर 14-15 मार्च 2026 को स्कूल बंद रहेगा।', 'holiday', '2026-03-10', 0, 1);

-- ============================================================================
-- EVENTS
-- ============================================================================
DROP TABLE IF EXISTS events;
CREATE TABLE events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  title_hi VARCHAR(255),
  description TEXT,
  description_hi TEXT,
  event_date DATE,
  event_time VARCHAR(50),
  venue VARCHAR(255),
  venue_hi VARCHAR(255),
  category VARCHAR(50) DEFAULT 'general',
  image_url VARCHAR(500),
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO events (title, title_hi, description, description_hi, event_date, event_time, venue, venue_hi, category, image_url, is_active) VALUES
('Annual Day Celebration 2026', 'वार्षिक दिवस समारोह 2026', 'Grand annual celebration featuring cultural performances, prize distribution, and student showcases. Chief guest: Education Minister.', 'भव्य वार्षिक उत्सव जिसमें सांस्कृतिक प्रदर्शन, पुरस्कार वितरण शामिल हैं।', '2026-12-20', '5:00 PM', 'School Auditorium', 'विद्यालय सभागार', 'cultural', 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=800', 1),
('Inter-House Sports Meet', 'अंतर-सदन खेल प्रतियोगिता', 'Three-day sports extravaganza with track events, team sports, and individual competitions across all houses.', 'तीन दिवसीय खेल आयोजन सभी सदनों के बीच।', '2026-12-15', '8:00 AM', 'School Sports Ground', 'विद्यालय खेल मैदान', 'sports', 'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=800', 1),
('Science Exhibition 2026', 'विज्ञान प्रदर्शनी 2026', 'Inter-school science fair showcasing innovative projects and experiments.', 'अंतर-विद्यालय विज्ञान मेला।', '2026-05-25', '10:00 AM', 'Science Block', 'विज्ञान भवन', 'academic', 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800', 1),
('Cultural Fest - Rangmanch', 'सांस्कृतिक उत्सव - रंगमंच', 'Annual cultural festival celebrating diversity through music, dance, drama, and art performances.', 'वार्षिक सांस्कृतिक उत्सव।', '2026-08-15', '4:00 PM', 'Open Air Theater', 'खुली हवा का थिएटर', 'cultural', 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800', 1),
('Independence Day Celebration', 'स्वतंत्रता दिवस समारोह', 'Patriotic ceremony with flag hoisting, parades, and cultural performances honoring our nation.', 'देशभक्ति समारोह।', '2026-08-15', '8:00 AM', 'School Ground', 'विद्यालय का मैदान', 'national', 'https://images.unsplash.com/photo-1564039670089-d7be9c4ed2f5?w=800', 1),
('Children''s Day Special', 'बाल दिवस विशेष', 'Special programs and activities organized for and by children to celebrate their day.', 'बच्चों के लिए विशेष कार्यक्रम।', '2025-11-14', '10:00 AM', 'School Auditorium', 'विद्यालय सभागार', 'celebration', 'https://images.unsplash.com/photo-1527334919515-b8dee906a34b?w=800', 1),
('Math Olympiad', 'गणित ओलंपियाड', 'Annual mathematics competition testing problem-solving skills and analytical thinking.', 'वार्षिक गणित प्रतियोगिता।', '2025-09-10', '9:00 AM', 'Examination Hall', 'परीक्षा हॉल', 'academic', 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800', 1);

-- ============================================================================
-- GALLERY
-- ============================================================================
DROP TABLE IF EXISTS gallery;
CREATE TABLE gallery (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  title_hi VARCHAR(255),
  category VARCHAR(50) DEFAULT 'general',
  media_type ENUM('photo','video') DEFAULT 'photo',
  media_url VARCHAR(500) NOT NULL,
  thumbnail_url VARCHAR(500),
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO gallery (title, title_hi, category, media_type, media_url, display_order, is_active) VALUES
('Annual Day 2025', 'वार्षिक दिवस 2025', 'cultural', 'photo', 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=1200', 1, 1),
('Sports Day Champions', 'खेल दिवस के चैंपियन', 'sports', 'photo', 'https://images.unsplash.com/photo-1571260899304-425eee4c7efc?w=1200', 2, 1),
('Science Lab Experiments', 'विज्ञान प्रयोगशाला', 'academic', 'photo', 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=1200', 3, 1),
('Cultural Performance', 'सांस्कृतिक प्रदर्शन', 'cultural', 'photo', 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=1200', 4, 1),
('Art & Craft Exhibition', 'कला एवं शिल्प प्रदर्शनी', 'academic', 'photo', 'https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1200', 5, 1),
('Inter-School Cricket', 'अंतर-विद्यालय क्रिकेट', 'sports', 'photo', 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=1200', 6, 1),
('Library Reading Hour', 'पुस्तकालय पठन समय', 'academic', 'photo', 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=1200', 7, 1),
('Field Trip Memories', 'क्षेत्र यात्रा यादें', 'trips', 'photo', 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=1200', 8, 1),
('Music Concert', 'संगीत समारोह', 'cultural', 'photo', 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=1200', 9, 1),
('Computer Lab Session', 'कंप्यूटर प्रयोगशाला', 'academic', 'photo', 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=1200', 10, 1),
('Yoga Day Celebration', 'योग दिवस समारोह', 'sports', 'photo', 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=1200', 11, 1),
('Republic Day Parade', 'गणतंत्र दिवस परेड', 'cultural', 'photo', 'https://images.unsplash.com/photo-1564039670089-d7be9c4ed2f5?w=1200', 12, 1);

-- ============================================================================
-- TESTIMONIALS
-- ============================================================================
DROP TABLE IF EXISTS testimonials;
CREATE TABLE testimonials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  name_hi VARCHAR(150),
  role VARCHAR(150),
  role_hi VARCHAR(150),
  message TEXT,
  message_hi TEXT,
  rating INT DEFAULT 5,
  image_url VARCHAR(500),
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO testimonials (name, name_hi, role, role_hi, message, message_hi, rating, image_url, display_order, is_active) VALUES
('Mrs. Anjali Sharma', 'श्रीमती अंजलि शर्मा', 'Parent of Class 8 Student', 'कक्षा 8 के छात्र की अभिभावक', 'St. Heritage has been a transformative experience for my daughter. The teachers are dedicated, the infrastructure is world-class, and the values instilled are priceless.', 'सेंट हेरिटेज ने मेरी बेटी के लिए परिवर्तनकारी अनुभव दिया है।', 5, 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400', 1, 1),
('Rohan Mehta', 'रोहन मेहता', 'Alumni, Batch of 2018', 'पूर्व छात्र, 2018 बैच', 'The foundation I received at St. Heritage prepared me for IIT and beyond. The mentorship, discipline, and holistic development I experienced here continue to guide me.', 'सेंट हेरिटेज में मिली नींव ने मुझे आईआईटी के लिए तैयार किया।', 5, 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400', 2, 1),
('Mr. Suresh Patel', 'श्री सुरेश पटेल', 'Parent of Class 12 Student', 'कक्षा 12 के छात्र के पिता', 'Excellent academics combined with character building. My son has grown into a confident, well-rounded individual ready to face any challenge.', 'शैक्षणिक उत्कृष्टता और चरित्र निर्माण दोनों।', 5, 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400', 3, 1),
('Priya Kapoor', 'प्रिया कपूर', 'Alumni, Batch of 2020', '2020 बैच की पूर्व छात्रा', 'The teachers here don''t just teach subjects - they inspire dreams. From debate competitions to science olympiads, every opportunity helped me grow.', 'यहां के शिक्षक न केवल विषय पढ़ाते हैं - वे सपने प्रेरित करते हैं।', 5, 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400', 4, 1),
('Mrs. Deepa Joshi', 'श्रीमती दीपा जोशी', 'Parent', 'अभिभावक', 'Three of my children have studied here over 15 years. Each had a unique journey but all received exceptional care and education. This is more than a school, it''s a family.', 'मेरे तीन बच्चे यहां पढ़े हैं। यह एक परिवार है।', 5, 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400', 5, 1);

-- ============================================================================
-- ADMISSION INFO — single row with process, fees, eligibility, dates
-- ============================================================================
DROP TABLE IF EXISTS admission_info;
CREATE TABLE admission_info (
  id INT AUTO_INCREMENT PRIMARY KEY,
  process_steps TEXT,
  process_steps_hi TEXT,
  eligibility TEXT,
  eligibility_hi TEXT,
  documents_required TEXT,
  documents_required_hi TEXT,
  fee_nursery INT DEFAULT 0,
  fee_primary INT DEFAULT 0,
  fee_middle INT DEFAULT 0,
  fee_secondary INT DEFAULT 0,
  fee_senior INT DEFAULT 0,
  important_dates TEXT,
  important_dates_hi TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO admission_info (process_steps, process_steps_hi, eligibility, eligibility_hi, documents_required, documents_required_hi, fee_nursery, fee_primary, fee_middle, fee_secondary, fee_senior, important_dates, important_dates_hi) VALUES
('Fill out the online application form\nApplication review (3-5 working days)\nEntrance test / Parent-student interaction\nAdmission letter & fee payment within 7 days\nDocument verification & enrollment',
'ऑनलाइन आवेदन पत्र भरें\nआवेदन की समीक्षा (3-5 कार्य दिवस)\nप्रवेश परीक्षा / अभिभावक-छात्र साक्षात्कार\n7 दिनों के भीतर प्रवेश पत्र और शुल्क भुगतान\nदस्तावेज़ सत्यापन और नामांकन',
'Age criteria as per CBSE norms. Open to all students based on entrance evaluation and merit.',
'सीबीएसई मानदंडों के अनुसार आयु मानदंड। प्रवेश मूल्यांकन और योग्यता के आधार पर सभी छात्रों के लिए खुला।',
'Birth certificate (original + copy)\nPrevious school transfer certificate\nReport card from previous class\n4 passport-size photographs\nAddress proof (Aadhaar / utility bill)\nParent ID proof',
'जन्म प्रमाण पत्र (मूल + प्रति)\nपिछले स्कूल का स्थानांतरण प्रमाण पत्र\nपिछली कक्षा का रिपोर्ट कार्ड\n4 पासपोर्ट साइज फोटो\nपते का प्रमाण (आधार / बिजली बिल)\nअभिभावक का पहचान प्रमाण',
65000, 85000, 105000, 125000, 145000,
'Application opens: April 1\nApplication deadline: May 15\nEntrance test: May 25\nResults: June 1\nAdmission confirmation: June 10',
'आवेदन शुरू: 1 अप्रैल\nआवेदन अंतिम तिथि: 15 मई\nप्रवेश परीक्षा: 25 मई\nपरिणाम: 1 जून\nप्रवेश पुष्टि: 10 जून');

-- ============================================================================
-- ADMISSION APPLICATIONS
-- ============================================================================
DROP TABLE IF EXISTS admission_applications;
CREATE TABLE admission_applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_name VARCHAR(150) NOT NULL,
  dob DATE,
  gender VARCHAR(20),
  parent_name VARCHAR(150) NOT NULL,
  parent_email VARCHAR(150),
  phone VARCHAR(20) NOT NULL,
  address TEXT,
  applying_for_class VARCHAR(50) NOT NULL,
  previous_school VARCHAR(255),
  message TEXT,
  status ENUM('pending','reviewed','approved','rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- SPORTS
-- ============================================================================
DROP TABLE IF EXISTS sports;
CREATE TABLE sports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  name_hi VARCHAR(150),
  icon VARCHAR(100),
  category VARCHAR(50),
  description TEXT,
  description_hi TEXT,
  image_url VARCHAR(500),
  achievements TEXT,
  achievements_hi TEXT,
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO sports (name, name_hi, icon, category, description, description_hi, image_url, achievements, achievements_hi, display_order, is_active) VALUES
('Cricket', 'क्रिकेट', 'GiCricketBat', 'Outdoor', 'Professional cricket coaching with international-standard pitch, nets, and equipment. Regular matches and tournaments organized at inter-school and state levels.', 'अंतर्राष्ट्रीय मानक की पिच, जाल और उपकरणों के साथ पेशेवर क्रिकेट कोचिंग।', 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=1200', 'State Champions 2024, Inter-School Trophy Winners 2023, 2022', 'राज्य चैंपियन 2024, अंतर-विद्यालय ट्रॉफी विजेता', 1, 1),
('Football', 'फुटबॉल', 'GiSoccerBall', 'Outdoor', 'Full-size football ground with FIFA-standard goal posts. Trained coaches develop players from beginner to advanced level with focus on technique and teamwork.', 'फीफा-मानक गोल पोस्ट के साथ पूर्ण आकार का फुटबॉल मैदान।', 'https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=1200', 'District Champions 2024, U-17 Inter-School Winners', 'जिला चैंपियन 2024', 2, 1),
('Basketball', 'बास्केटबॉल', 'GiBasketballBall', 'Outdoor', 'Modern basketball courts with professional coaching for boys and girls. Regular practice sessions and competitive matches throughout the year.', 'लड़कों और लड़कियों के लिए पेशेवर कोचिंग के साथ आधुनिक बास्केटबॉल कोर्ट।', 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=1200', 'Zonal Champions, Inter-School Bronze 2024', 'जोनल चैंपियन', 3, 1),
('Swimming', 'तैराकी', 'FaSwimmer', 'Aquatic', 'Olympic-size swimming pool with certified instructors. Programs for beginners to competitive swimmers with focus on safety and technique.', 'प्रमाणित प्रशिक्षकों के साथ ओलंपिक आकार का स्विमिंग पूल।', 'https://images.unsplash.com/photo-1530549387789-4c1017266635?w=1200', 'State Medalists, National Level Qualifiers', 'राज्य पदक विजेता', 4, 1),
('Athletics', 'एथलेटिक्स', 'FaRunning', 'Track', 'Track and field events including running, jumping, and throwing. Professional training with proper warm-up, technique, and competitive preparation.', 'दौड़, कूद और थ्रोइंग सहित ट्रैक और फील्ड इवेंट्स।', 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=1200', '15+ State Medals 2024, National Championship Participants', '15+ राज्य पदक 2024', 5, 1),
('Badminton', 'बैडमिंटन', 'GiShuttlecock', 'Indoor', 'Indoor badminton courts with wooden flooring. Coaching available for all levels from beginner to advanced tournament players.', 'लकड़ी की फर्श के साथ इनडोर बैडमिंटन कोर्ट।', 'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=1200', 'State Doubles Champions 2024', 'राज्य डबल्स चैंपियन', 6, 1),
('Table Tennis', 'टेबल टेनिस', 'FaTableTennis', 'Indoor', 'Multiple TT tables with professional coaching. Develops hand-eye coordination, reflexes, and strategic thinking through regular practice.', 'पेशेवर कोचिंग के साथ कई टीटी टेबल।', 'https://images.unsplash.com/photo-1534158914592-062992fbe900?w=1200', 'Inter-School Singles Champions, Regional Qualifiers', 'अंतर-विद्यालय एकल चैंपियन', 7, 1),
('Yoga & Meditation', 'योग एवं ध्यान', 'FaPrayingHands', 'Wellness', 'Daily yoga sessions for physical fitness and mental well-being. Special workshops on meditation, pranayama, and mindfulness practices.', 'शारीरिक फिटनेस और मानसिक कल्याण के लिए दैनिक योग सत्र।', 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=1200', 'International Yoga Day 1500+ participants', 'अंतर्राष्ट्रीय योग दिवस 1500+ प्रतिभागी', 8, 1),
('Karate', 'कराटे', 'GiPunch', 'Martial', 'Traditional Japanese karate training emphasizing discipline, self-defense, and physical fitness. Black belt instructors guide students through belts.', 'पारंपरिक जापानी कराटे प्रशिक्षण।', 'https://images.unsplash.com/photo-1555597673-b21d5c935865?w=1200', 'Multiple Black Belt holders, National Tournament Winners', 'कई ब्लैक बेल्ट धारक', 9, 1);

-- ============================================================================
-- CONTACT MESSAGES
-- ============================================================================
DROP TABLE IF EXISTS contact_messages;
CREATE TABLE contact_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(20),
  subject VARCHAR(255),
  message TEXT NOT NULL,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- DONE — Default admin login: admin / admin123
-- ============================================================================
SELECT 'School database setup complete. Default admin: admin / admin123' AS Status;
